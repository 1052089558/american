module.exports = {
    plugins: {
        'postcss-px2rem': {
            remUnit: 75 // 将1rem设置为75px 设计稿1/10
        }
    }
}
