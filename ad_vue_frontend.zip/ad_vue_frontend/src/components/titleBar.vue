<template>
  <div class="header">
    <div class="header-flex">
      <div class="header-lf">abcd69</div>
      <div class="header-rg">
        <div
          class="lang-box"
        >
          <div class="lang-title">{{ lang }}</div>
          <img
            class="bottom-icon-img"
            src="../assets/images/home/bottom-icon.png"
            alt=""
          />
        </div>
        <div
          class="area-box"
        >
          <img
            class="area-icon-img"
            src="../assets/images/home/area-icon.png"
            alt=""
          />

          <div class="area-title">{{ country }}</div>
        </div>
        <div
          class="screen-box"
          @click="(showMenuBox == true ? showMenuBox=false:showMenuBox=true)"
        >
          <img
            class="screen-icon-img"
            src="../assets/images/home/screen.png"
            alt=""
          />
        </div>
      </div>
    </div>
    
    <div class="country-popup-box" v-if="showMenuBox">
      <div class="country-item" v-if="isToken"  @click="isLogin">
        <img
          class="muen-icon-img"
          src="../assets/images/home/loginIcon.png"
        />
        <div class="area-title">SIGN IN/UP</div>
      </div>
      <div class="country-item" @click="clickUserAgreement">
        <img
          class="muen-icon-img"
          src="../assets/images/home/UserAgreement.png"
        />
        <div class="area-title">User Agreement</div>
      </div>
      <div class="country-item" @click="isContact">
        <img
          class="muen-icon-img"
          src="../assets/images/home/ContactUs.png"
        />
        <div class="area-title">Contact Us</div>
      </div>
      <div class="country-item" @click="clickFeedback">
        <img
          class="muen-icon-img"
          src="../assets/images/home/Feedback.png"
        />
        <div class="area-title">Feedback</div>
      </div>
    </div>
    <van-popup v-model="showContact">
      <div class="popup-box">
        <div class="popup-head">
          <img
          class="muen-icon-img"
          src="../assets/images/home/ContactUs.png"
          />
          Contact Us
        </div>
        <img
          @click="showContact = false"
          class="close-icon"
          src="../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">
          email：{{ contactUs }}
        </div>
        <div class="confirm-btn" @click="copyLink">copy</div>
      </div>
    </van-popup>
    <van-popup v-model="showUserAgreement">
      <div class="popup-box">
        <div class="popup-head">
          <img
          class="muen-icon-img"
          src="../assets/images/home/UserAgreement.png"
          />
          User Agreement
        </div>
        <img
          @click="showUserAgreement = false"
          class="close-icon"
          src="../assets/images/close-icon.png"
          alt=""
        />
        <div class="content-Agreement">
          <p>Terms of Service:</p>
          <span>
            &nbsp;&nbsp;&nbsp;&nbsp;abcd69.com is a web site (the "Site") that hosts classified advertising and related 
            content created and developed by third-party users. Your use of the Site, including 
            all access, services and/or features, is governed by these Terms of Use and the 
            Privacy Policy (collectively, "Terms"), and you should review both carefully. By 
            using the Site in any way, you are agreeing to comply with these Terms.The Site 
            reserves the right to change the Terms at any time and for any reason. Updated versi  ns 
            of the Terms will be posted to the Site at abcd69.com and you should visit this page 
            periodically to keep apprised of any changes. abcd69.com provides advertising services 
            for individuals.Users who publish advertisements and related content information 
            on the Site shall comply with the laws of the local country and region.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;The advertising in the Site only stand for the Site users,it does not represent 
            the Site.If the violations of laws and regulations, the user will be borne by 
            themselves,the Site does not assume any legal responsibility.If user uses the Site, 
            representing user has read and agreed the Terms.By continuing to use the Site after 
            any such change, you accept and agree to the modified Terms.The Site reserves the 
            right to modify or discontinue, temporarily or permanently, the Site, any site features,
             benefits (including without limitation blocking or terminating your Account), rules 
             or conditions, all without notice, even though such changes may affect the way you 
             use the Site. You agree that the Site will not be liable to you or any third-party 
             for any modification or discontinuance of the Site.
          </span>
          <p>User Conduct:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;Without limitation, you agree to refrain from the following actions while using the Site:<br>
          1.&nbsp;&nbsp;Harassing, threatening, embarrassing or causing distress or discomfort upon another individual 
          or entity or impersonating any other person or entity or otherwise restricting or inhibiting any
           other person from using or enjoying the Site;<br>
          2.&nbsp;&nbsp;Transmitting any information, data, text, files, links, software, chats, communication or 
          other materials that is unlawful, false, misleading, harmful, threatening, abusive, invasive 
          of another's privacy, harassing, defamatory, vulgar, obscene, hateful or racially or otherwise 
          objectionable, including without limitation material of any kind or nature that encourages 
          conduct that could constitute a criminal offense, give rise to civil liability or otherwise 
          violate any applicable local, state, provincial, national, or international law or regulation, 
          or encourage the use of controlled substances;<br>
          3.&nbsp;&nbsp;Posting advertising or solicitation in categories that is not appropriate, or posting the 
          same item or service in more than one category or more than once every 7 days, or posting the 
          same ad in multiple cities on the Site;<br>
          4. (a) Posting adult content or explicit adult material and any material country to the law 
            which is enforce.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(b) Posting, anywhere on the Site, obscene or lewd and lascivious graphics or photographs 
            which depict genitalia or actual or simulated sexual acts, or any act which suggest or promote 
            sexual acts or solicits sexual favor.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(c) Posting any solicitation directly or in “coded” fashion for any illegal service 
            exchanging sexual favors for money or other valuable consideration;<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(d) Posting any material on the Site that exploits minors in any way;<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(e) Posting any material on the Site that in any way constitutes or assists in human trafficking.<br>
          5.&nbsp;&nbsp; Posting any ad for products or services, use or sale of which is prohibited by any law or regulation;<br>
          6.&nbsp;&nbsp;Sending mail, e-mail, voice messages or faxes for solicitation of any other product, or 
          service to a user of the Site unless the user has granted permission in their ad or otherwise
           allowed contact for solicitation;<br>
          7.&nbsp;&nbsp;Deleting or revising any material posted by any other user;<br>
          8.&nbsp;&nbsp;Interfering with or infringing the patents, copyrights, trademarks, service marks, logos, 
          confidential information or intellectual property rights of others;<br>
          9.&nbsp;&nbsp;Using any automated device, spider, robot, crawler, data mining tool, software or routine 
          to access, copy, or download any part of the Site unless expressly permitted by the Site;<br>
          10.&nbsp;&nbsp;Taking any action creating a disproportionately large usage load on the Site unless expressly
           permitted by the Site:<br>
          11.&nbsp;&nbsp;Sending messages or engaging in disruptive or damaging activities online, including excessive 
          use of scripts, sound waves, scrolling, or use of viruses, bots, worms, time bombs, Trojan horses
           or any other destructive element;<br>
          12.&nbsp;&nbsp;Gaining or attempting to gain unauthorized access to non-public areas of the Site. In addition, 
          if you have a password to a non-public area of the Site, you may not disclose to, or share your 
          password, with any third parties and/or use your password for unauthorized purposes;<br>
          13.&nbsp;&nbsp;Attempting to decipher, decompile, disassemble or reverse engineer any of the software comprising 
          or in any way making up all or any part of the Site; modifying any meta data, copying or duplicating 
          in any manner any of the content; framing of or linking to any of the Site, its content or information 
          available from the Site without the express written consent of agents of the Site;<br>
          14.&nbsp;&nbsp;Discriminating on the grounds of race, religion, national origin, gender, disability, 
          age, marital status, sexual orientation, or refers to such matters in any manner prohibited by law;<br>
          15.&nbsp;&nbsp;Posting any employment ads violating the anti-discrimination provisions of the Immigration 
          and Nationality Act or messages which violate any law or regulation, or any ad which violate labor 
          law of the country.<br>
          16.&nbsp;&nbsp;Using the Site to engage in or assist another individual or entity to engage in fraudulent, 
          abusive, manipulative or illegal activity.<br>
          17.&nbsp;&nbsp;Posting free ads promoting links to commercial services or web sites except in areas of the Site 
          where such ads are expressly permitted;<br>
          <p>Use of Materials:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;Any ads or messages that you post, transmit, or otherwise make available for viewing on public areas of the Site will be treated as non-confidential and non-proprietary to you. You understand and agree that any such ads and messages may be used by the Site or our affiliates, without review or approval by you, for any purpose whatsoever, and in any medium, including our print media, if any. You grant the Site (and our affiliates) the irrevocable right to use and/or edit your ads and messages, without review or approval by you, for any purpose whatsoever, including, without limitation, reproduction, disclosure, transmission, publication, broadcast, posting, and advertising in any media in perpetuity without notice or compensation to you.
          <p>Termination of Access:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;The Site has the right terminate your access for any reason if we believe you have violated these Terms in any manner. You agree not to hold the Site liable for such termination, and further agree not to attempt to use the Site after termination.
          <p>No Third Party Beneficiaries:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;You agree that, except as otherwise provided in this Terms of Use, there shall be no third party beneficiaries to these Terms.
        </div>
        <div class="confirm-btn" @click="showUserAgreement = false">confirm</div>
      </div>
    </van-popup>
    <van-popup v-model="showFeedback">
      <div class="popup-box">
        <div class="popup-head">
          <img
          class="muen-icon-img"
          src="../assets/images/home/Feedback.png"
          />
          Feedback
        </div>
        <img
          @click="showFeedback = false"
          class="close-icon"
          src="../assets/images/close-icon.png"
          alt=""
        />
        <div class="content-Feedback">
          <van-field v-model="feedbackDescription"   show-word-limit
          maxlength="400" autosize="true"  rows="15"  type="textarea"   
          placeholder="Please describe your suggestions or issues so that wecan better serve you!" />
        </div>
        <div class="confirm-btn" @click="confirmFeedback()">confirm</div>
      </div>
    </van-popup>
  </div>
</template>

<script>
import {getConfigValue,apiFeedbackInformation} from '../request/api.js'
export default {
  name: "titleBar",
  data() {
    return {
      lang: "EN",
      country: "USA",
      isToken:false,
      showLangBox: false,
      showCountryBox: false,
      showMenuBox:false,
      showContact:false,
      showUserAgreement:false,
      showFeedback:false,
      feedbackDescription:"",
      contactUs:"",
      AgreementText:"",
      langList: ["English", "Español", "中文"],
      menuList: [
        {
          imgSrc:"../assets/images/home/UserAgreement.png",
          menuName:"User Agreement"
        },
        {
          imgSrc:"../assets/images/home/ContactUs.png",
          menuName:"Contact Us"
        },
        {
          imgSrc:"../assets/images/home/Feedback.png",
          menuName:"feedback"
        }],
      countryList: [
        "USA",
        "Canada",
        "UK",
        "Australia",
        "New Zealand",
        "Mexico",
      ],
    };
  },
  async created() {
     getConfigValue({configKey:"contactUs"}).then((res) =>{
      if(res.code == 200){
        this.contactUs = res.msg
      }
    })  
    let token = localStorage.getItem('key')
      if (!token) {
      this.isToken=true;    
    } 
    // getConfigValue({configKey:"UserAgreement"}).then((res) =>{
    //   if(res.code == 200){
    //     this.AgreementText = res.msg
    //   }
    // })  
  },
  mounted() {
    let lang = localStorage.getItem("i18n_lang");
    if (lang) {
      if (lang == "zh-en") {
        this.lang = "EN";
      } else if (lang == "zh-es") {
        this.lang = "ES";
      } else if (lang == "zh-cn") {
        this.lang = "CN";
      }
    } else {
      this.lang = "EN";
    }
    console.log(this.lang);

    let country = localStorage.getItem("country");
    if (country) {
      this.country = country;
    } else {
      this.country = "USA";
    }
    console.log(this.country);
  },
  methods: {
    // handleLang(item) {
    //   if (item == "English") {
    //     this.lang = "EN";
    //     localStorage.setItem("i18n_lang", "zh-en");
    //     this.$i18n.locale = "zh-en";
    //   } else if (item == "Español") {
    //     this.lang = "ES";
    //     localStorage.setItem("i18n_lang", "zh-es");
    //     this.$i18n.locale = "zh-es";
    //   } else if (item == "中文") {
    //     this.lang = "CN";
    //     localStorage.setItem("i18n_lang", "zh-cn");
    //     this.$i18n.locale = "zh-cn";
    //   }
    //   this.showLangBox = false;
    // },
    isLogin(){
      this.$router.push({path: "/login"});
    },
    handleCountry(item) {
      // this.country = item;
      localStorage.setItem("country", this.country);
      this.showMenuBox = false;
    },
    isContact(){
      this.showMenuBox=false
      this.showContact=true
    },
    clickUserAgreement(){
      this.showMenuBox=false
      this.showUserAgreement=true
    },
    clickFeedback(){
      this.showMenuBox=false
      this.showFeedback=true
    },
    copyLink() {
      this.showContact=false
      let contactUs = this.contactUs
      this.$copyText(contactUs).then(
        (e) => {
          this.$toast.success(this.$t('ok'))
        },
        (err) => {
          this.$toast.fail(this.$t('fail'))
        }
      )
    },
    confirmFeedback(){
      this.showFeedback=false
      apiFeedbackInformation({feedbackDescription:this.feedbackDescription}).then((res) => {
        if(res.code == 200){
          this.feedbackDescription=''
          this.$toast.success()
        }else{
          this.feedbackDescription=''
          this.$toast.success(this.$t(res.msg))

        }
      })
    }
  },
};
</script>

<style lang="scss" scoped>
.header {
  position: relative;
  .header-flex {
    height: 99px;
    background: #273458;
    padding: 15px 30px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-sizing: border-box;
    .header-lf {
      font-size: 50px;
      font-weight: 800;
      color: #ffffff;
    }
    .header-rg {
      display: flex;
      align-items: center;
      .lang-box {
        display: flex;
        align-items: center;
        margin-right: 46px;
      }
      .lang-title {
        font-size: 29px;
        font-weight: 400;
        color: #ffffff;
        margin-right: 11px;
      }
      .bottom-icon-img {
        width: 18.22px;
        height: auto;
      }
      .area-box {
        display: flex;
        align-items: center;
      }
      .area-icon-img {
        width: 48px;
        height: 48px;
        margin-right: 8px;
      }
      .area-title {
        font-size: 28px;
        font-weight: 400;
        color: #ffffff;
      }
      .screen-box {
        display: flex;
        align-items: center;
      }
      .screen-icon-img {
        width: 48px;
        height: 48px;
        margin-left: 5vw;
      }
    }
  }
  .lang-popup-box {
    position: absolute;
    width: 289px;
    height: 248px;
    background: #ffffff;
    z-index: 1;
    left: 40%;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
  }
  .lang-item {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: left;
    font-size: 26px;
    font-weight: 400;
    color: #000000;
    box-sizing: border-box;
    border-bottom: 1px solid #d5d5d5;
  }
  .lang-item:last-child {
    border-bottom: none;
  }
  .country-popup-box {
    position: absolute;
    width: 289px;
    height: 325px;
    background: #ffffff;
    z-index: 1;
    box-sizing: border-box;
    right: 10px;
    display: flex;
    flex-direction: column;
  }
  .country-item {
    display: flex;
    flex: 1;
    align-items: center;
    justify-content: left;
    font-size: 26px;
    font-weight: 400;
    color: #000000;
    box-sizing: border-box;
    border-bottom: 1px solid #d5d5d5;
    .muen-icon-img{
      width: 48px;
      height: 48px;
      margin-left: 10px;
      margin-right: 18px;
    }
  }
  .country-item:last-child {
    border-bottom: none;
  }
}
// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
    .muen-icon-img{
      width: 35px;
      height: 35px;
      margin-right: 10px;
    }
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }

  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 150px;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }
  .content-Agreement{
    margin: 5px 5px;
    padding: 15px;
    height: 800px;
    overflow-y: auto;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }
  .content-Feedback{
    margin: 21px 35px;
    padding: 15px;
    height: 400px;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }
  .contact-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 210px;
    font-size: 24px;
    float: left;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
p{
  font-weight: bold;
}
</style>
