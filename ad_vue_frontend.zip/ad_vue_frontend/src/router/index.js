import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/home/index.vue'
import {apiRecordVisitorViewTime} from '../request/api'


Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: "/detail",
    name: "detail",
    component: () => import("../views/home/detail.vue"),
  },
  // 登录
  {
    path: "/login",
    name: "login",
    component: () => import("../views/login/login.vue"),
  },
  {
    path: "/register",
    name: "register",
    component: () => import("../views/login/register.vue"),
  },
  {
    path: "/forget",
    name: "forget",
    component: () => import("../views/login/forget.vue"),
  },
  // vip
  {
    path: "/vip",
    name: "vip",
    component: () => import("../views/vip/index.vue"),
  },
  {
    path: "/vipDetails",
    name: "vipDetails",
    component: () => import("../views/vip/vipDetails.vue"),
  },
  // postAD
  {
    path: "/postAd",
    name: "postAd",
    component: () => import("../views/postAd/index.vue"),
  },
  //myAD
  {
    path: "/myAD",
    name: "myAD",
    component: () => import("../views/myAD/index.vue"),
  },
  //buy AD time
  {
    path: "/buyadtime",
    name: "buyadtime",
    component: () => import("../views/myAD/buyadtime.vue"),
  },
    //replace AD img
    {
      path: "/replace",
      name: "replace",
      component: () => import("../views/myAD/replace.vue"),
    },
  //upgrade AD type
  {
    path: "/upgrade",
    name: "upgrade",
    component: () => import("../views/myAD/upgrade.vue"),
  },
  // personal
  {
    path: "/personal",
    name: "personal",
    component: () => import("../views/personal/index.vue"),
  },
  {
    path: "/recharge",
    name: "recharge",
    component: () => import("../views/personal/recharge.vue"),
  },
  {
    path: "/changeMail",
    name: "changeMail",
    component: () => import("../views/personal/changeMail.vue"),
  },
  {
    path: "/changePassword",
    name: "changePassword",
    component: () => import("../views/personal/changePassword.vue"),
  },
  {
    path: "/demo",
    name: "demo",
    component: () => import("../views/personal/demo.vue"),
  },
  {
    path: "/403",
    name: "403",
    component: () => import("../views/error/403.vue"),
  },
  {
    path: "/realpersonverify",
    name: "realpersonverify",
    component:()=>import("../views/myAD/RealPersonVerify.vue")
  }

]

const router = new VueRouter({
  mode: 'history',
  // base: '/h5/',
  routes
})

export default router

window.pageViewStartTime = null;
router.beforeEach((to, from, next) => {
   if (from.name && window.pageViewStartTime) {
      const pageViewTime = new Date() - window.pageViewStartTime;
      console.log(`Page view time for ${from.name}: ${pageViewTime}ms`);
      apiRecordVisitorViewTime({
        userId:localStorage.getItem("userId"),
        pageName:from.name,
        viewTimeLong:pageViewTime
      }).then(res=>{
        console.log(res.code);
      })
   }
   window.pageViewStartTime = new Date();
   next();
});
// window.addEventListen('unload', () => {
//  if (window.pageViewStartTime) {
//     const pageViewTime = new Date() - window.pageViewStartTime;
//     console.log(`Page view time for ${from.name}: ${pageViewTime}ms`);
//  }
// })
