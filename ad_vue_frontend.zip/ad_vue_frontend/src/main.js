import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Vant from 'vant';
import 'vant/lib/index.css';
import "./assets/css/index.css";
import VueI18n from "vue-i18n";
import { zhEn } from "./assets/i18n/zhEn";
import VueClipboard from 'vue-clipboard2'
import { Locale } from 'vant';
import enUS from 'vant/es/locale/lang/en-US';
import zhCN from 'vant/es/locale/lang/zh-CN';
import './assets/iconfont/iconfont.css'
import axios from 'axios'
import "lib-flexible/flexible";
import "swiper/css/swiper.css";
import VueTouch from "vue-touch";
import ElementUI from 'element-ui';
import locale from 'element-ui/lib/locale/lang/en'
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI, { locale });
Vue.use(VueTouch, { name: "v-touch" });
Vue.prototype.$axios = axios
Vue.use(VueClipboard)
Vue.config.productionTip = false
Vue.use(Vant);
Vue.use(VueI18n);

const lang = localStorage.getItem("i18n_lang");
const i18n = new VueI18n({
  // 默认使用语言，this.$i18n.locale
  locale: lang || "zh-en",
  //报错时加上这个参数可以取消警告
  silentTranslationWarn: true,
  messages: {
    "zh-en": zhEn, //英语
  }
});

if (lang) {
  if (lang == "zh-en") {
    Locale.use("en-US", enUS);
  } else {
    Locale.use("zh-CN", zhCN);
  }
} else {
  Locale.use("en-US", enUS);
}

new Vue({
  router,
  i18n,
  store,
  render: h => h(App)
}).$mount('#app')



const express = require('express')
const app = express()
const port = 3000

app.get('/testhook', (req, res) => {
  res.send('Hello World!')
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

