<template>
  <div class="page">
    <titleBar></titleBar>
    <div class="content">
      <div class="swiper-img-box">
        <van-swipe
          class="my-swipe"
          :autoplay="3000"
          indicator-color="#232f3e"
          :loop="false"
        >
          <van-swipe-item>
            <img
              class="swipe-item-img"
              src="../../assets/images/home/home.png"
              alt=""
            />
          </van-swipe-item>
          <!-- <van-swipe-item v-for="item in rotationList" :key="item.id"
            ><img class="swipe-item-img" :src="item.images" alt=""
          /></van-swipe-item> -->
        </van-swipe>
      </div>
      <!-- <div class="swiper-menu-imgBox">
            <img class="swiper-menu-img" src="" alt="" />
      </div> -->
      <!-- <div class="swiper-menu-box">
        <div
          class="swiper-menu-item"
          :class="{ activeClassificationBg: checked == item.dictValue }"
          v-for="item in classificationList"
          :key="item.dictValue"
          @click="checkClassification(item)"
        >
          <div class="swiper-menu-p-box">
            <div class="swiper-menu-p">{{ item.dictLabel }}</div>
          </div>
          <div class="swiper-menu-imgBox">
            <img class="swiper-menu-img" :src="item.images" alt="" />
          </div>
        </div>
      </div> -->
      <div class="location-box">
        <div class="area-flex-box" @click="showLocationBox = !showLocationBox">
          <div class="area-box-lf">
            {{ country }}
            {{ cityName ? '/' + cityName : '' }}
          </div>
          <div class="area-box-rg">
            <img
              class="bottom-icon-bl-img"
              src="../../assets/images/home/bottom-icon-bl.png"
              alt=""
            />
          </div>
        </div>

        <van-popup
          v-model="showLocationBox"
          style="height: 80%"
          position="bottom"
          :lock-scroll="false"
        >
          <div
            style="
              text-align: center;
              margin-bottom: 5px;
              margin-top: 5px;
              font-size: large;
              background-color: #273458;
              color: #fff;
              height: 5%;
              line-height: initial;
              font-weight: 600;
            "
            @click="reset()"
          >
            Reset
          </div>

          <div
            class="flexBox-lf1"
            style="margin-top: 20px; margin-bottom: 20px"
          >
            <div style="border-bottom: 1px solid">
              <van-field
                type="textarea"
                class="city-ipt"
                v-model="street_info"
                placeholder="street Information"
                style="
                  height: 100%;
                  margin-right: 10px;
                  border-top-width: 0px;
                  border-right-width: 0px;
                  border-bottom-width: 1px;
                  border-left-width: 0px;
                  font: initial;
                "
                @input="streetInfoChange()"
              />
            </div>
            <div style="border-bottom: 1px solid; width: 25%">
              <van-field
                type="textarea"
                class="city-ipt"
                v-model="user_input_city_name"
                placeholder="city"
                style="
                  height: 100%;
                  margin-right: 10px;
                  border-top-width: 0px;
                  border-right-width: 0px;
                  border-bottom-width: 1px;
                  border-left-width: 0px;
                  font: initial;
                "
                @input="streetInfoChange()"
              />
            </div>

            <van-button
              size="normal"
              :disabled="streetInfoStatus"
              style="
                height: 100%;
                margin-left: 5px;
                background-color: #f2f15f;
                color: black;
              "
              @click="getNearBys"
              >Confirm</van-button
            >
          </div>

          <div class="big-line"></div>

          <van-cascader
            :closeable="false"
            v-model="cityName"
            title="Please select your region"
            active-color="#0000FF"
            swipeable="true"
            placeholder="Please select"
            @finish="onFinish"
            :options="stateList"
            @close="closeCascader"
            :field-names="fieldNames"
          />
        </van-popup>
        <!-- 下拉选择框 -->
        <!-- <div class="location-select-box" v-if="showLocationBox">
          <div class="search-box">
            <van-field
              class="location-ipt"
              v-model="searchWord"
              right-icon="warning-o"
              placeholder="State of California"
            >
              <template #right-icon>
                <img
                  class="search-icon"
                  src="../../assets/images/home/search-icon.png"
                  @click="searchClick"
                  alt=""
                />
              </template>
            </van-field>
          </div>
          <div class="location-list">
            <div class="location-state" v-if="showStateBox">
              <div class="location-list-box">
                <van-radio-group v-model="city">
                  <van-cell-group>
                    <van-cell
                      class="state-cell"
                      v-for="item in stateList"
                      clickable
                      :key="item.cityId"
                      :title="item.cityName"
                    >
                      <template #right-icon>
                        <span style="margin-right: 30px;">{{item.advertisementNumber}}</span>
                        <van-radio
                          icon-size="20px"
                          shape="square"
                          checked-color="#273458"
                          :name="item.cityId"
                          @click="handleCity(item)"
                        />
                      </template>
                    </van-cell>
                  </van-cell-group>
                </van-radio-group>
              </div>
            </div>
          </div>
        </div> -->
      </div>
      <div class="detail-box">
        <div class="type-box">
          <div class="all-type-box">
            <div class="type">
              <div
                class="type-text"
                :class="{ activeTypeBg: !isAll }"
                @click="handleRecommend"
              >
                Recommend
              </div>
              <div
                class="type-text"
                :class="{ activeTypeBg: isAll }"
                @click="handleAll"
              >
                All ads
              </div>
            </div>
            <!-- <div class="screen" v-if="isAll" @click="showRightPopup">
              <img
                class="screen-img"
                src="../../assets/images/home/home-screen.png"
                alt=""
              />
            </div> -->
          </div>

          <div
            class="type-info"
            v-if="advertisementCountData.advertisementNumber > 0"
          >
            {{ advertisementCountData.advertisementNumber }} ads in
            {{ advertisementCountData.cityName }}
          </div>
        </div>
        <!--推荐部分 -->
        <div v-if="!isAll">
          <div
            class="recommend-box-item"
            v-for="item in recommendList"
            :key="item.advertisementId"
            @click="Goto_detail(item.advertisementId)"
          >
            <div class="recommend-img-box">
              <div class="recommend-img-lf">
                <img
                  v-if="item.verify == 'success'"
                  style="
                    width: 60%;
                    height: auto;
                    position: absolute;
                    top: 1px;
                    left: 1px;
                  "
                  src="../../assets/images/myAds/verified.png"
                />
                <img :src="item.recommendImageOne" alt="" />
              </div>

              <div class="recommend-img-rg">
                <div class="recommend-img-rg-top">
                  <img :src="item.recommendImageTwo" alt="" />
                </div>
                <div class="recommend-img-rg-bottom">
                  <img :src="item.recommendImageThree" alt="" />
                </div>
              </div>
            </div>
            <div class="recommend-info-box">
              <div class="recommend-info-lf">
                <div class="info-lf-title">
                  {{ item.race }}/{{ item.occupation }}
                </div>
                <div>
                  <span class="info-lf-text">{{ item.advertisementName }}</span>
                  <span class="info-lf-text">{{ item.age }}</span>
                  <span
                    class="info-lf-text"
                    v-if="item.miles != 0 && item.miles != 9999.99"
                    >{{ item.miles }}mi</span
                  >
                </div>
              </div>
              <div
                class="recommend-info-rg"
                @click.stop="showContactPopup(item.phoneNumber)"
              >
                <img src="../../assets/images/home/phone.png" alt="" />
              </div>
            </div>
          </div>
          <div class="pagination" style="text-align: center">
            <el-pagination
              background
              layout="total, sizes, prev, pager, next, jumper"
              :current-page="recommendTablePage.pageNum"
              :page-size="recommendTablePage.pageSize"
              :page-sizes="recommendPageSizes"
              :total="recommendTablePage.total"
              @size-change="handleSizeChange"
              @current-change="handlePageChange"
              :key="recommendCurrentPage"
            />
          </div>

          <!-- <div
            id="recaptchaDivRecommend"
            :style="{ display: showRecaptcha == true ? '' : 'none' }"
            >
            <div
              class="g-recaptcha"
              :data-sitekey="recaptchaSiteKey"
              data-callback="onRecaptchaCallback"
            ></div>
          </div> -->

          <div
            id="recaptchaDiv"
            :style="{ display: showRecaptcha == true ? 'flex' : 'none' }"
            style="flex-direction: column"
          >
            <img :src="codeUrl" @click="getCode" class="login-code-img" />
            <br />
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <van-field
                label="verify code :"
                clearable
                v-model="code"
                placeholder="Please enter the result"
              ></van-field>
              <br />

              <div class="confirm-btn" @click="verifyCode">Confirm</div>
            </div>
          </div>
        </div>
        <!-- 全部部分 -->
        <div v-if="isAll">
          <div v-for="(item, index) in allList" :key="index">
            <div
              v-if="item.largeALlList.length > 0"
              class="all-box-item"
              @click="Goto_detail(item.largeALlList[0].advertisementId)"
            >
              <div class="big-img-box" >
                <img
                  v-if="item.largeALlList[0].verify == 'success'"
                  style="
                    width: 60%;
                    height: auto;
                    position: absolute;
                    top: 1px;
                    left: 1px;
                  "
                  src="../../assets/images/myAds/verified.png"
                />
                <img :src="item.largeALlList[0].largeImage" alt="" />
              </div>
              <div class="all-img-info">
                <div class="all-img-info-title">
                  {{ item.largeALlList[0].advertisementName }}
                </div>
                <div class="all-img-info-text">
                  <!-- <span class="info-sp-text">
                    {{ item.largeALlList[0].race }}/{{item.largeALlList[0].occupation}}
                  </span> -->
                  <!-- <span>{{ item.largeALlList[0].advertisementName }}</span> -->
                  <span>{{ item.largeALlList[0].age }}</span>
                  <span
                    v-if="
                      item.largeALlList[0].miles != 0 &&
                      item.largeALlList[0].miles != 9999.99
                    "
                    >{{ item.largeALlList[0].miles }} mi</span
                  >
                </div>
              </div>
            </div>
            <div class="all-box-item" v-if="item.thumbnailALlList.length > 0">
              <div class="sm-box-item">
                <div
                  class="sm-box-item-lf"
                  @click="Goto_detail(item.thumbnailALlList[0].advertisementId)"
                  v-if="item.thumbnailALlList.length > 0"
                >
                  <div class="small-img-box">
                    <img
                      v-if="item.thumbnailALlList[0].verify == 'success'"
                      style="
                        width: 60%;
                        height: auto;
                        position: absolute;
                        top: 1px;
                        left: 1px;
                      "
                      src="../../assets/images/myAds/verified.png"
                    />
                    <img :src="item.thumbnailALlList[0].imagesOne" alt="" />
                  </div>
                  <div class="sm-box-text">
                    <!-- <span class="sm-box-sp-text">
                      {{ item.thumbnailALlList[0].race }}/{{item.thumbnailALlList[0].occupation}}
                    </span> -->
                    <span>{{
                      item.thumbnailALlList[0].advertisementName
                    }}</span>
                    <span>{{ item.thumbnailALlList[0].age }}</span>
                    <span
                      v-if="
                        item.thumbnailALlList[0].miles != 0 &&
                        item.thumbnailALlList[0].miles != 9999.99
                      "
                      >{{ item.thumbnailALlList[0].miles }} mi</span
                    >
                  </div>
                </div>
                <div
                  class="sm-box-item-rg"
                  @click="Goto_detail(item.thumbnailALlList[1].advertisementId)"
                  v-if="item.thumbnailALlList.length > 1"
                >
                  <div class="small-img-box">
                    <img
                      v-if="item.thumbnailALlList[1].verify == 'success'"
                      style="
                        width: 60%;
                        height: auto;
                        position: absolute;
                        top: 1px;
                        left: 1px;
                      "
                      src="../../assets/images/myAds/verified.png"
                    />
                    <img :src="item.thumbnailALlList[1].imagesOne" alt="" />
                  </div>
                  <div class="sm-box-text">
                    <!-- <span class="sm-box-sp-text">
                      {{ item.thumbnailALlList[1].race }}/{{item.thumbnailALlList[1].occupation}}
                    </span> -->
                    <span>{{
                      item.thumbnailALlList[1].advertisementName
                    }}</span>
                    <span>{{ item.thumbnailALlList[1].age }}</span>
                    <span
                      v-if="
                        item.thumbnailALlList[1].miles != 0 &&
                        item.thumbnailALlList[1].miles != 9999.99
                      "
                      >{{ item.thumbnailALlList[1].miles }} mi</span
                    >
                  </div>
                </div>
              </div>
            </div>

            <div class="all-box-item" v-if="item.thumbnailALlList.length > 2">
              <div class="sm-box-item">
                <div
                  v-if="item.thumbnailALlList.length > 2"
                  class="sm-box-item-lf"
                  @click="Goto_detail(item.thumbnailALlList[2].advertisementId)"
                >
                  <div class="small-img-box">
                    <img
                      v-if="item.thumbnailALlList[2].verify == 'success'"
                      style="
                        width: 60%;
                        height: auto;
                        position: absolute;
                        top: 1px;
                        left: 1px;
                      "
                      src="../../assets/images/myAds/verified.png"
                    />
                    <img :src="item.thumbnailALlList[2].imagesOne" alt="" />
                  </div>
                  <div class="sm-box-text">
                    <!-- <span class="sm-box-sp-text">
                      {{ item.thumbnailALlList[2].race }}/{{item.thumbnailALlList[2].occupation}}
                    </span> -->
                    <span>{{
                      item.thumbnailALlList[2].advertisementName
                    }}</span>
                    <span>{{ item.thumbnailALlList[2].age }}</span>
                    <span
                      v-if="
                        item.thumbnailALlList[2].miles != 0 &&
                        item.thumbnailALlList[2].miles != 9999.99
                      "
                      >{{ item.thumbnailALlList[2].miles }} mi</span
                    >
                  </div>
                </div>
                <div
                  v-if="item.thumbnailALlList.length > 3"
                  class="sm-box-item-rg"
                  @click="Goto_detail(item.thumbnailALlList[3].advertisementId)"
                >
                  <div class="small-img-box">
                    <img
                      v-if="item.thumbnailALlList[3].verify == 'success'"
                      style="
                        width: 60%;
                        height: auto;
                        position: absolute;
                        top: 1px;
                        left: 1px;
                      "
                      src="../../assets/images/myAds/verified.png"
                    />
                    <img :src="item.thumbnailALlList[3].imagesOne" alt="" />
                  </div>
                  <div class="sm-box-text">
                    <!-- <span class="sm-box-sp-text">
                      {{ item.thumbnailALlList[3].race }}/{{item.thumbnailALlList[3].occupation}}
                    </span> -->
                    <span>{{
                      item.thumbnailALlList[3].advertisementName
                    }}</span>
                    <span>{{ item.thumbnailALlList[3].age }}</span>
                    <span
                      v-if="
                        item.thumbnailALlList[3].miles != 0 &&
                        item.thumbnailALlList[3].miles != 9999.99
                      "
                      >{{ item.thumbnailALlList[3].miles }} mi</span
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="pagination" style="text-align: center">
            <el-pagination
              background
              layout="total, sizes, prev, pager, next, jumper"
              :current-page="allTablePage.pageNum"
              :page-size="allTablePage.pageSize"
              :page-sizes="allPageSizes"
              :total="allTablePage.total"
              @size-change="handleSizeChangeAllAd"
              @current-change="handlePageChangeAllAd"
              :key="allCurrentPage"
            />
          </div>

          <!-- <div
            id="recaptchaDivAll"
            :style="{ display: showRecaptcha == true ? '' : 'none' }"
            >
            <div
              class="g-recaptcha"
              :data-sitekey="recaptchaSiteKey"
              data-callback="onRecaptchaCallback"
            ></div>
          </div> -->

          <div
            id="recaptchaDiv"
            :style="{ display: showRecaptcha == true ? 'flex' : 'none' }"
            style="flex-direction: column"
          >
            <img :src="codeUrl" @click="getCode" class="login-code-img" />
            <br />
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <van-field
                label="verify code :"
                clearable
                v-model="code"
                placeholder="Please enter the result"
              ></van-field>
              <br />

              <div class="confirm-btn" @click="verifyCode">Confirm</div>
            </div>
          </div>
        </div>
      </div>
      <!-- 右侧弹出层 -->
      <!-- <van-popup
        v-model="showRight"
        position="right"
        :style="{ width: '80%', height: '100%' }"
      >
        <div style="margin-top: 30px;margin-left:20px ;">
          <van-field name="Independent" label="Independent:" 
             label-width="110px"  style="font-size: 16px">
            <template #input>
              <van-radio-group
                v-model="advertisement.independent"
                direction="horizontal"
                style="font-size: 18px"
              >
                <van-radio
                  v-for="(item, index) in list4"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="width: 70px"
                  >{{ item.dictLabel }}</van-radio
                >
              </van-radio-group>
            </template>
          </van-field>
          <van-field name="provideService" style="margin-top: 10px;">
            <template #input>
              <van-radio-group
                v-model="advertisement.provideService"
                direction="horizontal"
                style="font-size: 16px"
              >
              <van-radio
                v-for="(item, index) in list3"
                :name="item.dictValue"
                :key="index"
                shape="square"
                checked-color="#273458"
                icon-size="20px"
                style="width: 100px"
                >{{ item.dictLabel }}</van-radio
              >
              </van-radio-group>
            </template>
          </van-field>
          <div style="margin-top: 20px">
              <div style="font-size: 19px; font-weight: 700; color: #273458">
                Available
              </div>
              <van-checkbox-group
                v-model="advertisement.available"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-checkbox
                  v-for="(item, index) in list2"
                  :name="item.dictValue+''"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="width: 90px;margin-top: 10px;"
                  >{{ item.dictLabel }}</van-checkbox
                >
              </van-checkbox-group>
          </div>
          <div style="margin-top: 20px">
              <div style="font-size: 19px; font-weight: 700; color: #273458">
                Provide
              </div>
              <van-checkbox-group
                v-model="advertisement.provide"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-checkbox
                  v-for="(item, index) in list1"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="width: 90px;margin-top: 10px;"
                  >{{ item.dictLabel }}</van-checkbox
                >
              </van-checkbox-group>
          </div>
            <div class="normal-person-iptBox">
              <div class="ipt-flexBox">
                <div class="flexBox" >
                  <div class="lang-box">
                    <div class="area-flex-box"
                      @click="
                      ; (showHeightBox        =	false),
                        (showWeightBox        =	false),
                        (showRaceBox          =	false),
                        (showGenderBox        =	false),
                        (showLanguageBox      =	false),
                        (showbreastSizeBox      =	false),
                        (showhairColorBox     =	false),
                        (showAgeBox           =	!showAgeBox),
                        (showOccupationBox    =	false),
                        (showRecommendSection =	false),
                        (showhairLengthBox    =	false),
                        (showeyeColorBox      =	false),
                        (showTravelBox        =	false)                  
                      "
                    >
                      <div class="area-box-lf">
                      {{ ageName }}
                      </div>
                      <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                      </div>
                    </div>
                    <div class="location-select-box" v-if="showAgeBox">
                      <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                        <van-radio-group v-model="advertisement.age">
                          <van-cell-group>
                          <van-cell
                            class="state-cell"
                            v-for="item in ageList"
                            label="Age"
                            clickable
                            :key="item.dictValue"
                            :title="item.dictLabel"
                            @click="chooseAge(item)"
                          >
                            <template #right-icon>
                            <van-radio
                              icon-size="20px"
                              shape="square"
                              checked-color="#273458"
                              :name="item.dictValue"
                            />
                            </template>
                          </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                        </div>
                      </div>
                      </div>
                    </div>
                  </div>
              </div>
              <div class="ipt-flexBox">
                <div class="flexBox" >
                  <div class="lang-box">
                    <div
                    class="area-flex-box"
                    @click="
                      ; (showHeightBox        =	false),
                        (showWeightBox        =	false),
                        (showRaceBox          =	false),
                        (showGenderBox        =	!showGenderBox),
                        (showLanguageBox      =	false),
                        (showbreastSizeBox      =	false),
                        (showhairColorBox     =	false),
                        (showAgeBox           =	false),
                        (showOccupationBox    =	false),
                        (showRecommendSection =	false),
                        (showhairLengthBox    =	false),
                        (showeyeColorBox      =	false),
                        (showTravelBox        =	false) 
                    "
                    >
                      <div class="area-box-lf">
                        {{ genderName }}
                      </div>
                      <div class="area-box-rg">
                        <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                        />
                      </div>
                    </div>
                    <div
                    class="location-select-box"
                    v-if="showGenderBox"
                    style="border: 1px solid #f4f4f4"
                    >
                    <div class="location-list">
                      <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="advertisement.gender">
                        <van-cell-group>
                          <van-cell
                          class="state-cell"
                          v-for="item in genderList"
                          clickable
                          :key="item.dictValue"
                          :title="item.dictLabel"
                          @click="chooseGender(item)"
                          >
                          <template #right-icon>
                            <van-radio
                            icon-size="20px"
                            shape="square"
                            checked-color="#273458"
                            :name="item.dictValue"
                            />
                          </template>
                          </van-cell>
                        </van-cell-group>
                        </van-radio-group>
                      </div>
                      </div>
                    </div>
                    </div>
                    </div>
                  </div>
                </div>
                     
            <div class="ipt-flexBox">
              <div class="flexBox">
              <div class="lang-box">
                <div
                class="area-flex-box"
                @click="
                  ; (showHeightBox        =	false),
                    (showWeightBox        =	false),
                    (showRaceBox          =	!showRaceBox),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	false),
                    (showhairColorBox     =	false),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	false),
                    (showeyeColorBox      =	false),
                    (showTravelBox        =	false) 
                "
                >
                <div class="area-box-lf">
                  {{raceName}}
                </div>
                <div class="area-box-rg">
                  <img
                  class="bottom-icon-bl-img"
                  src="../../assets/images/home/bottom-icon-bl.png"
                  alt=""
                  />
                </div>
                </div>
                <div class="location-select-box" v-if="showRaceBox">
                <div class="location-list">
                  <div class="location-state">
                  <div class="location-list-box">
                    <van-radio-group v-model="advertisement.race">
                    <van-cell-group>
                      <van-cell
                      class="state-cell"
                      v-for="item in raceList"
                      clickable
                      :key="item.dictValue"
                      :title="item.dictLabel"
                      @click="chooseRace(item)"
                      >
                      <template #right-icon>
                        <van-radio
                        icon-size="20px"
                        shape="square"
                        checked-color="#273458"
                        :name="item.dictValue"
                        />
                      </template>
                      </van-cell>
                    </van-cell-group>
                    </van-radio-group>
                  </div>
                  </div>
                </div>
                </div>
              </div>
            </div>

            <div class="flexBox">
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ; (showHeightBox        =	false),
                    (showWeightBox        =	false),
                    (showRaceBox          =	false),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	!showbreastSizeBox),
                    (showhairColorBox     =	false),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	false),
                    (showeyeColorBox      =	false),
                    (showTravelBox        =	false) 
                    "
                  >
                    <div class="area-box-lf">
                      {{ breastSizeName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>

                  <div class="location-select-box" v-if="showbreastSizeBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="advertisement.breastSize">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in breastSizeList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseBreastSize(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="ipt-flexBox">
              <div class="flexBox" >
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ; (showHeightBox        =	false),
                    (showWeightBox        =	!showWeightBox),
                    (showRaceBox          =	false),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	false),
                    (showhairColorBox     =	false),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	false),
                    (showeyeColorBox      =	false),
                    (showTravelBox        =	false) 
                    "
                  >
                    <div class="area-box-lf">
                      {{ weightName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="location-select-box" v-if="showWeightBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="advertisement.weight">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in weightList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseWeight(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="flexBox" >
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ; (showHeightBox        =	!showHeightBox),
                    (showWeightBox        =	false),
                    (showRaceBox          =	false),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	false),
                    (showhairColorBox     =	false),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	false),
                    (showeyeColorBox      =	false),
                    (showTravelBox        =	false) 
                    "
                  >
                    <div class="area-box-lf">
                      {{ heightName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="location-select-box" v-if="showHeightBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="advertisement.height">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in heightList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseHeight(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
          <div class="ipt-flexBox">
            <div class="flexBox" >
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ; (showHeightBox        =	false),
                    (showWeightBox        =	false),
                    (showRaceBox          =	false),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	false),
                    (showhairColorBox     =	!showhairColorBox),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	false),
                    (showeyeColorBox      =	false),
                    (showTravelBox        =	false) 
                  "
                >
                  <div class="area-box-lf">
                    {{ hairColorName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showhairColorBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="advertisement.hairColor">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in hairColorList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseHairColor(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="flexBox" >
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ; (showHeightBox        =	false),
                    (showWeightBox        =	false),
                    (showRaceBox          =	false),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	false),
                    (showhairColorBox     =	false),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	!showhairLengthBox),
                    (showeyeColorBox      =	false),
                    (showTravelBox        =	false) 
                  "
                >
                  <div class="area-box-lf">
                    {{ hairLengthName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showhairLengthBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="advertisement.hairLength">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in hairLengthList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseHairLength(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
         </div>

         <div class="ipt-flexBox">
          <div class="flexBox" >
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ; (showHeightBox        =	false),
                    (showWeightBox        =	false),
                    (showRaceBox          =	false),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	false),
                    (showhairColorBox     =	false),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	false),
                    (showeyeColorBox      =	!showeyeColorBox),
                    (showTravelBox        =	false) 
                  "
                >
                  <div class="area-box-lf">
                    {{ eyeColorName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showeyeColorBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="advertisement.eyeColor">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in eyeColorList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseEyeColor(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="flexBox" >
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ; (showHeightBox        =	false),
                    (showWeightBox        =	false),
                    (showRaceBox          =	false),
                    (showGenderBox        =	false),
                    (showLanguageBox      =	false),
                    (showbreastSizeBox      =	false),
                    (showhairColorBox     =	false),
                    (showAgeBox           =	false),
                    (showOccupationBox    =	false),
                    (showRecommendSection =	false),
                    (showhairLengthBox    =	false),
                    (showeyeColorBox      =	false),
                    (showTravelBox        =	!showTravelBox) 
                  "
                >
                  <div class="area-box-lf">
                    {{ travelName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showTravelBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="advertisement.travel">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in travelList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseTravel(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
         </div>
            </div>
            </div>
          </div>
        </div>
        <div class="confirm-box">
          <van-button class="confirm-btn-le" @click="clickReset">Reset</van-button>
          <van-button class="confirm-btn-rg" @click="filterCriteria">Apply Filters</van-button>        
        </div>
      </van-popup> -->
      <!-- 获取位置弹窗 -->
      <van-popup v-model="showContact">
        <div class="popup-box">
          <div class="popup-head">phone number</div>
          <img
            @click="showContact = false"
            class="close-icon"
            src="../../assets/images/close-icon.png"
            alt=""
          />
          <div class="content">{{ phoneNumber }}</div>
          <div class="confirm-btn" @click="copyPhoneNumber">copy</div>
        </div>
      </van-popup>
    </div>

    <router-view />
    <van-tabbar route active-color="#027AFC" inactive-color="#666666">
      <van-tabbar-item replace to="/vip">
        <span> {{ $t('vip') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active1 : icon.inactive1" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/">
        <span> {{ $t('home') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active2 : icon.inactive2" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/postAd">
        <span> {{ $t('post AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active3 : icon.inactive3" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/myAD" v-if="tokenKey">
        <span> {{ $t('my AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active4 : icon.inactive4" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/personal" v-if="tokenKey">
        <span> {{ $t('Profile') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active5 : icon.inactive5" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
    <van-popup v-model="isDialog" :round="true">
      <div class="popup-box">
        <div class="content">
          Please authorize your location information for recommending the
          nearest ads.
        </div>
        <div class="contact-btn" @click="GetLocation">OK</div>
      </div>
    </van-popup>

    <van-popup
      v-model="showstreetpopup"
      round
      position="bottom"
      :style="{ height: '65%' }"
    >
      <van-cell-group>
        <van-cell
          v-for="(item, index) in streetPopupList"
          center
          :key="index"
          style="
            margin-top: 5px;
            text-align: center;
            font-size: 17px;
            height: auto;
            line-height: 34px;
          "
          @click="choosepopupInfo(item)"
        >
          <template #title>
            <img
              width="20px"
              height="20px"
              src="../../assets/images/postAd/position.png"
            />
            {{ item }}
          </template>
          <template #right-icon>
            <van-checkbox checked-color="#273458" icon-size="20px" />
          </template>
        </van-cell>
      </van-cell-group>
    </van-popup>
  </div>
</template>

<script>
import router from '@/router'
import titleBar from '../../components/titleBar.vue'
import {
  apiAdvertisingClassification,
  apiGetRecommendList,
  apiGetAllList,
  apiOccupation,
  apiGetindependent,
  apiGetavailable_to,
  apiGetservlce_provided_as,
  apiGetselect_provide,
  apiRace,
  // apiRotationList,
  // apiGetAdvertisementCount,
  getUserLoc,
  getStateData,
  getCityDetails,
  getInvitationAddress,
  apiGetEyeColor,
  apiGettravel,
  apiGethai_length,
  apiGethai_color,
  apiGetheight,
  apiGetweight,
  apiGetage,
  apiGetgenderList,
  apiGetbreast_size,
  listCity,
  apiGetUserCityByIp,
  apiGetGoogleMapDetail,
  apiRecaptchaed,
  apiNeedToastGetLatLng,
  getCodeImg,
  apiVerifyCode,
} from '../../request/api'
export default {
  name: 'Home',
  components: { titleBar },
  data() {
    return {
      street_info: '',
      streetInfoStatus: true,
      streetPopupList: [],
      showstreetpopup: false,
      active: 0,
      icon: {
        active1: require('../../assets/images/tabbar/tabbar1.png'),
        inactive1: require('../../assets/images/tabbar/tabbar2.png'),
        active2: require('../../assets/images/tabbar/tabbar3.png'),
        inactive2: require('../../assets/images/tabbar/tabbar4.png'),
        active3: require('../../assets/images/tabbar/tabbar5.png'),
        inactive3: require('../../assets/images/tabbar/tabbar6.png'),
        active4: require('../../assets/images/tabbar/tabbar7.png'),
        inactive4: require('../../assets/images/tabbar/tabbar8.png'),
        active5: require('../../assets/images/tabbar/tabbar9.png'),
        inactive5: require('../../assets/images/tabbar/tabbar10.png'),
      },
      isDialog: false,
      isAll: false,
      // lang: "EN",
      country: 'USA',
      showLocationBox: false,
      searchWord: '',
      state: '',
      showStateBox: true,
      token: '',
      // 分类列表
      classificationList: [],
      checked: '',
      // 列表参数
      city: '',
      cityName: '',
      stateId: '',
      category: '0',
      miles: 0,
      // race: [],
      occupation: [],
      // 推荐列表
      recommendList: [],
      // 所有广告列表
      allList: [],
      stateList: [],
      advertisement: {
        independent: '',
        provideService: '',
        available: [],
        provide: [],
        age: '',
        gender: '',
        race: '',
        breastSize: '',
        weight: '',
        hairColor: '',
        hairLength: '',
        travel: '',
      },
      // 电话控制
      showContact: false,
      phoneNumber: '',
      // 右侧弹出层
      showRight: false,
      // 种族列表
      raceList: [],
      // 职业列表
      occupationList: [],
      raceName: 'Ethnicity',
      showRaceBox: false,
      showOccupationBox: false,
      // 轮播列表
      rotationList: [],
      // 获取当前城市名称与广告总数
      advertisementCountData: {},
      // 地址树形数据获取
      deptTreeList: [],
      activeName: '',
      cityResult: [],
      tokenKey: localStorage.getItem('key'),
      userPosition: {
        lat: null,
        lng: null,
      },
      options: {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0,
      },
      list1: [],
      list2: [],
      list3: [],
      list4: [],
      ageList: [],
      showAgeBox: false,
      ageName: 'Age',

      genderList: [],
      showGenderBox: false,
      genderName: 'Gender',

      breastSizeList: [],
      showbreastSizeBox: false,
      breastSizeName: 'breast size',

      weightList: [],
      showWeightBox: false,
      weightName: 'weight',

      heightList: [],
      showHeightBox: false,
      heightName: 'height',

      hairColorList: [],
      showhairColorBox: false,
      hairColorName: 'Hair Color',

      hairLengthList: [],
      showhairLengthBox: false,
      hairLengthName: 'Hair Length',

      // eyeColorList: [],
      showeyeColorBox: false,
      eyeColor: '',
      eyeColorName: 'Eye Color',

      travelList: [],
      showTravelBox: false,
      travelName: 'Travel',
      fieldNames: {
        text: 'cityAdNumStr',
        value: 'cityName',
        children: 'children',
      },
      latLng: '',

      recommendTablePage: {
        pageNum: 1, // 第几页
        pageSize: 25, // 每页多少条
        total: 0, // 总记录数
      },
      allTablePage: {
        pageNum: 1, // 第几页
        pageSize: 8, // 每页多少条
        total: 0, // 总记录数
      },

      recommendPageSizes: [25],
      allPageSizes: [8],

      // toastGetLocTimes: 0,

      recommendCurrentPage: 1,
      allCurrentPage: 1,

      nowCityName: '',
      user_input_city_name: '',
      search_by_street: '0',

      showRecaptcha: false,
      recaptchaSiteKey: '6LcAO0ooAAAAANLDgssJDvE_auLZG1ao9xm7cJne', // Replace with your site key
      recaptchaResponse: null,

      code: '',
      codeUrl: '',
      uuid: '',
    }
  },
  created() {
    //详情页返回所带参数
    let isAll = this.$route.query.isAll
    if (isAll != undefined) {
      this.isAll = this.$route.query.isAll == 'true'
      if (this.isAll) {
        this.allCurrentPage = Number(this.$route.query.allCurrentPage)
        this.allTablePage.pageNum = this.allCurrentPage
      } else {
        this.recommendCurrentPage = Number(
          this.$route.query.recommendCurrentPage
        )
        this.recommendTablePage.pageNum = this.recommendCurrentPage
      }

      this.city = Number(this.$route.query.city)
      this.search_street = this.$route.query.search_street
      this.search_city = this.$route.query.search_city
      this.search_by_street = this.$route.query.search_by_street

      this.latLng = this.$route.query.latLng
      localStorage.setItem('adlatlng', this.latLng)
    }

    if (this.city != '') {
      if (this.isAll) {
        this.handlePageChangeAllAd(this.allCurrentPage)
      } else {
        this.handlePageChange(this.recommendCurrentPage)
      }
    } else {
      apiGetUserCityByIp()
        .then((res) => {
          if (res.code == 200) {
            this.city = res.data.cityId
            console.log('cityInfo', res.data.cityName)
          } else {
            //默认洛杉矶
            this.city = 1733
          }
        })
        .then(() => {
          //设置城市信息，并查询AD
          let latLngTmp = localStorage.getItem('adlatlng')
          if (latLngTmp != null) {
            this.GetLocation()
          } else {
            this.getRecommendList()
            this.getAllList()
          }

          setTimeout(() => {
            if (localStorage.getItem('adlatlng') == null) {
              apiNeedToastGetLatLng().then((res) => {
                if (res.code == 200) {
                  this.isDialog = true
                }
              })

              // this.toastGetLocTimes=this.toastGetLocTimes+1
              // localStorage.setItem("toastGetLocTimes",this.toastGetLocTimes)
            }
          }, 10000)
        })
    }

    // apiGetbreast_size().then((res) => {
    //   if (res.code === 200) {
    //     this.breastSizeList = res.data;
    //   }
    // });
    // apiGetgenderList().then((res) => {
    //   if (res.code === 200) {
    //     this.genderList = res.data;
    //   }
    // });
    // apiGetage().then((res) => {
    //   if (res.code === 200) {
    //     this.ageList = res.data;
    //   }
    // });
    // apiGetweight().then((res) => {
    //   if (res.code === 200) {
    //     this.weightList = res.data;
    //   }
    // });
    // apiGetheight().then((res) => {
    //   if (res.code === 200) {
    //     this.heightList = res.data;
    //   }
    // });
    // apiGethai_color().then((res) => {
    //   if (res.code === 200) {
    //     this.hairColorList = res.data;
    //   }
    // });
    // apiGethai_length().then((res) => {
    //   if (res.code === 200) {
    //     this.hairLengthList = res.data;
    //   }
    // });
    // apiGettravel().then((res) => {
    //   if (res.code === 200) {
    //     this.travelList = res.data;
    //   }
    // });
    // apiGetEyeColor().then((res) => {
    //   if (res.code === 200) {
    //     this.eyeColorList = res.data;
    //   }
    // });
    // apiGetselect_provide().then((res) => {
    //   if (res.code === 200) {
    //     this.list1 = res.data;
    //   }
    // });
    // apiGetavailable_to().then((res) => {
    //   if (res.code === 200) {
    //     this.list2 = res.data;
    //   }
    // });
    // apiGetindependent().then((res) => {
    //   if (res.code === 200) {
    //     this.list4 = res.data;
    //   }
    // });
    // apiGetservlce_provided_as().then((res) => {
    //   if (res.code === 200) {
    //     this.list3 = res.data;
    //   }
    // });
    const queryString = window.location.search
    const urlParams = new URLSearchParams(queryString)
    var code = urlParams.get('invitationCode')
    code=code.substring(0,code.indexOf(' '))
    if (code != null) {
      getInvitationAddress({ invitationCode: code }).then((res) => {
        if (res.code != 200) {
          this.$toast.fail(res.msg)
        }
      })
    }

    // 分类字典数据获取
    apiAdvertisingClassification().then((res) => {
      if (res.code == 200) {
        this.classificationList = res.data
        this.classificationList = this.classificationList.filter(
          (x) =>
            x.dictValue !== '3' && x.dictValue !== '8' && x.dictValue !== '6'
        )
        console.log('分类字典数据获取', this.classificationList)
      }
    })
    apiOccupation().then((res) => {
      if (res.code == 200) {
        this.occupationList = res.data
      }
    })
    apiRace().then((res) => {
      if (res.code == 200) {
        this.raceList = res.data
      }
    })
    // 轮播接口
    // apiRotationList().then((res) => {
    //   if (res.code == 200) {
    //     this.rotationList = res.rows;
    //     console.log("轮播接口 ", res);
    //   }
    // });
    // 获取当前城市名称与广告总数
    // this.getAdvertisementCount();

    // 地址树形数据获取
    // 地址树形数据获取
    listCity({ webpage: 'home' }).then((res) => {
      if (res.code == 200) {
        this.stateList = res.data
        // this.stateList.forEach((item) => {
        //   item.cityAdNumStr=item.cityName
        //   item.children.forEach((itemChild) => {
        //     var itemCityNameLen = itemChild.cityName.length;
        //     if (itemCityNameLen < 60) {
        //       itemChild.cityAdNumStr = itemChild.cityName.replace(' ','').padEnd(50, '\u0020');
        //     }
        //     itemChild.cityAdNumStr = itemChild.cityAdNumStr + itemChild.advertisementNumber;
        //   });
        // });
      }
    })

    this.checked = 0
  },
  mounted() {
    window['onRecaptchaCallback'] = (response) => {
      this.onRecaptchaCallback(response)
    }

    // setTimeout(() => {
    //   if(this.showRecaptcha==true){
    //     //添加recaptcha JS
    //       var recaptchaDiv = document.getElementById("recaptchaDiv");
    //       const scriptDom = document.createElement("script");
    //       scriptDom.src ="https://www.google.com/recaptcha/api.js";
    //       recaptchaDiv.appendChild(scriptDom);
    //   }
    // }, 2000);
  },
  methods: {
    goBack() {
      this.$router.go(-1)
    },
    verifyCode() {
      apiVerifyCode({
        code: this.code,
        uuid: this.uuid,
      }).then((res) => {
        if (res.code == 200) {
          console.log('recaptcha ok')
          location.reload()
        } else {
          Toast.fail('verify error,please try again')
          this.getCode()
        }
      })
    },
    getCode() {
      getCodeImg().then((res) => {
        this.captchaEnabled =
          res.captchaEnabled === undefined ? true : res.captchaEnabled
        if (this.captchaEnabled) {
          this.codeUrl = 'data:image/gif;base64,' + res.img
          this.uuid = res.uuid
        }
      })
    },
    onRecaptchaCallback(response) {
      this.recaptchaResponse = response
      this.showRecaptcha = false

      apiRecaptchaed().then(() => {
        console.log('recaptcha ok')
        location.reload()
      })
    },
    // filterCriteria(){
    //   this.showRight=false
    //   apiGetAllList({
    //     city: this.city,
    //     category: this.category,
    //     miles: this.miles,
    //     race: this.race,
    //     occupation: this.occupation.join(','),
    //     latLng:this.latLng,
    //     pageNumAd: this.allTablePage.pageNum,
    //     pageSizeAd: this.allTablePage.pageSize
    //   }).then((res) => {
    //     if (res.code == 200) {
    //       console.log(res.rows,'allList')
    //       this.allList = res.rows
    //       this.showRight = false
    //       this.allTablePage.total=res.total
    //     }
    //   })
    // },
    // clickReset(){
    //   this.advertisement={
    //     independent:"",
    //     provideService:"",
    //     available:[],
    //     provide:[],
    //     age:"",
    //     gender:'',
    //     race:"",
    //     breastSize:"",
    //     weight: '',
    //     hairColor: '',
    //     hairLength: '',
    //     travel: ''
    //   }
    //   this.ageName ='Age'
    //   this.genderName = 'Gender'
    //   this.breastSizeName = 'breast size'
    //   this.weightName = 'weight'
    //   this.heightName = 'height'
    //   this.hairColorName = 'Hair Color'
    //   this.hairLengthName = 'Hair Length'
    //   this.eyeColorName = 'Eye Color'
    //   this.travelName = 'Travel'
    // },
    streetInfoChange() {
      var isStreetInfoValue = Boolean(this.street_info)
      var isInputCityNameValue = Boolean(this.user_input_city_name)
      if (isStreetInfoValue && isInputCityNameValue) {
        this.streetInfoStatus = false
      } else {
        this.streetInfoStatus = true
        this.isConfirmStreetInfo = false
      }
    },
    choosepopupInfo(item) {
      this.street_info = ''
      this.street_info = item
      this.showstreetpopup = false
      this.showLocationBox = false

      //设置按照街道信息查询标志位
      this.search_by_street = '1'

      //调用查询接口
      this.recommendTablePage.pageNum = 1
      this.recommendTablePage.pageSize = 25
      this.getRecommendList()

      this.allTablePage.pageNum = 1
      this.allTablePage.pageSize = 8
      this.getAllList()
    },
    reset() {
      this.cityName = ''
      ////默认城市为用户当前城市，并查询数据
      apiGetUserCityByIp()
        .then((res) => {
          if (res.code == 200) {
            this.city = res.data.cityId
            console.log('cityInfo', res.data.cityName)
          } else {
            //默认洛杉矶
            this.city = 1733
          }
        })
        .then(() => {
          this.GetLocation()
        })
        .then(() => {
          this.showLocationBox = false
        })
    },
    getNearBys() {
      apiGetGoogleMapDetail({
        streetInfo: this.street_info,
        cityName: this.user_input_city_name,
      }).then((res) => {
        if (res.code === 200) {
          this.showstreetpopup = true
          this.streetPopupList = res.data
        }
      })
    },

    GetLocation() {
      //获取用户位置经纬度
      console.log('begin get lat lng')
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          this.success,
          this.error,
          this.options
        )
      } else {
        console.log('Genlocation is not supported by this browser')
      }
      this.isDialog = false
    },
    chooseTravel(item) {
      this.travel = item.dictValue
      this.travelName = item.dictLabel
      this.showTravelBox = false
    },
    chooseEyeColor(item) {
      this.eyeColor = item.dictValue
      this.eyeColorName = item.dictLabel
      this.showeyeColorBox = false
    },
    chooseHairLength(item) {
      this.hairLength = item.dictValue
      this.hairLengthName = item.dictLabel
      this.showhairLengthBox = false
    },
    chooseHairColor(item) {
      this.hairColor = item.dictValue
      this.hairColorName = item.dictLabel
      this.showhairColorBox = false
    },
    chooseHeight(item) {
      this.height = item.dictValue
      this.heightName = item.dictLabel
      this.showHeightBox = false
    },
    chooseWeight(item) {
      this.weight = item.dictValue
      this.weightName = item.dictLabel
      this.showWeightBox = false
    },
    chooseBreastSize(item) {
      this.breastSize = item.dictValue
      this.breastSizeName = item.dictLabel
      this.showbreastSizeBox = false
    },
    // 选择职业
    chooseRace(item) {
      this.race = item.dictValue
      this.raceName = item.dictLabel
      this.showRaceBox = false
    },
    //选择性别
    chooseGender(item) {
      this.gender = item.dictValue
      this.genderName = item.dictLabel
      this.showGenderBox = false
    },
    chooseAge(item) {
      this.age = item.dictValue
      this.ageName = item.dictLabel
      this.showAgeBox = false
    },
    // 选择州
    closeCascader() {
      this.showLocationBox = false
    },
    onFinish(selectedOptions) {
      console.log('selectedOptions', selectedOptions)
      this.showLocationBox = false
      this.cityName =
        selectedOptions.selectedOptions[1].parentName +
        '/' +
        selectedOptions.selectedOptions[1].cityName

      this.search_by_street = '0'

      //设置城市信息，并查询AD
      this.city = selectedOptions.selectedOptions[1].cityId
      this.recommendTablePage.pageNum = 1
      this.recommendTablePage.pageSize = 25
      this.getRecommendList()

      this.allTablePage.pageNum = 1
      this.allTablePage.pageSize = 8
      this.getAllList()
    },
    // 选择城市
    handleCity(item) {
      this.cityName = item.cityName
      getCityDetails({
        cityId: item.cityId,
      }).then((res) => {
        if (res.code == 200) {
          this.advertisementCountData = res.data
        }
      })
      this.showLocationBox = false
    },
    // 选择分类
    checkClassification(item) {
      this.checked = item.dictValue
      this.category = item.dictValue
      if (this.isAll) {
        this.getAllList()
      } else {
        this.getRecommendList()
      }
    },
    // 点击推荐
    handleRecommend() {
      this.isAll = false
      this.getRecommendList()
    },
    // 点击全部
    handleAll() {
      this.isAll = true
      this.getAllList()
    },
    // 请求推荐列表
    getRecommendList() {
      console.log(this.category, ' this.category')
      apiGetRecommendList({
        city: this.city,
        category: this.category,
        miles: this.miles,
        latLng: this.latLng,
        pageNumAd: this.recommendTablePage.pageNum,
        pageSizeAd: this.recommendTablePage.pageSize,
        search_street: this.street_info,
        search_city: this.user_input_city_name, //未使用，仅作页面上匹配相关地点时使用
        search_by_street: this.search_by_street,
      }).then((res) => {
        console.log(res.rows, 'recommendList')
        if (res.code == 200) {
          this.recommendList = res.rows
          this.recommendTablePage.total = res.total
        } else if (res.code == 204) {
          //需要进行人机验证
          this.showRecaptcha = true
          this.getCode()

          this.recommendList = res.rows
          this.recommendTablePage.total = res.total

          // var recaptchaDiv = document.getElementById("recaptchaDivRecommend");
          // const scriptDom = document.createElement("script");
          // scriptDom.src = "https://www.google.com/recaptcha/api.js";
          // recaptchaDiv.appendChild(scriptDom);
        }
      })
    },
    getAllList() {
      apiGetAllList({
        city: this.city,
        category: this.category,
        miles: this.miles,
        race: this.race,
        occupation: this.occupation.join(','),
        latLng: this.latLng,
        pageNumAd: this.allTablePage.pageNum,
        pageSizeAd: this.allTablePage.pageSize,
        search_street: this.street_info,
        search_city: this.user_input_city_name, //未使用，仅作页面上匹配相关地点时使用
        search_by_street: this.search_by_street,
      }).then((res) => {
        if (res.code == 200) {
          console.log(res.rows, 'allList')
          this.allList = res.rows
          this.showRight = false
          this.allTablePage.total = res.total
        } else if (res.code == 204) {
          //需要进行人机验证
          this.showRecaptcha = true
          this.getCode()

          this.allList = res.rows
          this.allTablePage.total = res.total

          // var recaptchaDiv = document.getElementById("recaptchaDivAll");
          // const scriptDom = document.createElement("script");
          // scriptDom.src = "https://www.google.com/recaptcha/api.js";
          // recaptchaDiv.appendChild(scriptDom);
        }
      })
    },
    // 电话弹出层
    showContactPopup(phone) {
      this.phoneNumber = phone
      this.showContact = true
    },
    // 复制电话
    copyPhoneNumber() {
      this.$copyText(this.phoneNumber).then(
        (e) => {
          this.$toast.success('ok')
        },
        (err) => {
          this.$toast.fail('fail')
        }
      )
    },
    // 全部部分右侧筛选
    showRightPopup() {
      this.showRight = true
    },
    // Goto_detail
    Goto_detail(advertisementId) {
      this.$router.push({
        path: '/detail',
        query: {
          city: this.city,
          advertisementId: advertisementId,
          category: this.category,
          isAll: this.isAll,
          recommendCurrentPage: this.recommendTablePage.pageNum,
          allCurrentPage: this.allTablePage.pageNum,
          latLng: this.latLng,
          search_street: this.street_info,
          search_city: this.user_input_city_name, //未使用，仅作页面上匹配相关地点时使用
          search_by_street: this.search_by_street,
        },
      })
    },
    // 获取当前城市名称与广告总数
    // getAdvertisementCount() {
    //   apiGetAdvertisementCount({
    //     city: this.stateId,
    //   }).then((res) => {
    //     if (res.code == 200) {
    //       this.advertisementCountData = res.data;
    //     }
    //   });
    // },
    success(position) {
      this.userPosition.lat = position.coords.latitude
      this.userPosition.lng = position.coords.longitude
      // alert("lat=" + this.userPosition.lat + ";lng=" + this.userPosition.lng);
      let latLngKey = 'adlatlng'
      let latLngValNew = this.userPosition.lat + ',' + this.userPosition.lng
      let latLngVal = localStorage.getItem(latLngKey)
      if (!latLngVal) {
        localStorage.setItem(latLngKey, latLngValNew)
        this.latLng = latLngValNew
      } else {
        //判断latlng是否相同
        if (latLngVal != latLngValNew) {
          localStorage.setItem(latLngKey, latLngValNew)
          this.latLng = latLngValNew
        } else {
          this.latLng = latLngVal
        }
      }
      getUserLoc({
        lat: this.userPosition.lat,
        lng: this.userPosition.lng,
      }).then((res) => {
        if (res.code == 200) {
          // alert("loc:" + res.data.loc);
          this.getRecommendList()
        }
      })
    },
    error(error) {
      console.log(`ERROR(${error.code}):${error.message}`)
      console.log('get usrLocLatLng error!')
      //被禁止位置授权时，记录需要提示获取位置信息弹窗
      apiNeedToastGetLatLng()

      // if(localStorage.getItem("toastGetLocTimes")>=2){
      this.getRecommendList()
      // }else{
      //   this.toastGetLocTimes=this.toastGetLocTimes+1
      //   localStorage.setItem("toastGetLocTimes",this.toastGetLocTimes)
      //   this.isDialog=true
      // }
    },
    searchClick() {
      getStateData({ cityName: this.searchWord }).then((res) => {
        console.log('res.data', res.data)
        if (res.code == 200) {
          this.stateList = res.data
        }
      })
    },
    handlePageChange(currentPage) {
      this.recommendTablePage.pageNum = currentPage
      // 在此刷新数据
      this.getRecommendList()
    },
    handleSizeChange(pageSize) {
      this.recommendTablePage.pageSize = pageSize
      // 在此刷新数据
      this.getRecommendList()
    },

    handlePageChangeAllAd(currentPage) {
      this.allTablePage.pageNum = currentPage
      // 在此刷新数据
      this.getAllList()
    },
    handleSizeChangeAllAd(pageSize) {
      this.allTablePage.pageSize = pageSize
      // 在此刷新数据
      this.getAllList()
    },
  },
}
</script>
<style lang="scss">
.van-cascader__header {
  font-size: 0.3rem;
}

.van-cascader__options {
  height: auto !important;
  .van-cascader__option {
    line-height: 0.6rem;
    font-size: 0.4rem;
    white-space: pre;
    font-family: monospace;
  }
}
</style>
<style lang="scss" scoped>
.page {
  background: #f0f0f0;
  .popup-box {
    padding: 0;
    margin: 0;
    width: 80vw;
    background: #ffffff;
    .content {
      height: 100px;
      background: #ffffff;
      font-size: 24px;
      font-weight: 400;
      color: #000000;
    }
    .contact-btn {
      display: block;
      margin: 0 auto;
      margin-bottom: 15px;
      height: 70px;
      width: 55%;
      font-size: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      color: #ffffff;
      background: #273458;
      box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
      border-radius: 10px;
    }
  }
}
.content {
  margin: 14px 17px 120px;
  :deep(.van-swipe__indicator) {
    width: 14px;
    height: 14px;
    margin-right: 10px !important;
  }
  .swiper-img-box {
    :deep(.van-swipe__indicator) {
      width: 14px;
      height: 14px;
      margin-right: 10px !important;
    }
    .swipe-item-img {
      width: 100%;
      height: 260px;
    }
  }
  .swiper-menu-box {
    margin: 24px 0;
    display: flex;
    overflow-x: auto;
    overflow-y: hidden;
  }
  .swiper-menu-item {
    background: #ffffff;
    padding: 10px;
    display: flex;
    flex-direction: column;
    width: 230px;
    height: 210px;
    color: #000000;
    margin-right: 20px;
  }
  .activeClassificationBg {
    background: #273458;
    color: #fff;
  }
  .swiper-menu-p-box {
    flex: 1;
    display: flex;
    align-items: center;
    text-align: left;
  }
  .swiper-menu-p {
    font-size: 20px;
    font-weight: 600;
    text-align: left;
  }
  .swiper-menu-imgBox {
    height: 128px;
    display: flex;
    justify-content: center;
    align-items: flex-end;
    padding-bottom: 10px;
  }
  .swiper-menu-img {
    width: 100%;
    height: 128px;
  }

  .ipt-title {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 10px;
  }
  // 地区下拉框
  .location-box {
    position: relative;
    margin-top: 24px;
    .area-flex-box {
      height: 80px;
      background: #ffffff;
      border: 1px solid rgba(112, 112, 112, 0.34);
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px;
    }
    .area-box-lf {
      font-size: 28px;
      font-weight: 400;
      color: #242424;
    }
    .bottom-icon-bl-img {
      width: 48px;
      height: 48px;
    }
    .location-select-box {
      z-index: 1;
      background: #fff;
      padding: 20px;
    }
    .search-box {
      height: 81px;
      background: #ffffff;
      border: 1px solid #b2b2b2;
      margin-bottom: 30px;
    }
    .location-ipt {
      height: 81px;
      align-items: center;
    }
    :deep(.van-field__control) {
      font-size: 28px;
    }
    .search-icon {
      width: 29px;
      height: 29px;
    }
    .location-list {
      margin-bottom: 40px;
    }
    .location-list-title {
      font-size: 30px;
      font-weight: bold;
      color: #000000;
    }
    .state-cell {
      box-sizing: border-box;
      padding: 26px 0;
      overflow: hidden;
      font-size: 28px;
      font-weight: 400;
      color: #000000;
    }
    .state-value {
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      text-align: center;
    }
    .city-cell {
      box-sizing: border-box;
      padding: 26px 0;
      overflow: hidden;
      font-size: 24px;
      font-weight: 400;
      color: #989898;
    }
    .city-value {
      font-size: 24px;
      font-weight: 400;
      color: #989898;
      text-align: center;
    }
  }

  .detail-box {
    // padding: 0 21px;
    margin-top: 24px;
    .type-box {
      padding: 24px 21px 10px;
      background: #ffffff;
    }
    .all-type-box {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .screen {
      margin-bottom: 9px;
      margin-right: 15px;
    }
    .screen-img {
      width: 45px;
      height: 45px;
    }
    .type {
      display: flex;
      align-items: center;
      margin-bottom: 24px;
    }
    .type-text {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      font-weight: bold;
      color: #273458;
      width: 218px;
      height: 70px;
      background: #ffffff;
      opacity: 0.88;
      border: 1px solid #273458;
      box-sizing: border-box;
    }
    .activeTypeBg {
      background: #273458;
      border: 1px solid #273458;
      box-sizing: border-box;
      color: #ffffff;
    }
    .type-info {
      font-size: 24px;
      font-weight: 400;
      color: #111111;
    }
    .recommend-box-item {
      padding: 21px 21px 10px;
      background: #ffffff;
      margin-bottom: 20px;
    }
    .recommend-img-box {
      display: flex;
      height: 472px;
    }
    .recommend-img-lf {
      margin-right: 8px;
      position: relative;
      width: 52.3%;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      height: 100%;
    }
    .recommend-img-rg {
      margin-left: 8px;
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
    }
    .recommend-img-rg-top {
      margin-bottom: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      height: calc(50% - 8px);
    }
    .recommend-img-rg-bottom {
      margin-top: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      height: calc(50% - 8px);
    }
    .recommend-img-box img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
    .recommend-img-rg-top img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
    .recommend-img-rg-bottom img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }

    .recommend-info-box {
      padding: 25px 12px 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .info-lf-title {
      font-size: 35px;
      font-weight: bold;
      color: #000000;
    }
    .recommend-info-rg img {
      width: 66px;
      height: 66px;
    }
    .info-lf-text {
      font-size: 30px;
      font-weight: 400;
      color: #000000;
      margin-right: 40px;
    }
    .all-box-item {
      padding: 21px 21px;
      background: #fff;
      margin-bottom: 20px;
      position: relative;
    }
    .all-box-item img {
      width: 100%; /*最大宽度不超过父元素宽度*/
      height: 100%; /*最大高度不超过父元素高度*/
      object-fit: contain;
    }
    .all-img-info {
      position: absolute;
      left: 30px;
      bottom: 30px;
    }
    .all-img-info-title {
      font-size: 40px;
      font-weight: 500;
      color: #dbdbdb;
    }
    .all-img-info-text {
      font-size: 24px;
      font-weight: 400;
      color: #dbdbdb;
    }
    .all-img-info-text span {
      margin-right: 20px;
    }
    .info-sp-text {
      font-size: 24px;
      font-weight: bold;
    }
    .sm-box-item {
      display: flex;
      align-items: center;
    }
    .sm-box-item-lf {
      margin-right: 10px;
      width: 50%;
    }
    .sm-box-item-rg {
      margin-left: 10px;
      width: 50%;
    }
    .sm-box-item-lf .sm-box-item-rg img {
      width: 100%; /*最大宽度不超过父元素宽度*/
      height: 100%; /*最大高度不超过父元素高度*/
      object-fit: contain;
      margin-bottom: 20px;
    }
    .sm-box-text {
      font-size: 24px;
      font-weight: 400;
      color: #636363;
      padding-top: 20px;
      margin-top: 20px;
      border-top: 2px solid #000000;
    }
    .sm-box-text span {
      margin-right: 10px;
    }
    .sm-box-sp-text {
      font-size: 24px;
      font-weight: bold;
      color: #000000;
    }
  }
}
// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
.right-item-box {
  margin-bottom: 20px;
}
.showRight-box {
  position: relative;
  margin: 20px 0;
  padding: 10px;
  .area-flex-box {
    height: 80px;
    background: #ffffff;
    border: 1px solid rgba(112, 112, 112, 0.34);
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px;
  }
  .area-box-lf {
    font-size: 28px;
    font-weight: 400;
    color: #242424;
  }
  .bottom-icon-bl-img {
    width: 48px;
    height: 48px;
  }
  .location-select-box {
    position: absolute;
    z-index: 1;
    background: #fff;
    padding: 20px;
    left: 0;
    right: 0;
  }
  .location-list {
    margin-bottom: 40px;
  }
  .location-list-title {
    font-size: 30px;
    font-weight: bold;
    color: #000000;
  }
  .state-cell {
    box-sizing: border-box;
    padding: 26px 0;
    overflow: hidden;
    font-size: 28px;
    font-weight: 400;
    color: #000000;
  }
  .state-value {
    font-size: 28px;
    font-weight: 400;
    color: #000000;
    text-align: center;
  }
  .city-cell {
    box-sizing: border-box;
    padding: 26px 0;
    overflow: hidden;
    font-size: 24px;
    font-weight: 400;
    color: #989898;
  }
  .city-value {
    font-size: 24px;
    font-weight: 400;
    color: #989898;
    text-align: center;
  }
  .van-cell {
    align-items: center;
  }
  .van-cell__title {
    font-size: 28px;
  }
}
.showRightBox-title {
  font-size: 30px;
  text-align: center;
  margin: 30px auto;
  padding: 20px;
}
.handle-btn {
  display: flex;
  align-items: center;
  justify-content: space-around;
}
.handle-btn-item {
  border: 1px solid #273458;
  border-radius: 10px;
  padding: 10px 15px;
  color: #273458;
}
.sure-btn {
  margin: 0 auto;
  width: 100%;
  height: 70px;
}
.van-collapse-item .van-cell {
  align-items: center;
}
:deep(.van-collapse-item__content) {
  padding: 0 0.213333rem;
}
.big-img-box {
  height: 532px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}
.small-img-box {
  height: 350px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}
.small-img-box img {
  width: 100%;
  height: 100%;
  object-fit: cover !important;
}
.normal-person-iptBox {
  background: #fff;
  padding-right: 40px;
  .ipt-flexBox {
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
  }
  .flexBox {
    margin-top: 20px;
    width: 100%;
  }
  .lang-box {
    position: relative;
    .area-flex-box {
      height: 80px;
      background: #ffffff;
      border: 1px solid rgba(112, 112, 112, 0.34);
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .area-box-lf {
      font-size: 28px;
      font-weight: 400;
      color: #242424;
      margin-left: 10px;
    }
    .bottom-icon-bl-img {
      width: 48px;
      height: 48px;
    }
    .location-select-box {
      position: absolute;
      z-index: 1;
      background: #fff;
      padding: 20px;
      left: 0;
      right: 0;
      border: 1px solid #f4f4f4;
    }
    .location-ipt {
      height: 81px;
      align-items: center;
    }
    :deep(.van-field__control) {
      font-size: 28px;
    }
    .location-list {
      margin-bottom: 40px;
    }
    .location-list-title {
      font-size: 30px;
      font-weight: bold;
      color: #000000;
    }
    .state-cell {
      box-sizing: border-box;
      padding: 26px 20px;
      overflow: hidden;
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      line-height: 25px;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      font-weight: 700;
    }
    .state-value {
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      text-align: center;
    }
    .city-cell {
      box-sizing: border-box;
      padding: 26px 0;
      overflow: hidden;
      font-size: 24px;
      font-weight: 400;
      color: #989898;
    }
    .city-value {
      font-size: 24px;
      font-weight: 400;
      color: #989898;
      text-align: center;
    }
  }
  .availability-box {
    margin: 20px 0;
  }
  .available-radio {
    margin-right: 30px;
  }
}

// .confirm-box {
//     margin-top: 30px;
//     margin-left: 40px;
//     margin-right: 40px;

//     .confirm-btn-le {
//       width: 200px;
//       height: 90px;
//       float: left;
//       background: #7ee91a;
//       box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
//       border: 1px solid #ffffff;
//       font-size: 26px;
//       color: #ffffff;
//       font-weight: 400;
//       margin-bottom: 20px;
//     }
//     .confirm-btn-rg {
//       margin-left: 20px;
//       width: 300px;
//       height: 90px;
//       background: #273458;
//       box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
//       border: 1px solid #ffffff;
//       font-size: 26px;
//       color: #ffffff;
//       font-weight: 400;
//       margin-bottom: 20px;
//     }
//   }

.flexBox-lf1 {
  height: 80px;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
}

.van-cell__title {
  line-height: inherit !important;
  text-align: left;
  margin-left: 10px;
  font-weight: 800;
}
.van-cell {
  line-height: 33px !important;
  font-weight: 800;
}

.big-line {
  height: 0px;
  opacity: 1;
  border: 3px solid #d5d1d1;
  margin: 25px 0;
}
</style>
<style scoped>
:deep(.van-cell__title) {
  font-weight: 500 !important;
}
</style>

<style scoped>
:deep(.el-pagination__sizes) {
  width: 20%;
}
:deep(.el-pagination .el-select .el-input) {
  width: 100% !important;
}

:deep(.van-field__label) {
  width: auto !important;
  font-size: large;
  margin-right: 20px;
  color: black;
}

.confirm-btn {
  margin: 21px 35px 35px;
  height: 70px;
  width: 498px;
  font-size: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  color: #ffffff;
  background: #273458;
  box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
}
</style>
