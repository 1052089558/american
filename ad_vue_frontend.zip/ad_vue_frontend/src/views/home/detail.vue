<template>
  <div class="page">
    <div class="header">
      <div class="header-title">details</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>

    <div class="swiper-box">
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="big-swiper">
              <div class="swiper-container">
                <div class="swiper-wrapper">
                  <div class="swiper-slide" v-show="videosOneShow" v-cloak>
                    <div class="swiper-img-box">
                      <video :src="videosOne" controls>
                        <source src="movie.mp4" type="video/mp4" />
                        <!--兼容IE9 、Chrome和Safari-->
                        <source src="movie.ogg" type="video/ogg" />
                        <!--兼容Firefox、Opera和Chrome-->
                        <source src="movie.webm" type="video/webm" />
                        <!--兼容Firefox、Opera和Chrome-->
                        <object data="movie.mp4">
                          <embed src="movie.swf" />
                        </object>
                      </video>
                    </div>
                  </div>

                  <div
                    class="swiper-slide"
                    v-for="(item, index) in detailImgList"
                    :key="index"
                  >
                    <div class="swiper-img-box">
                      <img :src="item.image" alt="" />
                    </div>
                  </div>
                </div>
                <div class="swiper-pagination"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="small-swiper">
              <div class="swiper-container">
                <div class="swiper-wrapper">
                  <div
                    class="swiper-slide"
                    v-for="(item, index) in detailImgList"
                    :key="index"
                  >
                    <img :src="item.image" alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="line"></div>
    <v-touch
      @swipeleft="onSwipeLeft()"
      @swiperight="onSwipeRight()"
      :swipe-options="{ direction: 'horizontal' }"
      style="touch-action: pan-y !important"
    >
      <!-- 主页详情 -->
      <div
        @click="showReport = true"
        style="
          text-align: right;
          padding-right: 20px;
          position: relative;
          top: -18px;
          height: 20px;
          display: flex;
          align-items: center;
          flex-direction: row-reverse;
        "
        >
        <img style="height: 20px" src="../../assets/images/vip/report.png" />
        <div>report</div>
      </div>
      <van-popup v-model="showReport">
        <div style="border: 1px solid #707070; margin: 10px; padding: 8px">
          <div class="popup-box">
            <div
              @click="showReport = false"
              style="position: absolute; right: 15px; top: 20px; z-index: 1"
            >
              <img
                style="height: 20px"
                src="../../assets/images/home/close-bl.png"
              />
            </div>
            <div
              class="popup-head"
              style="border-bottom: 0px; font-size: x-large"
            >
              report
            </div>
            <div
              style="
                margin-bottom: 10px;
                margin-top: 10px;
                font-size: initial;
                margin-left: 10px;
                font-weight: 600;
              "
            >
              <span style="color: red"> * </span>choose one report type:
            </div>
            <van-checkbox-group v-model="report_type" :max="1" icon-size="20px">
              <van-checkbox name="deceptive">deceptive</van-checkbox>
              <van-checkbox name="underage">underage</van-checkbox>
              <van-checkbox name="bloody">bloody</van-checkbox>
            </van-checkbox-group>

            <div
              style="
                margin-bottom: 10px;
                margin-top: 10px;
                font-size: initial;
                margin-left: 10px;
                font-weight: 600;
              "
            >
              Your email
            </div>
            <van-field
              v-model="contactEmail"
              label="contact email"
              placeholder="contact_email"
            >
            </van-field>
            <div
              style="
                margin-bottom: 10px;
                margin-top: 10px;
                font-size: initial;
                margin-left: 10px;
                font-weight: 600;
              "
            >
              Event history
            </div>
            <van-field
              v-model="reportContent"
              rows="6"
              autosize
              label="report content"
              type="textarea"
              placeholder="please input content"
            />

            <div
              style="
                display: flex;
                align-items: center;
                justify-content: center;
              "
            >
              <div
                class="confirm-btn"
                style="width: 50%; border-radius: 10px"
                @click="reportSubmit"
              >
                Confirm Reporting
              </div>
            </div>
          </div>
        </div>
      </van-popup>

      <div class="detail-info" v-if="homepageDetail">
        <div class="detail-info-head">
          <div class="info-head-lf">
            <span class="info-head-name">{{
              advertisement_data.advertisementName
            }}</span>
            <span
              class="info-head-kli"
              v-if="
                advertisement_data.miles != 0 &&
                advertisement_data.miles != 9999.99
              "
              >{{ advertisement_data.miles }}mi
            </span>
          </div>
          <div class="info-head-rg">
            <div
              class="info-head-pho"
              v-if="advertisement_data.phoneAreaCode != undefined "
              v-cloak
            >

            <div class="info-head-pho" v-if="advertisement_data.phoneNumber!=''">
              {{
                '+' +
                advertisement_data.phoneAreaCode +
                advertisement_data.phoneNumber
              }}
            </div>
              
            </div>
            <img
              v-if="advertisement_data.phoneNumber!=''"
              @click="showContactPopup"
              class="phone-img"
              src="../../assets/images/home/phone.png"
              alt=""
            />
            <img
              @click="showShare=true"
              class="phone-img"
              src="../../assets/images/share.png"
              alt=""
            />
          </div>
        </div>
        <div class="detail-info-content">
          <div
            class="info-content-item"
            v-if="
              advertisement_data.cityData != null &&
              advertisement_data.cityData != ''
            "
          >
            <div class="info-content-item-lf">Location</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.cityData.cityName }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.gender != null &&
              advertisement_data.gender != ''
            "
          >
            <div class="info-content-item-lf">Gender</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.gender }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.age != null && advertisement_data.age != ''
            "
          >
            <div class="info-content-item-lf">Age</div>
            <div class="info-content-item-rg">{{ advertisement_data.age }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.race != null && advertisement_data.race != ''
            "
          >
            <div class="info-content-item-lf">Ethnicity</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.race }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.breastSize != null &&
              advertisement_data.breastSize != ''
            "
          >
            <div class="info-content-item-lf">Breast size</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.breastSize }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.weight != null &&
              advertisement_data.weight != ''
            "
          >
            <div class="info-content-item-lf">Weight</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.weight }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.height != null &&
              advertisement_data.height != ''
            "
          >
            <div class="info-content-item-lf">Height</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.height }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.hairLength != null &&
              advertisement_data.hairLength != ''
            "
          >
            <div class="info-content-item-lf">Hair lengh</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.hairLength }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.hairColor != null &&
              advertisement_data.hairColor != ''
            "
          >
            <div class="info-content-item-lf">Hair color</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.hairColor }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.eyeColor != null &&
              advertisement_data.eyeColor != ''
            "
          >
            <div class="info-content-item-lf">Eye color</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.eyeColor }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.travel != null &&
              advertisement_data.travel != ''
            "
          >
            <div class="info-content-item-lf">Travel</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.travel }}
            </div>
          </div>
          
          <div
            class="info-content-item"
            v-if="
              advertisement_data.provide != null &&
              advertisement_data.provide != ''
            "
          >
            <div class="info-content-item-lf">Provide</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.provide }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.available != null &&
              advertisement_data.available != ''
            "
          >
            <div class="info-content-item-lf">Available TO</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.available }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.independent != null &&
              advertisement_data.independent != ''
            "
            >
            <div class="info-content-item-lf">Independent</div>
            <div class="info-content-item-rg">
              {{ advertisement_data.independent }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="
              advertisement_data.email != null && advertisement_data.email != ''
            "
            >
            <div class="info-content-item-lf">Email</div>
            <div class="info-content-item-rg">
              
              <div>{{ advertisement_data.email }}</div>
              <div>
                <img
                  @click="copyEmail(advertisement_data.email)"
                  class="phone-img"
                  src="../../assets/images/home/email.png"
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
        <div class="text-box" v-if="isintroduce">
          <div class="text-box-p">
            {{ advertisement_data.introduce }}
          </div>
        </div>
      </div>
      <!-- 商铺详情 -->
      <div class="store-info" v-if="storeDetail">
        <div class="store-info-item">
          <div class="store-info-item-lf">Store Name：</div>
          <div class="store-info-item-rg">
            {{ advertisement_data.shopname }}
          </div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">Place：</div>
          <div class="store-info-item-rg">{{ advertisement_data.place }}</div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">phone number：</div>
          <div class="store-info-item-rg">
            <span class="phone-num" v-cloak>{{
              '+' +
              advertisement_data.phoneAreaCode +
              advertisement_data.phoneNumber
            }}</span>
            <img
              @click="showContactPopup"
              class="phone-img"
              src="../../assets/images/home/phone.png"
              alt=""
            />
          </div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">Table Shower：</div>
          <div class="store-info-item-rg" v-if="advertisement_data.tableShower">
            yes
          </div>
          <div
            class="store-info-item-rg"
            v-if="!advertisement_data.tableShower"
          >
            no
          </div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">Sauna：</div>
          <div class="store-info-item-rg" v-if="advertisement_data.sauna">
            yes
          </div>
          <div class="store-info-item-rg" v-if="!advertisement_data.sauna">
            no
          </div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">Jacuzzi：</div>
          <div class="store-info-item-rg" v-if="advertisement_data.jacuzzi">
            yes
          </div>
          <div class="store-info-item-rg" v-if="!advertisement_data.jacuzzi">
            no
          </div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">Accept credit card：</div>
          <div
            class="store-info-item-rg"
            v-if="advertisement_data.acceptCreditCard"
          >
            yes
          </div>
          <div
            class="store-info-item-rg"
            v-if="!advertisement_data.acceptCreditCard"
          >
            no
          </div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">Masseur</div>
          <div class="store-info-item-rg" v-if="advertisement_data.masseur">
            yes
          </div>
          <div class="store-info-item-rg" v-if="!advertisement_data.masseur">
            no
          </div>
        </div>
        <div class="store-info-item">
          <div class="store-info-item-lf">Payment method:</div>
          <div class="store-info-item-rg">{{ advertisement_data.payment }}</div>
        </div>
        <div class="time-item">
          <div class="time-item-lf">Rate for 30 miuntes</div>
          <div class="time-item-rg">
            &nbsp;&nbsp;{{ advertisement_data.ratefor30 }}
          </div>
        </div>
        <div class="time-item">
          <div class="time-item-lf">Rate for 45 miuntes</div>
          <div class="time-item-rg">
            &nbsp;&nbsp;{{ advertisement_data.ratefor45 }}
          </div>
        </div>
        <div class="time-item">
          <div class="time-item-lf">Rate for 60 miuntes</div>
          <div class="time-item-rg">
            &nbsp;&nbsp;{{ advertisement_data.ratefor60 }}
          </div>
        </div>
        <div class="hour-box">
          <div class="hour-box-lf">Hours:</div>
          <div class="hour-box-rg">
            <div class="hour-box-rg-item">
              <div class="time">Monday</div>
              <div class="time-box1">AM：{{ advertisement_data.mondayAm }}</div>
              <div class="time-box2">PM：{{ advertisement_data.mondayPm }}</div>
              <div></div>
            </div>
            <div class="hour-box-rg-item">
              <div class="time">Tuesday</div>
              <div class="time-box1">
                AM：{{ advertisement_data.tuesdayAm }}
              </div>
              <div class="time-box2">
                PM：{{ advertisement_data.tuesdayPm }}
              </div>
              <div></div>
            </div>
            <div class="hour-box-rg-item">
              <div class="time">Wednesday</div>
              <div class="time-box1">
                AM：{{ advertisement_data.wednesdayAm }}
              </div>
              <div class="time-box2">
                PM：{{ advertisement_data.wednesdayPm }}
              </div>
              <div></div>
            </div>
            <div class="hour-box-rg-item">
              <div class="time">Thursday</div>
              <div class="time-box1">
                AM：{{ advertisement_data.thursdayAm }}
              </div>
              <div class="time-box2">
                PM：{{ advertisement_data.thursdayPm }}
              </div>
              <div></div>
            </div>
            <div class="hour-box-rg-item">
              <div class="time">Friday</div>
              <div class="time-box1">AM：{{ advertisement_data.fridayAm }}</div>
              <div class="time-box2">PM：{{ advertisement_data.fridayPm }}</div>
              <div></div>
            </div>
            <div class="hour-box-rg-item">
              <div class="time">Saturday</div>
              <div class="time-box1">
                AM：{{ advertisement_data.saturdayAm }}
              </div>
              <div class="time-box2">
                PM：{{ advertisement_data.saturdayPm }}
              </div>
              <div></div>
            </div>
            <div class="hour-box-rg-item">
              <div class="time">Sunday</div>
              <div class="time-box1">AM：{{ advertisement_data.sundayAm }}</div>
              <div class="time-box2">PM：{{ advertisement_data.sundayPm }}</div>
              <div></div>
            </div>
          </div>
        </div>
      </div>
    </v-touch>
    <!-- 电话弹窗 -->
    <van-popup v-model="showContact">
      <div class="popup-box">
        <div class="popup-head">phone number</div>
        <img
          @click="showContact = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content" style="height: auto">
          {{
            '+' +
            advertisement_data.phoneAreaCode +
            advertisement_data.phoneNumber
          }}
        </div>

        <div style="display: flex">
          <div class="confirm-btn" style="margin-right: 10px">
            <a
              :href="
                'tel:+' +
                advertisement_data.phoneAreaCode +
                advertisement_data.phoneNumber
              "
              >Call phone
            </a>
          </div>
          <div class="confirm-btn">
            <a
              :href="
                'sms:+' +
                advertisement_data.phoneAreaCode +
                advertisement_data.phoneNumber
              "
              @click="infoClick($event)"
              >text
            </a>
          </div>
        </div>
      </div>
    </van-popup>
    <!-- 消息弹窗 -->
    <!-- <div class="msg-box" v-if="showMsg">
      <img
        class="msg-img"
        @click="showMsgBox = !showMsgBox"
        src="../../assets/images/home/msg.png"
        alt=""
      />
      <div class="msg-pop" v-if="showMsgBox">
        <div class="msg-contentBox">
          <div class="contentBox-header">
            Tony
            <img
              @click="showMsgBox = false"
              class="close-icon"
              src="../../assets/images/home/close-bl.png"
              alt=""
            />
          </div>
          <div class="msg-body">
            <div>
              <img
                class="avatar-img"
                src="../../assets/images/personal/avatar.png"
                alt=""
              />
            </div>
            <div class="msg-text">
              {{ remark }}
            </div>
          </div>
        </div>
      </div>
    </div> -->


    <van-share-sheet
      v-model="showShare"
      title="Share with friends now"
      :options="shareOptions"
      @select="onShareSelect"
    />

  </div>
</template>

<script>
import {
  apiGetAllList_detail,
  apiGetRemark,
  apiAllList,
  apiGetInfo,
  apiGetRecommendList,
  apiGetAllList,
  apiSysReportAdd,
  getInvitationAddress,
  apiRecodeShareNum,
} from '../../request/api'
import Swiper from 'swiper'
import 'swiper/css/swiper.css'
import { Toast } from 'vant'
import { ShareSheet } from 'vant';
export default {
  name: 'detail',
  data() {
    return {
      invitationCode:"",

      //分享标志位
      showShare:false,
      shareOptions:[
      { id:1,name: 'copy link', icon: 'link' },
      ],

      //举报弹窗
      reportType: '',
      reportContent: '',
      contactEmail: '',
      validcontactEmail: false,
      report_type: [],
      showReport: false,

      videosOneShow: false,
      videosOne: '',
      detailImgList: [],
      showDetailImgList: false,
      showContact: false,
      showMsg: false,
      showMsgBox: true,
      homepageDetail: true,
      storeDetail: false,
      isintroduce: false,
      //主页广告id
      advertisementId: null,
      // 主页广告详情数据
      advertisement_data: {},
      // 弹窗消息
      remark: '',
      allList: [],
      advertisementIds: [],
      currentIndex: null,
      herf: '',
      nickName: '',

      city: 25,
      isAll: false,
      recommendCurrentPage: 1,
      allCurrentPage: 1,
      latLng: '',

      search_street: '',
      search_city: '',
      search_by_street: '0',

      from: '',
    }
  },
  created() {
    // 控制消息弹窗
    setTimeout(() => {
      this.showMsg = true
    }, 3000)
    // 获取主页给来的路由参数
    console.log('主页给来的路由参数', this.$route.query)
    let category = this.$route.query.category
    let advertisementId = this.$route.query.advertisementId // 实际
    this.advertisementId = Number(advertisementId)

    //返回列表页所需参数
    this.isAll = this.$route.query.isAll == 'true'
    this.recommendCurrentPage = Number(this.$route.query.recommendCurrentPage)
    this.allCurrentPage = Number(this.$route.query.allCurrentPage)
    this.city = Number(this.$route.query.city)
    this.latLng = this.$route.query.latLng
    this.search_street = this.$route.query.search_street
    this.search_city = this.$route.query.search_city
    this.search_by_street = this.$route.query.search_by_street

    this.invitationCode =this.$route.query.invitationCode
    if(this.invitationCode!=undefined){
      getInvitationAddress({invitationCode:this.invitationCode}).then(res=>{
        if(res.code==200){
          console.log("invitation code get success")
        }
      })
    }

    //判断跳回路径
    this.from = this.$route.query.from

    console.log('this.advertisementId' + advertisementId)
    // let advertisementId = 1;
    if (category == '5' || category == '8') {
      this.homepageDetail = false
      this.storeDetail = true
    }
    if (advertisementId) {
      this.GET_apiGetAllList_detail(advertisementId)
    }

    // 消息提示获取接口
    apiGetRemark(advertisementId).then((res) => {
      if (res.code == 200) {
        this.remark = res.data.remark
      }
    })

    //判断来自推荐页还是全部AD页
    if (this.isAll == true) {
      //查询全部AD页
      apiGetAllList({
        city: this.city,
        category: this.category,
        miles: this.miles,
        race: this.race,
        latLng: this.latLng,
        pageNumAd: this.allCurrentPage,
        pageSizeAd: 8,
        search_street: this.street_info,
        search_city: this.user_input_city_name, //未使用，仅作页面上匹配相关地点时使用
        search_by_street: this.search_by_street,
      }).then((res) => {
        if (res.code == 200) {
          console.log(res.rows, 'allList')

          this.allList = res.rows
          this.allList.forEach((item) => {
            item.largeALlList.forEach((largeItem) => {
              if (
                this.advertisementIds.indexOf(largeItem.advertisementId) < 0
              ) {
                this.advertisementIds.push(largeItem.advertisementId)
              }
            })

            item.thumbnailALlList.forEach((allAdItem) => {
              if (
                this.advertisementIds.indexOf(allAdItem.advertisementId) < 0
              ) {
                this.advertisementIds.push(allAdItem.advertisementId)
              }
            })
          })
          console.log('this.advertisementIds.....' + this.advertisementIds)
        }
      })
    } else {
      //查询推荐AD页
      apiGetRecommendList({
        city: this.city,
        category: this.category,
        miles: this.miles,
        latLng: this.latLng,
        pageNumAd: this.recommendCurrentPage,
        pageSizeAd: 25,
        search_street: this.street_info,
        search_city: this.user_input_city_name, //未使用，仅作页面上匹配相关地点时使用
        search_by_street: this.search_by_street,
      }).then((res) => {
        console.log(res.rows, 'recommendList')
        if (res.code == 200) {
          this.allList = res.rows
          this.allList.forEach((ad) => {
            this.advertisementIds.push(ad.advertisementId)
          })
          console.log('this.advertisementIds.....' + this.advertisementIds)
        }
      })
    }
  },
  watch: {
    report_type(e) {
      if (e.length == 1) {
        this.reportType = this.report_type[0]
      } else {
        this.reportType = ''
      }
    },
  },
  mounted() {
    const bigSwiper = new Swiper('.big-swiper .swiper-container', {
      pagination: {
        el: '.big-swiper .swiper-pagination',
        clickable: true,
      },
      thumbs: {
        swiper: {
          el: '.small-swiper .swiper-container',
          slidesPerView: 4,
          spaceBetween: 10,
          breakpoints: {
            640: {
              slidesPerView: 4,
              spaceBetween: 10,
            },
            768: {
              slidesPerView: 5,
              spaceBetween: 20,
            },
          },
        },
      },
    })
    this.$data.bigSwiper = bigSwiper
  },
  methods: {
    onShareSelect(shareOption){
      if(shareOption.id==1){
        var url='American professional escort platform, enter to view escorts near you: https://www.abcd69.com/detail?advertisementId='+this.advertisementId;
        var codeTmp=localStorage.getItem("invitationCode");
        if(codeTmp!="undefined"){
          url=url+'&invitationCode='+codeTmp;
        }
        this.$copyText(url).then(
        (e) => {
          //记录分享次数
          if(codeTmp!="undefined"){
            apiRecodeShareNum({invitationCode:codeTmp}).then(res=>{
              if(res.code==200){
                console.log("RecodeShareNum ok")
              }
            })
          }          
          this.$toast.success('ok')
        },
        (err) => {
          this.$toast.fail('fail')
        }
      )
      }
      

    },
    reportSubmit() {
      // 参数校验
      if (this.reportType == '') {
        Toast.fail('please select report type.')
        return
      }

      if (this.reportType == 'deceptive') {
        if (this.contactEmail == '' || this.reportContent == '') {
          Toast.fail('if you choose deceptive type,please input report info.')
          return
        }
        // if(!this.validcontactEmail){
        //   Toast.fail("please input correct email.")
        //   this.showReport=true
        //   return;
        // }
      }

      apiSysReportAdd({
        type: this.reportType,
        contactEmail: this.contactEmail,
        content: this.reportContent,
        adId: this.advertisementId,
      }).then((res) => {
        if (res.code == 200) {
          Toast.success()
          this.showReport = false
        } else {
          Toast.fail('report fail,Please contact administrator')
        }
      })
    },
    infoClick(e) {
      // 触发手机自带发短信,上面的代码只适用于Android，当为ios时需要将上面的?改为&
      var u = navigator.userAgent
      var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1 //android终端
      var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) //ios终端
      if (isiOS) {
        var hr = e.target.getAttribute('href')
        hr = hr.replace('?', '&')
        e.target.setAttribute('href', hr)
      }
    },
    goBack() {
      if (this.from == 'myad') {
        this.$router.push({ path: '/myAD' })
      } else {
        this.$router.push({
          path: '/',
          query: {
            city: this.city,
            isAll: this.isAll,
            recommendCurrentPage: this.recommendCurrentPage,
            allCurrentPage: this.allCurrentPage,
            latLng: this.latLng,
            search_street: this.street_info,
            search_city: this.user_input_city_name, //未使用，仅作页面上匹配相关地点时使用
            search_by_street: this.search_by_street,
          },
        })
      }
    },
    showContactPopup() {
      this.showContact = true
    },
    // 获取主页广告详情方法
    GET_apiGetAllList_detail(advertisementId) {
      let latLng = localStorage.getItem('adlatlng')
      apiGetAllList_detail({
        advertisementId: advertisementId,
        latLng: latLng,
      }).then((res) => {
        if (res.code == 200) {
          console.log('获取主页广告详情', res.data)
          let data = res.data
          this.advertisement_data = data
          if (res.data.introduce != null && res.data.introduce != '') {
            this.isintroduce = true
          }

          this.videosOne = data.videosOne
          if (this.videosOne != '') {
            this.videosOneShow = true
          }

          let detailImgList = []
          detailImgList.push({ image: data.images })
          detailImgList.push({ image: data.imagesOne })
          detailImgList.push({ image: data.imagesTwo })
          detailImgList.push({ image: data.imagesThree })
          detailImgList.push({ image: data.imagesFour })
          detailImgList.push({ image: data.imagesFive })
          detailImgList.push({ image: data.imagesSix })
          detailImgList.push({ image: data.imagesSeven })
          detailImgList.push({ image: data.imagesEight })
          detailImgList.push({ image: data.imagesNine })
          detailImgList.forEach((element, index) => {
            if (element.image) {
            } else {
              delete detailImgList[index]
            }
          })
          for (let i = 0; i < detailImgList.length; i++) {
            if (
              detailImgList[i] == null ||
              detailImgList[i] == '' ||
              JSON.stringify(detailImgList[i]) == '{}'
            ) {
              detailImgList.splice(i, 1)
              i = i - 1
            }
          }
          this.detailImgList = detailImgList
          this.showDetailImgList = true
          console.log(this.detailImgList)
        }
      })
    },
    copyPhoneNumber(data) {
      this.$copyText(data).then(
        (e) => {
          this.$toast.success('ok')
        },
        (err) => {
          this.$toast.fail('fail')
        }
      )
    },
    copyEmail(email) {
      this.$copyText(email).then(
        (e) => {
          this.$toast.success('copy email success')
        },
        (err) => {
          this.$toast.fail('copy email fail')
        }
      )
    },

    onSwipeLeft() {
      console.log('左滑')
      const index = this.advertisementIds.indexOf(this.advertisementId)
      console.log(index)
      if (index < this.advertisementIds.length - 1) {
        this.currentIndex = index + 1
        this.advertisementId = this.advertisementIds[this.currentIndex]
        this.GET_apiGetAllList_detail(this.advertisementId)
      } else {
        console.log('没有更多的广告了')
      }
    },
    onSwipeRight() {
      console.log('右滑')
      const index = this.advertisementIds.indexOf(this.advertisementId)
      console.log(index)
      if (index > 0) {
        this.currentIndex = index - 1
        this.advertisementId = this.advertisementIds[this.currentIndex]
        this.GET_apiGetAllList_detail(this.advertisementId)
      } else {
        console.log('没有更多的广告了')
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}
.swiper-box {
  padding: 24px;
  .swiper-container {
    width: 100%;
    height: 100%;
  }

  .swiper-slide {
    width: 100%;
    height: 100%;
  }

  .big-swiper {
    width: 100%;
    height: 100%;
  }

  .big-swiper .swiper-container {
    width: 100%;
    height: 100%;
  }

  .big-swiper .swiper-slide img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  .small-swiper {
    width: 100%;
    height: 246px;
  }

  .small-swiper .swiper-slide {
    width: 178px;
    height: 246px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .small-swiper .swiper-slide img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .swiper-pagination {
    bottom: 20px;
  }

  .swiper-pagination-bullet {
    background-color: rgba(255, 255, 255, 0.5);
  }

  .swiper-pagination-bullet-active {
    background-color: #fff;
  }
}
.line {
  height: 30px;
  background: #f3f3f3;
}
.detail-info {
  padding: 24px;
  .detail-info-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .info-head-name {
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    margin-right: 6px;
  }
  .info-head-kli {
    font-size: 24px;
    font-weight: 500;
    color: #232f3e;
  }
  .info-head-rg {
    display: flex;
    align-items: center;
  }
  .info-head-pho {
    font-size: large;
    font-weight: 600;
    margin-right: 30px;
    color: #273458;
  }

  .detail-info-content {
    margin: 30px 0;
  }
  .info-content-item {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .info-content-item-lf {
    width: 200px;
    height: 70px;
    background: #273458;
    font-size: 26px;
    font-weight: 500;
    color: #ffffff;
    padding-left: 20px;
    display: flex;
    align-items: center;
  }
  .info-content-item-rg {
    flex: 1;
    height: 70px;
    background: #f3f3f3;
    font-size: 24px;
    font-weight: 500;
    color: #232f3e;
    padding-left: 30px;
    display: flex;
    align-items: center;
    justify-content:space-between;
  }
  .text-box {
    background: #f8f8f8;
    padding: 26px;
  }
  .text-box-header {
    font-size: 40px;
    font-weight: 500;
    color: #0e0e0e;
    margin-bottom: 36px;
  }
  .text-box-p {
    font-size: 33px;
    font-weight: 400;
    color: #000000;
    word-wrap: break-word;
    white-space: pre-wrap;
  }
}
.phone-img {
  width: 54px;
  margin-right: 30px;
  height: 54px;
}
.store-info {
  padding: 50px 65px;
  font-size: 26px;
  font-weight: 400;
  color: #000000;
  .store-info-item {
    display: flex;
    align-items: center;
    border-bottom: 1px solid #d6d6d6;
    padding: 40px 0;
  }

  .store-info-item-lf {
    width: 50%;
  }
  .store-info-item-rg {
    flex: 1;
    display: flex;
    align-items: center;
  }
  .phone-num {
    margin-right: 40px;
  }
  .store-info-item:last-child {
    border-bottom: none;
  }
  .time-item {
    display: flex;
    align-items: center;
    margin: 40px 0;
  }
  .time-item-lf {
    margin-right: 33px;
  }
  .time-item-rg {
    flex: 1;
    height: 70px;
    border: 1px solid #e2e2e2;
    display: flex;
    align-items: center;
  }
  .hour-box {
    display: flex;
  }
  .hour-box-lf {
    height: 55px;
    margin-right: 40px;
    display: flex;
    align-items: center;
  }
  .hour-box-rg {
    flex: 1;
  }
  .hour-box-rg-item {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    box-sizing: border-box;
    height: 55px;
  }
  .time {
    margin-right: 30px;
    width: 130px;
  }
  .time-box1 {
    width: 165px;
    height: 55px;
    border: 1px solid #707070;
    margin-right: 12px;
    padding: 5px;
    box-sizing: border-box;
  }
  .time-box2 {
    width: 165px;
    height: 55px;
    padding: 5px;
    box-sizing: border-box;
    border: 1px solid #707070;
  }
}

// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
.msg-box {
  position: fixed;
  right: 30px;
  bottom: 30%;
  z-index: 2;

  .msg-img {
    width: 81px;
    height: 81px;
    position: relative;
  }
  .msg-pop {
    position: absolute;
    top: -700px;
    right: 30px;
    width: 645px;
    height: 694px;
    border-radius: 40px;
    background-color: #f7f7f7;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  }
  .msg-contentBox {
    position: relative;
  }
  .contentBox-header {
    font-size: 29px;
    font-weight: bold;
    color: #000000;
    height: 94px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #fff;
    border-radius: 40px 40px 0 0;
  }
  .close-icon {
    position: absolute;
    width: 26px;
    height: 26px;
    right: 40px;
  }
  .msg-body {
    background: #f7f7f7;
    padding: 20px 20px;
  }
  .avatar-img {
    width: 92px;
    height: 92px;
  }
  .msg-text {
    background: #000;
    width: 446px;
    background: #ffffff;
    box-shadow: 0px 3px 6px 1px rgba(0, 0, 0, 0.16);
    border-radius: 20px 20px 20px 20px;
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    left: 100px;
    top: 200px;
    padding: 24px;
  }
}
.swiper-img-box {
  height: 902px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
}

video {
  width: 100%;
  position: relative;
  height: auto;
  z-index: 2;
}
</style>
<style scoped>
[v-cloak] {
  display: none !important;
}

:deep(.van-field__label) {
  width: auto;
  display: none;
}

:deep(.van-cell) {
  font-size: initial;
  border: 1px solid #707070;
}

:deep(.van-checkbox__label) {
  font-size: initial;
}

:deep(.van-checkbox-group) {
  margin-bottom: 10px;
  margin-top: 10px;
  display: flex;
}

:deep(.van-checkbox) {
  padding-left: 10px;
  height: 45px;
}

.big-line {
  height: 0px;
  opacity: 1;
  border: 3px solid #d5d1d1;
  margin: 25px 0;
}
</style>
