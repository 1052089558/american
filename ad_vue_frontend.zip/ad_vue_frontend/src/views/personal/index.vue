<template>
  <div class="page">
    <div class="header">
      <van-nav-bar title="Mine" />
    </div>
    <div class="name-box">
      <div class="name-box-lf">
        <img
          class="avatar-img"
          src="../../assets/images/personal/user_img.jpg"
          alt=""
        />
      </div>
      <div class="name-box-rg">
        <div>
          <span class="name-text" style="color: red" v-if="nickName == 'LOG IN'"
            >LOG IN</span
          >
          <span class="name-text" v-else>{{ nickName }}</span>
          <img
            @click="showEditNickname = true"
            class="edit-img"
            src="../../assets/images/personal/edit.png"
            alt=""
          />
        </div>
        <div class="mail-text">{{ userInfo.userName }}</div>
      </div>
    </div>
    <div class="main-item1">
      <div class="money-box">
        <div class="money-box-lf">
          <img
            class="money-box-head-img"
            src="../../assets/images/personal/ad.png"
            alt=""
          />
          <div>
            <div class="money-box-head-text">
              {{ userInfo.publishAdNums ? userInfo.publishAdNums : 0 }}
            </div>
            <div class="money-box-type">Actived Ad</div>
          </div>
        </div>
        <div class="money-box-rg">
          <img
            class="money-box-head-img"
            src="../../assets/images/personal/money.png"
            alt=""
          />
          <div>
            <div class="money-box-head-text">
              {{ userInfo.balance ? userInfo.balance : 0 }}
            </div>
            <div class="money-box-type">Ad balance</div>
          </div>
        </div>
      </div>

      <div class="line"></div>

      <div class="recharge-item-box" @click="showRecharge = !showRecharge">
        <div class="recharge-item-lf">
          <div class="recharge-item-flex">
            <img
              class="wallet-img"
              src="../../assets/images/personal/wallet.png"
              alt=""
            />
            <span class="recharge-text">Recharge</span>
          </div>
        </div>
        <div class="recharge-item-rg">
          <img
            v-show="!showRecharge"
            class="right-icon-img"
            src="../../assets/images/personal/right-icon.png"
            alt=""
          />
          <img
            v-show="showRecharge"
            class="top-icon-img"
            src="../../assets/images/personal/top-icon.png"
            alt=""
          />
        </div>
      </div>
      <div class="recharge-box" v-show="showRecharge">
        <div style="margin-bottom: 10px">
          If you are unable to open the recharge page, please use mobile
          data.(Do not use wifi)
        </div>
        <div class="recharge-flex-box">
          <div
            class="recharge-item"
            :class="{ activeRechargeBg: checked == item.dictSort }"
            v-for="item in balanceList"
            :key="item.dictSort"
            @click="checkedMoney(item)"
          >
            <div class="recharge-money">$ {{ item.dictLabel }}</div>
            <div style="display: flex; justify-content: flex-end">
              <img
                style="width: 20px"
                src="../../assets/images/personal/BTC_icon.png"
              />
              <img
                style="width: 20px"
                src="../../assets/images/personal/ETF_icon.png"
              />
            </div>
          </div>
        </div>
        <!-- <div>
          <van-field
            class="money-inp"
            v-model="rechargeMoney"
            placeholder="Please enter amount"
          />
        </div> -->
        <div class="confirm-btn-box" @click="handleRecharge">
          <van-button class="confirm-btn">Confirm recharge</van-button>
        </div>

        <div style="display: flex; flex-direction: column; margin-top: 10px">
          <div style="display: flex; text-align: center">
            <span>customer service:</span>
            <a href="https://t.me/abcd69_1"
              ><img
                style="
                  width: 20px;
                  height: 20px;
                  margin-left: 10px;
                  margin-right: 5px;
                "
                src="../../assets/images/personal/tg.png"
            /></a>
            <div @click="showContact = !showContact">
              <img
                style="
                  width: 20px;
                  height: 20px;
                  margin-left: 5px;
                  margin-right: 5px;
                "
                src="../../assets/images/home/ContactUs.png"
              />
            </div>
          </div>
          <div>
            Please contact official customer service for recharge issues
          </div>
        </div>
      </div>
    </div>

    <div class="line"></div>

    <div class="bg-div"></div>

    <div class="main-item2">
      <div v-bind:style="{ display: signCycleDay <= 21 ? '' : 'none' }">
        <div class="cash-item-box" @click="toggleShow">
          <div class="recharge-item-lf">
            <div class="recharge-item-flex">
              <img
                class="wallet-img"
                src="../../assets/images/personal/gift.png"
                alt=""
              />
              <span class="recharge-text">Sign in and collect cash</span>
            </div>
          </div>
          <div class="recharge-item-rg">
            <img
              v-if="!showCollapse"
              class="right-icon-img"
              src="../../assets/images/personal/right-icon.png"
              alt=""
            />
            <img
              v-else
              class="top-icon-img"
              src="../../assets/images/personal/top-icon.png"
              alt=""
            />
          </div>
        </div>
        <div v-if="showCollapse" class="sign-content">
          <p class="tips tips1">
            Open the abcd69.com webpage every day to sign in and receive cash
            rewards that can be used for free advertising.
          </p>
          <p class="tips tips2">Daily check-in to collect cash</p>
          <div class="sign-view">
            <p>{{ 'My Rewards $' + (myRewards == null ? 0 : myRewards) }}</p>
            <div class="sign-show">
              <div
                v-for="(item, index) in signList"
                :key="index"
                class="sign-show-content"
              >
                <div>{{ item.money }}</div>
                <div>{{ item.order }}</div>
                <div class="sign-show-list">
                  <div v-if="item.hasSign == 'Y'" class="sign_text">√</div>
                  <div v-else-if="item.hasSign == 'F'" class="sign_text">X</div>
                  <div v-else class="sign_text"></div>
                  <!-- <van-checkbox
                    v-model="item.hasSign"
                    icon-size="24px"
                    disabled
                  ></van-checkbox> -->
                </div>
              </div>
            </div>
            <van-button
              v-bind:disabled="signStatus"
              class="confirm-btn"
              style="color: black; font-size: 20px"
              @click="goSignIn"
              >Click in</van-button
            >
          </div>
        </div>
      </div>
      <div v-if="showCollapse" class="sign-content">
        <div class="sign-rules">
          <div class="sign-rules-head">
            <span>Task rewards</span>
          </div>

          <div class="task-list">
            <div
              v-for="(item, index) in taskList"
              :key="index"
              class="task-content"
              @click="getCouponFunction(item)"
            >
              <div
                class="task-item"
                :style="{
                  'background-color':
                    item.userCoupon.userCouponState == 'expiry'
                      ? 'darkgray'
                      : '',
                }"
              >
                <div class="task-item-head">
                  <span>Received rule</span>
                </div>
                <div class="task-item-foot">
                  <div class="task-item-foot-left">
                    <span>{{ item.title }}</span>
                    <span
                      >EXP:{{ item.userCoupon.userCouponExpiryDateStr }}</span
                    >
                  </div>
                  <div
                    class="task-item-foot-right"
                    v-if="item.userCoupon.userCouponState == 'acquirement'"
                  >
                    <div class="task-item-foot-left">
                      <span style="font-size: 20px"
                        >${{ item.rechargeAmount }}</span
                      >
                      <span
                        class="received-money"
                        style="font-size: 15px; text-decoration: line-through"
                        :style="{ display: item.payAmount == 0 ? 'none' : '' }"
                        >${{ item.payAmount }}</span
                      >
                    </div>

                    <span style="margin-right: 10px">{{
                      item.userCoupon.userCouponState == 'acquirement'
                        ? 'USE'
                        : 'Get'
                    }}</span>
                  </div>

                  <div
                    class="task-item-foot-right"
                    v-if="item.userCoupon.userCouponState == 'notGet'"
                  >
                    <div class="task-item-foot-left">
                      <span style="font-size: 20px"
                        >${{ item.rechargeAmount }}</span
                      >
                      <span
                        class="received-money"
                        style="font-size: 15px; text-decoration: line-through"
                        :style="{ display: item.payAmount == 0 ? 'none' : '' }"
                        >${{ item.payAmount }}</span
                      >
                    </div>

                    <span style="margin-right: 10px">Get</span>
                  </div>

                  <div
                    class="task-item-foot-right"
                    v-if="item.userCoupon.userCouponState == 'unfinished'"
                  >
                    <div class="task-item-foot-left">
                      <span style="font-size: 18px"
                        >${{ item.rechargeAmount }}</span
                      >
                      <span
                        class="received-money"
                        style="font-size: 15px; text-decoration: line-through"
                        :style="{ display: item.payAmount == 0 ? 'none' : '' }"
                        >${{ item.payAmount }}</span
                      >
                    </div>

                    <span style="font-size: initial">unfinished</span>
                  </div>

                  <div
                    class="task-item-foot-right"
                    v-if="item.userCoupon.userCouponState == 'used'"
                  >
                    <div class="task-item-foot-left">
                      <span style="font-size: 20px"
                        >${{ item.rechargeAmount }}</span
                      >
                      <span
                        class="received-money"
                        style="font-size: 15px; text-decoration: line-through"
                        :style="{ display: item.payAmount == 0 ? 'none' : '' }"
                        >${{ item.payAmount }}</span
                      >
                    </div>

                    <span style="margin-right: 10px">{{
                      item.userCoupon.userCouponState
                    }}</span>
                  </div>

                  <div
                    class="task-item-foot-right"
                    v-if="item.userCoupon.userCouponState == 'expiry'"
                  >
                    <div class="task-item-foot-left">
                      <span style="font-size: 20px"
                        >${{ item.rechargeAmount }}</span
                      >
                      <span
                        class="received-money"
                        style="font-size: 15px; text-decoration: line-through"
                        :style="{ display: item.payAmount == 0 ? 'none' : '' }"
                        >${{ item.payAmount }}</span
                      >
                    </div>

                    <span style="margin-right: 10px">{{
                      item.userCoupon.userCouponState
                    }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-div"></div>

    <div class="main-item2">
      <div class="cash-item-box" @click="toggleShow1">
        <div class="recharge-item-lf">
          <div class="recharge-item-flex">
            <img
              class="wallet-img"
              src="../../assets/images/personal/cash.png"
              alt=""
            />
            <span class="recharge-text">Cash reward promotion</span>
          </div>
        </div>
        <div class="recharge-item-rg">
          <img
            v-if="!showCollapse1"
            class="right-icon-img"
            src="../../assets/images/personal/right-icon.png"
            alt=""
          />
          <img
            v-else
            class="top-icon-img"
            src="../../assets/images/personal/top-icon.png"
            alt=""
          />
        </div>
      </div>
      <div class="num-box" v-show="showCollapse1">
        <div class="num-box-text">
          Invite new users who have never opened or used abcd69.com to receive a
          reward. Each user can only be invited once, and the reward can be used
          to post advertisements
        </div>
        <div class="num-box-text">You can invite multiple new users.</div>
        <div class="num-box-text">The reward can be used for publish ads.</div>
        <div class="num-flex-box">
          <div class="num-flex-item">
            <div class="num-flex-item-title">invited people</div>
            <div class="num-flex-item-num">
              {{ userInfo.inviteNumber ? userInfo.inviteNumber : 0 }}
            </div>
          </div>

          <div class="num-flex-item">
            <div class="num-flex-item-title">Pre person</div>
            <div class="num-flex-item-num">＄：{{ Invitation_amount }}</div>
          </div>

          <div class="num-flex-item">
            <div class="num-flex-item-title">Total reward</div>
            <div class="num-flex-item-num">
              {{
                (userInfo.effectiveNumber ? userInfo.effectiveNumber : 0) *
                Invitation_amount
              }}
            </div>
          </div>
        </div>

        <div class="address-box">
          <div class="address-box-lf">{{ invite_link + invitationCode }}</div>
          <div class="address-box-rg" @click="copyLinkInviteUrl">
            copy address
          </div>
        </div>
        <div class="num-box-text">
          Copy your referral link and send it to your customer to receive a cash
          reward.
        </div>
      </div>
    </div>

    <div class="bg-div"></div>
    <!--  -->

    <div class="main-item3">
      <div class="menu-item" @click="handleChangePassword">
        <div class="menu-item-lf">
          <div class="menu-item-flex">
            <img
              class="menu-item-img"
              src="../../assets/images/personal/lock.png"
              alt=""
            />
            <div class="menu-item-title">change password</div>
          </div>
        </div>
        <div class="menu-item-rg">
          <img
            class="right-icon-img"
            src="../../assets/images/personal/right-icon.png"
            alt=""
          />
        </div>
      </div>
      <div class="menu-item" @click="handleChangeEmail">
        <div class="menu-item-lf">
          <div class="menu-item-flex">
            <img
              class="menu-item-img"
              src="../../assets/images/personal/mail.png"
              alt=""
            />
            <div class="menu-item-title">change email</div>
          </div>
        </div>
        <div class="menu-item-rg">
          <img
            class="right-icon-img"
            src="../../assets/images/personal/right-icon.png"
            alt=""
          />
        </div>
      </div>
      <div class="menu-item" @click="showPrivacyPopup">
        <div class="menu-item-lf">
          <div class="menu-item-flex">
            <img
              class="menu-item-img"
              src="../../assets/images/personal/privacy.png"
              alt=""
            />
            <div class="menu-item-title">privacy</div>
          </div>
        </div>
        <div class="menu-item-rg">
          <img
            class="right-icon-img"
            src="../../assets/images/personal/right-icon.png"
            alt=""
          />
        </div>
      </div>
      <!-- <div class="menu-item" @click="showContactPopup">
        <div class="menu-item-lf">
          <div class="menu-item-flex">
            <img
              class="menu-item-img"
              src="../../assets/images/personal/kefu.png"
              alt=""
            />
            <div class="menu-item-title">contact us</div>
          </div>
        </div>
        <div class="menu-item-rg">
          <img
            class="right-icon-img"
            src="../../assets/images/personal/right-icon.png"
            alt=""
          />
        </div>
      </div> -->
      <div class="menu-item" @click="handleLogout">
        <div class="menu-item-lf">
          <div class="menu-item-flex">
            <img
              class="menu-item-img"
              src="../../assets/images/personal/logout.png"
              alt=""
            />
            <div class="menu-item-title">logout</div>
          </div>
        </div>
        <div class="menu-item-rg">
          <img
            class="right-icon-img"
            src="../../assets/images/personal/right-icon.png"
            alt=""
          />
        </div>
      </div>
    </div>

    <!-- 弹窗 -->

    <!-- @click="showRechargeLoading = false" -->
    <van-overlay :show="showRechargeLoading">
      <div
        style="
          display: flex;
          justify-content: center;
          align-items: center;
          flex-direction: column;
        "
        @click.stop
      >
        <van-loading size="75px" color="#0094ff"></van-loading>
        <van-button plain style="margin-top:10px;" @click="showRechargeLoading = false"
          >cancel</van-button
        >
      </div>
    </van-overlay>

    <van-popup v-model="showRechargeTitle">
      <div class="popup-box">
        <div class="popup-head">Toast</div>
        <img
          @click="showRechargeTitle = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content" style="height: auto">
          If you are unable to open the recharge page, please use mobile
          data.(Do not use wifi).
        </div>
        <div class="confirm-btn" @click="handleRecharge">confirm</div>
      </div>
    </van-popup>

    <van-popup v-model="showPrivacy">
      <div class="popup-box">
        <div class="popup-head">privacy</div>
        <img
          @click="showPrivacy = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">
          {{ privacyStatement }}
        </div>
        <div class="confirm-btn" @click="showPrivacy = false">confirm</div>
      </div>
    </van-popup>

    <van-popup v-model="showContact">
      <div class="popup-box">
        <div class="popup-head">
          <img
            class="muen-icon-img"
            src="../../assets/images/home/ContactUs.png"
          />
          Contact Us
        </div>
        <img
          @click="showContact = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">email：{{ contactUs }}</div>
        <div class="confirm-btn" @click="copyLinkContactUsEmail">copy</div>
      </div>
    </van-popup>

    <van-popup v-model="showEditNickname">
      <div class="popup-box">
        <div class="popup-head">Modify Name</div>
        <img
          @click="showEditNickname = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content nickName-content">
          <van-field v-model="nickName" />
        </div>
        <div class="confirm-btn" @click="handleEditNickname">confirm</div>
      </div>
    </van-popup>

    <router-view />
    <van-tabbar route active-color="#027AFC" inactive-color="#666666">
      <van-tabbar-item replace to="/vip">
        <span> {{ $t('vip') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active1 : icon.inactive1" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/">
        <span> {{ $t('home') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active2 : icon.inactive2" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/postAd">
        <span> {{ $t('post AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active3 : icon.inactive3" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/myAD">
        <span> {{ $t('my AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active4 : icon.inactive4" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/personal">
        <span> {{ $t('Profile') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active5 : icon.inactive5" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
    <div style="display: none">
      <div class="buy-with-crypto-div">
        <!-- 1美元测试如下 -->
        <!-- <a
          ref="pay20"
          class="buy-with-crypto"
          data-custom="1000"
          href="https://commerce.coinbase.com/checkout/0cad3973-0b69-49bd-b386-78daddce6b99"
        > -->

        <a
          ref="pay20"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/09ccc9f8-fc74-4dab-ae25-e3bfa4cafb97"
        >
          $20
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay50"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/7c81bd77-602f-4a5a-ab16-580aa0dd17f0"
        >
          $50
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay100"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/caf1e5b5-1268-47d2-8a2f-633db0ec3419"
        >
          $100
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay200"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/9ff5db07-98bd-49ad-8305-9bfbc536c0ff"
        >
          $200
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay500"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/da7abb79-81c0-4557-82c8-dfd8940e9e05"
        >
          $500
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay1000"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/daa8862e-086e-41f6-a91a-c9d63e9bf187"
        >
          $1000
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay2000"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/a0c681e9-ae62-4eb3-8452-bb9af8012c8a"
        >
          $2000
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay5000"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/0c985d4c-4e96-469a-b443-6eadd24e30bc"
        >
          $5000
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay10000"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/a550bb65-96de-4a20-aeea-892f41fa2937"
        >
          $10000
        </a>
      </div>

      <!-- coinbase_checkout_coupon-->
      <div class="buy-with-crypto-div">
        <a
          ref="pay30_45"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/b5f57888-ebda-4605-8e4f-5fe7002c2650"
        >
          Recharge $30, you will get $45 on your balance.
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay50_80"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/12badddf-5f07-4c4c-ad96-b1a149ead382"
        >
          Recharge $50, you will get $80 on your balance.
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay100_200"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/32d730d7-a3fc-4299-b520-4210c2788fd6"
        >
          Recharge $100, you will get $200 on your balance.
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay500_700"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/b626bbbc-94ee-4452-8ce7-dba622a6184f"
        >
          Recharge $500, you will get $700 on your balance.
        </a>
      </div>
      <div class="buy-with-crypto-div">
        <a
          ref="pay1000_1300"
          class="buy-with-crypto"
          :data-custom="userId"
          href="https://commerce.coinbase.com/checkout/7085b99a-ef7f-4ead-8c37-00f3e4fc5904"
        >
          Recharge $1000, you will get $1300 on your balance.
        </a>
      </div>
    </div>
  </div>
</template>

<script>
import {
  apiGetPrivacyStatement,
  apiGetContactUs,
  apiGetLogout,
  apiGetInfo,
  apiUpdateUser,
  apiBalance,
  apiRecharge,
  apiSignDays,
  getSignMoney,
  getTaskRewards,
  getConfigValue,
  getCoupon,
  apiRecodeShareNum,
  // apiVerrfyPayState,
} from '../../request/api'
import { Toast } from 'vant'
export default {
  name: 'personal',
  components: {},
  data() {
    return {
      showRechargeLoading: false,
      showRechargeTitle: false,

      rechargeMoney: '',
      Invitation_amount: '',
      active: 0,
      icon: {
        active1: require('../../assets/images/tabbar/tabbar1.png'),
        inactive1: require('../../assets/images/tabbar/tabbar2.png'),
        active2: require('../../assets/images/tabbar/tabbar3.png'),
        inactive2: require('../../assets/images/tabbar/tabbar4.png'),
        active3: require('../../assets/images/tabbar/tabbar5.png'),
        inactive3: require('../../assets/images/tabbar/tabbar6.png'),
        active4: require('../../assets/images/tabbar/tabbar7.png'),
        inactive4: require('../../assets/images/tabbar/tabbar8.png'),
        active5: require('../../assets/images/tabbar/tabbar9.png'),
        inactive5: require('../../assets/images/tabbar/tabbar10.png'),
      },
      showRecharge: false,
      checked: '',
      money: '',
      showPrivacy: false,
      showContact: false,
      privacyStatement: '',
      contactUs: '',
      // 用户信息
      nickName: 'LOG IN',
      userId: '',
      invite_link: '',
      invitationCode: '',
      userInfo: {},
      showEditNickname: false,
      balanceList: [],
      showCollapse: true,
      showCollapse1: true,
      myRewards: 0,
      signStatus: true,
      signCycleDay: 0,
      signdays: 0,
      signList: [
        { ind: 1, order: '1st', money: '$15' },
        { ind: 2, order: '2nd', money: '$5' },
        { ind: 3, order: '3rd', money: '$10' },
        { ind: 4, order: '4th', money: '$15' },
        { ind: 5, order: '5th', money: '$25' },
        { ind: 6, order: '6th', money: '$45' },
        { ind: 7, order: '7th', money: '$60' },
      ],
      taskList: [],
      taskNotGetList: [],
      taskGetList: [],
      taskUnfinishedList: [],
      taskUsedList: [],
      taskExpiryList: [],
    }
  },
  created() {
    let token = localStorage.getItem('key')
    if (!token) {
      this.$router.replace('/login')
    }

    getConfigValue({ configKey: 'Invitation_Address' }).then((res) => {
      if (res.code == 200) {
        this.invite_link = res.msg
      }
    })
    getConfigValue({ configKey: 'Invitation_amount' }).then((res) => {
      // console.log(res, "res");
      if (res.code == 200) {
        this.Invitation_amount = res.msg
      }
    })

    getConfigValue({ configKey: 'contactUs' }).then((res) => {
      if (res.code == 200) {
        this.contactUs = res.msg
      }
    })

    apiGetInfo().then((res) => {
      if (res.code == 200) {
        this.invitationCode = res.data.invitationCode
        this.userInfo = res.data
        this.userId = res.data.userId
        this.nickName = res.data.nickName
        this.signdays = res.data.signTimes
        this.myRewards = res.data.signRewards
        this.signStatus = res.data.signToday == 'Y' ? true : false
        this.signCycleDay = res.data.signCycleDay
        this.signList[0].hasSign = this.userInfo.sign_1
        this.signList[1].hasSign = this.userInfo.sign_2
        this.signList[2].hasSign = this.userInfo.sign_3
        this.signList[3].hasSign = this.userInfo.sign_4
        this.signList[4].hasSign = this.userInfo.sign_5
        this.signList[5].hasSign = this.userInfo.sign_6
        this.signList[6].hasSign = this.userInfo.sign_7

        // this.signList.map((x) => {
        //   if (x.ind <= this.signdays) {
        //     x.hasSign = true;
        //   } else {
        //     x.hasSign = false;
        //   }
        //   return x;
        // });
      }
    })
    apiBalance().then((res) => {
      if (res.code == 200) {
        this.balanceList = res.data
      }
    })

    //获取设置签到金额
    getSignMoney().then((res) => {
      if (res.code == 200) {
        for (let index = 0; index < 7; index++) {
          this.signList[index].money = '$' + res.data[index].money
          // console.log("set sign money success");
        }
      }
    })
    //获取设置的taskRewards
    getTaskRewards().then((res) => {
      if (res.code == 200) {
        this.taskList = res.data
        // for (let index = 0; index < res.data.length; index++) {
        //   if (res.data[index].userCoupon.userCouponState == "notGet") {
        //     //未获取的券
        //     this.taskNotGetList.push(res.data[index]);
        //   } else if (
        //     res.data[index].userCoupon.userCouponState == "acquirement"
        //   ) {
        //     //已获得、可使用的券
        //     this.taskGetList.push(res.data[index]);
        //   } else if (res.data[index].userCoupon.userCouponState == "used") {
        //     //已使用的券
        //     this.taskUsedList.push(res.data[index]);
        //   } else if (res.data[index].userCoupon.userCouponState == "expiry") {
        //     //已失效的券
        //     this.taskExpiryList.push(res.data[index]);
        //   } else if (
        //     res.data[index].userCoupon.userCouponState == "unfinished"
        //   ) {
        //     //未完成任务的券
        //     this.taskUnfinishedList.push(res.data[index]);
        //   }
        // }
      }
    })

    window.addEventListener(
      'POIDetailDataChange',
      this.handlePOIDetailDataChange
    )
  },
  mounted() {
    window.showRechargeLoading = false

    // https://commerce.coinbase.com/v1/checkout.js?version=201807
    var paymentBtns = document.getElementsByClassName('buy-with-crypto-div')

    //先确认userid已被正确设置，再进行js添加操作
    apiGetInfo()
      .then((res) => {
        if (res.code == 200) {
          this.userId = res.data.userId
        }
      })
      .then(() => {
        for (var i = 0; i < paymentBtns.length; i++) {
          const scriptDom = document.createElement('script')
          scriptDom.src =
            'https://commerce.coinbase.com/v1/checkout.js?version=201807'
          paymentBtns[i].appendChild(scriptDom)
        }
        setTimeout(() => this.initPaymentFunction(), 3000)
      })
  },
  methods: {
    handlePOIDetailDataChange(newVal) {
      // console.log('window.POIDetailData 发生变化:', newVal);
      this.showRechargeLoading = window.showRechargeLoading
    },
    initPaymentFunction() {
      BuyWithCrypto.registerCallback('onSuccess', function (e) {
        // Charge was successfully completed
        console.log('onSuccess', e)
        window.showRechargeLoading = false
        var event = new Event('POIDetailDataChange')
        window.dispatchEvent(event)
        Toast.success(
          'Charge was successfully completed,If it does not arrive in time, please contact the account administrator.'
        )
        // apiVerrfyPayState({eventId:e.eventId}).then((res)=>{
        //   if(res.code==200){
        //     //支付成功
        //     Toast.success("Charge was successfully completed");
        //   }else if(res.code==500){
        //     //请联系管理员
        //     Toast.success("Coinbase server payment status query failed, please contact the administrator");
        //   }else if(res.code==501){
        //     //支付状态不正确，请确认是否支付成功
        //     Toast.fail("The payment status is incorrect, please confirm whether the payment was successful.");
        //   }else{
        //     Toast.fail("Charge failed");
        //   }
        // })
      })

      BuyWithCrypto.registerCallback('onFailure', function (e) {
        // Charge failed
        console.log('onFailure', e)
        window.showRechargeLoading = false
        var event = new Event('POIDetailDataChange')
        window.dispatchEvent(event)
        // apiVerrfyPayState({eventId:e.eventId}).then((res)=>{
        //   Toast.fail("Charge failed");
        // });
        Toast.fail('Charge failed')
      })

      BuyWithCrypto.registerCallback('onPaymentDetected', function (e) {
        // Payment has been detected but not yet confirmed
        console.log('onPaymentDetected', e)
        window.showRechargeLoading = false
        var event = new Event('POIDetailDataChange')
        window.dispatchEvent(event)
        Toast('Payment has been detected but not yet confirmed')
      })
    },

    // 充值
    // handleRecharge() {
    //   apiRecharge({
    //     rechargeMoney: this.rechargeMoney,
    //   }).then((res) => {
    //     if (res.code == 200) {
    //       this.$router.go(0)
    //       this.$toast.success(res.msg)
    //     } else {
    //       this.$router.go(0)
    //       this.$toast.fail(res.msg)
    //     }
    //     this.showRecharge = false
    //   })
    // },
    // 充值byCoinBase
    handleRecharge() {
      this.showRechargeTitle = false

      this.$dialog
        .confirm({
          // title: this.$t('Total'),
          messageAlign:'left',
          showCancelButton:false,
          confirmButtonText:'OK',
          message: this.$t(
            'If you are unable to open the recharge page, please use mobile data.(Do not use wifi).'
          ),
        })
        .then(() => {
          this.showRechargeLoading = true
          window.showRechargeLoading = true

          if (this.rechargeMoney == '20') {
            this.$refs.pay20.click()
          } else if (this.rechargeMoney == '50') {
            this.$refs.pay50.click()
          } else if (this.rechargeMoney == '100') {
            this.$refs.pay100.click()
          } else if (this.rechargeMoney == '200') {
            this.$refs.pay200.click()
          } else if (this.rechargeMoney == '500') {
            this.$refs.pay500.click()
          } else if (this.rechargeMoney == '1000') {
            this.$refs.pay1000.click()
          } else if (this.rechargeMoney == '2000') {
            this.$refs.pay2000.click()
          } else if (this.rechargeMoney == '5000') {
            this.$refs.pay5000.click()
          } else if (this.rechargeMoney == '10000') {
            this.$refs.pay10000.click()
          }
        })
        .catch(() => {
          // on cancel
        })

      // apiRecharge({
      //   rechargeMoney: this.rechargeMoney,
      // }).then((res) => {
      //   if (res.code == 200) {
      //     this.$router.go(0)
      //     this.$toast.success(res.msg)
      //   } else {
      //     this.$router.go(0)
      //     this.$toast.fail(res.msg)
      //   }
      //   this.showRecharge = false
      // })
    },
    checkedMoney(item) {
      this.checked = item.dictSort
      this.rechargeMoney = item.dictValue
    },
    copyLinkInviteUrl() {
      let invite_info = this.invite_link + this.invitationCode
      invite_info =
        invite_info +
        ' American professional escort platform, more than 16000 people find partners on the platform every day.'
      this.$copyText(invite_info).then(
        (e) => {
          apiRecodeShareNum({invitationCode:this.invitationCode}).then(res=>{
            if(res.code==200){
              console.log("RecodeShareNum ok")
            }
          })
          this.$toast.success()
        },
        (err) => {
          this.$toast.fail()
        }
      )
    },
    copyLinkContactUsEmail() {
      this.showContact = false
      let contactUs = this.contactUs
      this.$copyText(contactUs).then(
        (e) => {
          this.$toast.success()
        },
        (err) => {
          this.$toast.fail()
        }
      )
    },
    showPrivacyPopup() {
      apiGetPrivacyStatement().then((res) => {
        if (res.code == 200) {
          this.showPrivacy = true
          this.privacyStatement = res.data
        }
      })
    },
    // showContactPopup() {
    //   apiGetContactUs().then((res) => {
    //     if (res.code == 200) {
    //       // this.showContact = true;
    //       this.contactUs = res.data;
    //     }
    //   });
    // },

    handleEditNickname() {
      apiUpdateUser({
        userId: this.userId,
        nickName: this.nickName,
      }).then((res) => {
        if (res.code == 200) {
          this.$toast.success(res.msg)
        } else {
          this.$toast.fail(res.msg)
        }
        this.showEditNickname = false
      })
    },

    handleLogout() {
      this.$dialog
        .confirm({
          title: this.$t('Total'),
          message: this.$t('sure to exit?'),
        })
        .then(() => {
          apiGetLogout().then((res) => {
            if (res.code == 200) {
              localStorage.removeItem('key')
              localStorage.removeItem('userId')
              localStorage.removeItem('invitationCode')
              this.$router.replace('/login')
              this.$toast.success(res.msg)
            }
          })
        })
        .catch(() => {
          // on cancel
        })
    },
    handleChangePassword() {
      this.$router.push('/changePassword')
    },
    handleChangeEmail() {
      this.$router.push('/changeMail')
    },
    toggleShow() {
      this.showCollapse = !this.showCollapse
    },
    goSignIn() {
      if (this.signStatus) return
      let token = localStorage.getItem('key')
      apiSignDays({ Authorization: token })
        .then((res) => {
          if (res.code === 200) {
            this.$toast.success({
              duration: 1000,
              message: res.msg,
              type: 'success',
            })
            this.signStatus = true
          }
        })
        .then(() => {
          apiGetInfo().then((res) => {
            if (res.code == 200) {
              this.userInfo = res.data
              this.userId = res.data.userId
              this.nickName = res.data.nickName
              this.signdays = res.data.signTimes
              this.myRewards = res.data.myRewards
              this.signStatus = res.data.signToday == 'Y' ? true : false
              this.signCycleDay = res.data.signCycleDay
              this.signList[0].hasSign = this.userInfo.sign_1
              this.signList[1].hasSign = this.userInfo.sign_2
              this.signList[2].hasSign = this.userInfo.sign_3
              this.signList[3].hasSign = this.userInfo.sign_4
              this.signList[4].hasSign = this.userInfo.sign_5
              this.signList[5].hasSign = this.userInfo.sign_6
              this.signList[6].hasSign = this.userInfo.sign_7
              // this.signList.map((x) => {
              //   if (x.ind <= this.signdays) {
              //     x.hasSign = true;
              //   } else {
              //     x.hasSign = false;
              //   }
              //   return x;
              // });
            }
          })
        })
    },
    getCouponFunction(item) {
      console.log(item, '--------')
      getCoupon({ couponId: item.id }).then((res) => {
        if (res.code == 200) {
          if (res.data.forward == 'yes') {
            var forwardTag = res.data.forwardTag
            this.$dialog
              .confirm({
                // title: this.$t('Total'),
                messageAlign:'left',
                showCancelButton:false,
                confirmButtonText:'OK',
                message: this.$t(
                  'If you are unable to open the recharge page, please use mobile data.(Do not use wifi).'
                ),
              })
              .then(() => {
                if (forwardTag == '30') {
                  this.showRechargeLoading = true
                  this.$refs.pay30_45.click()
                } else if (forwardTag == '50') {
                  this.showRechargeLoading = true
                  this.$refs.pay50_80.click()
                } else if (forwardTag == '100') {
                  this.showRechargeLoading = true
                  this.$refs.pay100_200.click()
                } else if (forwardTag == '500') {
                  this.showRechargeLoading = true
                  this.$refs.pay500_700.click()
                } else if (forwardTag == '1000') {
                  this.showRechargeLoading = true
                  this.$refs.pay1000_1300.click()
                }
              })
              .catch(() => {
                // on cancel
              })
          } else {
            this.$toast.success({
              message: res.data.msg,
              position: 'top',
            })
            if (res.data.refresh == 'yes') {
              //this.refresh();
              //不进行页面刷新，仅对列表数据进行修改
              this.taskList.forEach((item) => {
                if (item.id == res.data.couponId) {
                  item.userCoupon.userCouponState = res.data.couponState
                }
              })
            }
          }
        } else {
          this.$toast.fail({
            message: res.msg,
            position: 'top',
          })
        }
      })
    },
    toggleShow1() {
      this.showCollapse1 = !this.showCollapse1
    },
    refresh() {
      location.reload()
    },
  },
}
</script>

<style lang="scss" scoped>
.name-box {
  box-shadow: 0px 2px 6px 1px rgba(71, 71, 71, 0.16);
  height: 162px;
  display: flex;
  align-items: center;
  justify-content: center;

  .name-box-lf {
    margin-right: 17px;
  }

  .avatar-img {
    width: 90px;
    height: 90px;
    border-radius: 50%;
  }

  .name-text {
    color: #273458;
    font-weight: 400;
    margin-right: 13px;
    font-size: 36px;
  }

  .edit-img {
    width: 26px;
    height: 26px;
  }

  .mail-text {
    font-size: 28px;
    font-weight: 400;
    color: #273458;
  }
}

.main-item1 {
  padding: 0 30px;

  .money-box {
    margin: 20px 0;
    display: flex;
    align-items: center;
    justify-content: center;

    .money-box-lf {
      margin-right: 20px;
      padding: 0px 28px;
      border: 1px solid #3d4c76;
      box-sizing: border-box;
      height: 106px;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: space-between;

      .money-box-head-text {
        font-size: 32px;
        font-weight: 400;
        color: #273458;
        text-align: right;
      }

      .money-box-type {
        font-size: 23px;
        font-weight: 400;
        text-align: right;
        color: #273458;
      }

      .money-box-head-img {
        height: 60px;
        width: 60px;
      }
    }

    .money-box-rg {
      background: linear-gradient(90deg, #4e608f 0%, #273458 100%);
      height: 106px;
      padding: 0px 28px;
      box-shadow: inset 0px 3px 6px 1px rgba(0, 0, 0, 0.16);
      box-sizing: border-box;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: space-between;

      .money-box-head-text {
        font-size: 32px;
        font-weight: 400;
        text-align: right;
        color: #ffffff;
      }

      .money-box-type {
        font-size: 23px;
        font-weight: 400;
        color: #ffffff;
        text-align: right;
      }

      .money-box-head-img {
        height: 60px;
        width: 60px;
      }
    }
  }

  .line {
    height: 0px;
    opacity: 0.2;
    border: 1px solid #adadad;
  }
  .span_info {
    font-size: 25px;
    font-weight: 400;
    color: #1f1a17;

    .span_info_weight {
      font-weight: 600;
    }
  }

  .recharge-item-box {
    margin: 21px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .recharge-item-flex {
      display: flex;
      align-items: center;
    }

    .wallet-img {
      width: 33px;
      height: auto;
      margin-right: 16px;
      line-height: 35px;
    }

    .recharge-text {
      font-size: 28px;
      font-weight: bold;
      line-height: 35px;
      color: #273458;
    }

    .right-icon-img {
      width: 12px;
      height: auto;
    }

    .top-icon-img {
      height: 12px;
      width: auto;
    }
  }

  .recharge-box {
    padding: 10px 26px;

    .recharge-flex-box {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;

      .recharge-item {
        width: calc(30% - 9px);
        height: 116px;
        border: 1px solid rgba(39, 52, 88, 0.27);
        background: #ffffff;
        margin-bottom: 18px;
        padding: 15px 20px;
        padding-right: 7px;
        box-sizing: border-box;
      }

      .recharge-money {
        font-size: 29px;
        font-weight: bold;
        color: #1f1a17;
        margin-bottom: 10px;
      }

      .recharge-btc {
        font-size: 25px;
        font-weight: 400;
        color: #1f1a17;
      }

      .activeRechargeBg {
        background: #273458;

        .recharge-money {
          color: #f3f3f3;
        }

        .recharge-btc {
          color: #f3f3f3;
        }
      }
    }

    .money-inp {
      height: 90px;
      margin: 65px 0;
      background: #ffffff;
      border: 1px solid #273458;
      align-items: center;
    }

    :deep(.van-field__control) {
      font-size: 28px;
    }

    :deep(.van-field__control::placeholder) {
      text-align: center;
    }

    .confirm-btn-box {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .confirm-btn {
      height: 90px;
      width: 408px;
      font-size: 24px;
      font-weight: bold;
      color: #ffffff;
      background: #273458;
      box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
    }
  }
}

.bg-div {
  background: #f0f0f0;
  height: 20px;
}

.main-item2 {
  padding: 0 30px;
  margin: 5px 0px;

  .sign-content {
    height: auto;
    background-color: rgb(39, 52, 86);
    border: 1px solid rgb(39, 52, 86);
    border-radius: 5px;

    .tips {
      color: #ffffff;
    }

    .tips2 {
      border-bottom: 1px solid #fff;
    }

    .sign-view {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border-bottom: 1px solod #fff;

      p {
        color: #fff;
        font-size: 36px;
        margin: 20px 0px;
      }

      .sign-show {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        align-items: center;

        .sign-show-content {
          width: 10%;
          height: 140px;
          margin: 5px 10px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          background-color: rgba(255, 255, 255, 0.1);
          color: #fff;
          border-radius: 5px;
          display: flex;
          flex-direction: column;
          justify-content: space-around;
          align-items: center;

          .sign-show-list {
            display: flex;
            flex-direction: row;
            justify-content: space-around;
            align-items: center;

            ::v-deep .van-checkbox__icon--checked .van-icon {
              background-color: rgb(255, 240, 202) !important;
            }
          }
        }
      }

      .confirm-btn {
        width: 60%;
        height: 90px;
        // background: #273458;
        box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
        border: 1px solid #ffffff;
        border-radius: 45px;
        font-size: 26px;
        color: #ffffff;
        font-weight: 400;
        margin-top: 10px;
        margin-bottom: 10px;
      }
    }

    .sign-rules {
      color: #fff;
      font-size: 24px;
      padding: 10px;

      .sign-rules-head {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
      }

      .task-list {
        color: #333;

        .task-content {
          width: 100%;
          height: 140px;
          border: 1px solid rgb(255, 240, 202);
          border-radius: 5px;
          margin: 20px 0px;
          background-color: rgb(255, 240, 202);

          .task-item {
            padding: 5px 10px;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;

            .task-item-head {
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              font-size: 30px;
            }

            .task-item-foot {
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              align-items: center;

              .task-item-foot-left {
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                width: 70%;
                font-size: 18px;
              }

              .task-item-foot-right {
                width: 260px;
                height: 85px;
                border: 1px solid #fb5151;
                border-radius: 5px;
                background-color: #fb5151;
                color: #fff;
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                align-items: center;

                .menu-item-img {
                  width: 64px;
                  height: auto;
                  margin-right: 32px;
                }

                span {
                  font-size: 36px;
                  margin-left: 10px;
                }
              }
            }
          }
        }
      }
    }
  }

  .cash-item-box {
    margin: 21px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .recharge-item-flex {
      display: flex;
      align-items: center;
    }

    .wallet-img {
      width: 33px;
      height: auto;
      margin-right: 16px;
      line-height: 35px;
    }

    .recharge-text {
      font-size: 28px;
      font-weight: bold;
      line-height: 35px;
      color: #273458;
    }

    .right-icon-img {
      width: 12px;
      height: auto;
    }
    .top-icon-img {
      height: 12px;
      width: auto;
    }
  }

  .num-box {
    margin: 30px 0;
    padding: 36px;
    background-image: url('../../assets/images/personal/num-bg.png');
    background-size: cover;
    /* 调整背景图片大小以完全覆盖元素 */
    background-position: center center;
    /* 将背景图像位于元素的中心 */
    background-repeat: no-repeat;
    /* 防止图像重复 */
  }

  .num-box-text {
    font-size: 28px;
    font-weight: 400;
    color: #ffffff;
  }

  .num-flex-box {
    margin: 34px 0;
    padding: 30px 0;
    display: flex;
    align-items: center;
    border-top: 1px solid #b3b3b3;
    border-bottom: 1px solid #b3b3b3;
  }

  .num-flex-item {
    flex: 1;
  }

  .num-flex-item-title {
    font-size: 26px;
    font-weight: 400;
    color: #ffffff;
    text-align: center;
    margin-bottom: 24px;
  }

  .num-flex-item-num {
    font-size: 32px;
    font-weight: bold;
    color: #ffffff;
    text-align: center;
  }

  .address-box {
    margin: 13px;
    display: flex;
    align-items: center;
  }

  .address-box-lf {
    padding: 10px 20px;
    font-size: 24px;
    font-weight: 400;
    background: #ffffff;
    border: 1px solid #e2e2e2;
    color: #989898;
    height: 50px;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    box-sizing: border-box;
  }

  .address-box-rg {
    font-size: 26px;
    background: #4e5f8b;
    width: 233px;
    height: 50px;
    font-weight: 400;
    padding: 10px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #f3f3f3;
    text-align: center;
    box-sizing: border-box;
    border: 1px solid #4e5f8b;
  }
}

.main-item3 {
  padding: 0 30px;
  margin-bottom: 120px;

  .menu-item {
    padding: 30px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #e1e1e1;
  }

  .menu-item-flex {
    display: flex;
    align-items: center;
  }

  .menu-item-img {
    width: 32px;
    height: auto;
    margin-right: 32px;
  }

  .menu-item-title {
    font-size: 28px;
    font-weight: bold;
    color: #707070;
  }

  .menu-item:last-child {
    border-bottom: none;
  }

  .right-icon-img {
    width: 12px;
    height: auto;
  }
}

// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;

  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;

    .muen-icon-img {
      width: 35px;
      height: 35px;
      margin-right: 10px;
    }
  }

  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }

  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }

  .nickName-content {
    height: 100%;
  }

  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }

  .font-line {
    font-family: 'Helvetica', sans-serif;
    position: relative;
    display: inline-block;
    font-size: 24px;
  }
  .font-line.after {
    content: '---';
    position: absolute;
    left: 0;
    top: 50%;
    width: 100%;
    height: 1px;
    background-color: #000000;
    transform: translateY(-50%) rotate(-45deg);
  }

  .buy-with-crypto {
    color: white;
    border: 1px solid black;
    background: #273458;
    padding-bottom: 10px;
    padding-top: 10px;
    padding-left: 15px;
    padding-right: 15px;
    font-size: medium;
  }
}

.sign_text {
  width: 40px;
  height: 40px;
  background: white;
  border-radius: 50%;
  color: black;
  text-align: center;
  font-size: initial;
  font-weight: normal;
}
</style>
<style scoped>
:deep(.van-overlay) {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
