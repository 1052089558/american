<template>
  <div class="page">
    <div class="logo-title">abcd69</div>
    <div class="ipt-box">
      <div class="ipt-main">
        <div class="ipt-title">
           <span class="ipt-item-title"> Click </span>
           <span class="ipt-pth" @click="attention" style="color: #273458;">abcd69.com</span> 
           <span class="ipt-item-title"> to return homepage </span>           
        </div>
        <div class="ipt-item">
          <div class="ipt-item-title">Enter your email</div>
          <van-field class="ipt-item-input" v-model="email" />
        </div>
        <div class="ipt-item">
          <div class="ipt-item-title">Enter your password</div>
          <van-field
            class="ipt-item-input"
            type="password"
            v-model="password"
          />
          <div class="forgot-text" @click="goForget">Forgot password</div>
        </div>
      </div>
      <div class="confirm-box">
        <van-button class="confirm-btn" @click="login">Log in</van-button>
        <van-button class="confirm-btn" @click="goRegister">Register account</van-button>        
      </div>
      <!-- google一键登录 -->
      <!-- <div class="g_id_signin" id="g_id_signin" style="display: flex;justify-content: center;align-items: center;margin-top: 30px   ;"></div> -->
    </div>
    <!-- <recaptchaabcd69Vue></recaptchaabcd69Vue> -->
  </div>
</template>

<script>

import App from '@/App.vue';
// import jwt_decode from "jwt-decode";
import { apiLoginApp,apiGetGoogleUserInfo } from "../../request/api";
import recaptchaabcd69Vue from './recaptchaabcd69.vue';
export default {
  components: { recaptchaabcd69Vue },
  name: "login",
  data() {
    return {
      email: "",
      password: "",
      code: "",
      GOOGLE_CLIENT_ID:"646698369970-290t0v2teo285anmfiv3oteqtgjmecac.apps.googleusercontent.com",
    };
  },
  goLogin() {
    this.$router.push("/login");
  },
  created() {
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    document.body.appendChild(script);

    window.addEventListener("load", () => {
      window.google.accounts.id.initialize({
        // 主要就是填写client_id
        client_id: this.GOOGLE_CLIENT_ID,
        auto_select: false,
        callback: this.handleCredentialResponse,
      });
      // 设置按钮的样式等
      window.google.accounts.id.renderButton(
        document.getElementById("g_id_signin"),
        {
          theme: "filled_blue",
          size: "samll",
          // width:'320',
          type: "standard",
          text: "signin_with",
        }
      );
    });



  },
  mounted() {},
  methods: {
    handleError(){
      console.log("check fail.");
    },
    handleSuccess (){
      console.log("check success.");
    },
    attention(){
      this.$router.push("/");
    },
    goForget() {
      this.$router.push("/forget");
    },
    goRegister() {
      this.$router.push("/register");
    },
    login() {
      apiLoginApp({
        username: this.email,
        password: this.password,
      }).then((res) => {
        if (res.code == 200) {
          console.log(res);
          localStorage.setItem("key", res.token);
          localStorage.setItem("userId",res.userId);
          localStorage.setItem("invitationCode",res.invitationCode);
          // this.$toast.success(res.msg);
          // this.$toast.success("登录成功");
          this.$router.replace("/");
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },

    async handleCredentialResponse(response) {
      // 获取回调响应的凭证数据 然后拿这个凭证给后台，jwt进行解析获取登录信息
      await apiGetGoogleUserInfo({idTokenString:response.credential}).then(
        (res) => {
          if (res.code == 200) {
            console.log(res);
            localStorage.setItem("key", res.token);
            localStorage.setItem("userId",res.userId);
            localStorage.setItem("invitationCode",res.invitationCode);
            // this.$toast.success(res.msg);
            // this.$toast.success("登录成功");
            this.$router.replace("/");
          } else {
            this.$toast.fail(res.msg);
          }
        }
      );
      // const profile = jwt_decode(response.credential);  // 解析返回的信息
      // id = profile.sub; email = profile.email;  需要什么取什么，然后传给后端验证
      // console.log("GOOGLE response:", profile);
    },

  },
};
</script>

<style lang="scss" scoped>
.logo-title {
  font-size: 70px;
  font-weight: 800;
  color: #273458;
  margin: 166px auto 194px;
  text-align: center;
}
.ipt-item-input {
  border: 1px solid #a6a6a6;
  height: 90px;
  align-items: center;
}
:deep(.van-field__control) {
  font-size: 28px;
}
.ipt-box {
  padding: 0 56px;
  .ipt-main {
    .ipt-title{
      font-size: 32px;
      font-weight: 500;
      margin-bottom: 30px;
      .ipt-pth{
        font-size: 38px;
        font-weight: 800;

      }
    }
    .ipt-item {
      margin-bottom: 40px;
    }
    .ipt-item-title {
      color: #273458;
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 20px;
    }

    .forgot-text {
      font-size: 24px;
      font-weight: 400;
      color: #273458;
      text-align: right;
      margin-top: 15px;
    }
  }
  .confirm-box {
    margin-top: 170px;
    .confirm-btn {
      width: 100%;
      height: 90px;
      background: #273458;
      box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
      border: 1px solid #ffffff;
      font-size: 26px;
      color: #ffffff;
      font-weight: 400;
      margin-bottom: 20px;
    }
  }
}
</style>
