<template>
  <div class="page">
    <div v-if="status == 0">
      <div class="logo-title">abcd69</div>
      <div class="ipt-box">
        <div class="ipt-main">
          <div class="ipt-header">Create account</div>
          <div class="ipt-item">
            <div class="ipt-item-title">Email</div>
            <van-field class="ipt-item-input" v-model="email" />
          </div>
          <div class="ipt-item">
            <div class="ipt-item-title">Create a password</div>
            <van-field
              class="ipt-item-input"
              v-model="password"
              :type="showPassword ? 'text' : 'password'"
            />
            <div class="ipt-info">Minimum 6 characters required</div>
          </div>
          <div class="show-psd">
            <van-checkbox
              v-model="showPassword"
              shape="square"
              checked-color="#273458"
              >Show password</van-checkbox
            >
          </div>
        </div>
        <div class="confirm-box">
          <van-button class="confirm-btn" @click="sendEmail"
            >Verify email</van-button
          >
        </div>
        <div class="login-box">
          <van-button class="confirm-btn" @click="goLogin"
          >Log in</van-button
          >
        </div>
        <div class="ipt-title">Click <span class="ipt-pth" @click="attention" style="color: #273458;">abcd69.com</span> to return homepage</div>

      </div>
    </div>

    <div class="mail-box" v-if="status == 1">
      <div class="mail-box-title">Verify email address</div>
      <div class="mail-box-info">
        To Verify your email, We've sent a One time password (verification code) to email,please input in 15 minutes
      </div>
      <div class="ipt-item">
        <div class="ipt-item-title">Enter verification code</div>
        <van-field class="ipt-item-input" v-model="code" />
      </div>
      <van-button class="confirm-btn" @click="register"
        >Create your account</van-button
      >
      <van-button style="margin-top:10px;" class="confirm-btn" @click="goLogin"
      >back</van-button
      >
      <div class="mail-box-info-text">
        By creating an account,you agree to <span @click="clickUserAgreement" class="user-agreement" style="color: #273458;">《Conditions of Use》</span> and Privacy
        Notict.
      </div>
      <div class="ipt-title">Click <span class="ipt-pth" @click="attention" style="color: #273458;">abcd69.com</span> to return homepage</div>
      <div class="reset-box" @click="sendEmail">Resend verification code</div>
    </div>
    <van-popup v-model="showUserAgreement">
      <div class="popup-box">
        <div class="popup-head">
          <img
          class="muen-icon-img"
          src="@/assets/images/home/UserAgreement.png"
          />
          User Agreement
        </div>
        <img
          @click="showUserAgreement = false"
          class="close-icon"
          src="@/assets/images/close-icon.png"
          alt=""
        />
        <div class="content-Agreement">
          <p>Terms of Service:</p>
          <span>
            &nbsp;&nbsp;&nbsp;&nbsp;abcd69.com is a web site (the "Site") that hosts classified advertising and related 
            content created and developed by third-party users. Your use of the Site, including 
            all access, services and/or features, is governed by these Terms of Use and the 
            Privacy Policy (collectively, "Terms"), and you should review both carefully. By 
            using the Site in any way, you are agreeing to comply with these Terms.The Site 
            reserves the right to change the Terms at any time and for any reason. Updated versi  ns 
            of the Terms will be posted to the Site at abcd69.com and you should visit this page 
            periodically to keep apprised of any changes. abcd69.com provides advertising services 
            for individuals.Users who publish advertisements and related content information 
            on the Site shall comply with the laws of the local country and region.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;The advertising in the Site only stand for the Site users,it does not represent 
            the Site.If the violations of laws and regulations, the user will be borne by 
            themselves,the Site does not assume any legal responsibility.If user uses the Site, 
            representing user has read and agreed the Terms.By continuing to use the Site after 
            any such change, you accept and agree to the modified Terms.The Site reserves the 
            right to modify or discontinue, temporarily or permanently, the Site, any site features,
             benefits (including without limitation blocking or terminating your Account), rules 
             or conditions, all without notice, even though such changes may affect the way you 
             use the Site. You agree that the Site will not be liable to you or any third-party 
             for any modification or discontinuance of the Site.
          </span>
          <p>User Conduct:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;Without limitation, you agree to refrain from the following actions while using the Site:<br>
          1.&nbsp;&nbsp;Harassing, threatening, embarrassing or causing distress or discomfort upon another individual 
          or entity or impersonating any other person or entity or otherwise restricting or inhibiting any
           other person from using or enjoying the Site;<br>
          2.&nbsp;&nbsp;Transmitting any information, data, text, files, links, software, chats, communication or 
          other materials that is unlawful, false, misleading, harmful, threatening, abusive, invasive 
          of another's privacy, harassing, defamatory, vulgar, obscene, hateful or racially or otherwise 
          objectionable, including without limitation material of any kind or nature that encourages 
          conduct that could constitute a criminal offense, give rise to civil liability or otherwise 
          violate any applicable local, state, provincial, national, or international law or regulation, 
          or encourage the use of controlled substances;<br>
          3.&nbsp;&nbsp;Posting advertising or solicitation in categories that is not appropriate, or posting the 
          same item or service in more than one category or more than once every 7 days, or posting the 
          same ad in multiple cities on the Site;<br>
          4. (a) Posting adult content or explicit adult material and any material country to the law 
            which is enforce.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(b) Posting, anywhere on the Site, obscene or lewd and lascivious graphics or photographs 
            which depict genitalia or actual or simulated sexual acts, or any act which suggest or promote 
            sexual acts or solicits sexual favor.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(c) Posting any solicitation directly or in “coded” fashion for any illegal service 
            exchanging sexual favors for money or other valuable consideration;<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(d) Posting any material on the Site that exploits minors in any way;<br>
            &nbsp;&nbsp;&nbsp;&nbsp;(e) Posting any material on the Site that in any way constitutes or assists in human trafficking.<br>
          5.&nbsp;&nbsp; Posting any ad for products or services, use or sale of which is prohibited by any law or regulation;<br>
          6.&nbsp;&nbsp;Sending mail, e-mail, voice messages or faxes for solicitation of any other product, or 
          service to a user of the Site unless the user has granted permission in their ad or otherwise
           allowed contact for solicitation;<br>
          7.&nbsp;&nbsp;Deleting or revising any material posted by any other user;<br>
          8.&nbsp;&nbsp;Interfering with or infringing the patents, copyrights, trademarks, service marks, logos, 
          confidential information or intellectual property rights of others;<br>
          9.&nbsp;&nbsp;Using any automated device, spider, robot, crawler, data mining tool, software or routine 
          to access, copy, or download any part of the Site unless expressly permitted by the Site;<br>
          10.&nbsp;&nbsp;Taking any action creating a disproportionately large usage load on the Site unless expressly
           permitted by the Site:<br>
          11.&nbsp;&nbsp;Sending messages or engaging in disruptive or damaging activities online, including excessive 
          use of scripts, sound waves, scrolling, or use of viruses, bots, worms, time bombs, Trojan horses
           or any other destructive element;<br>
          12.&nbsp;&nbsp;Gaining or attempting to gain unauthorized access to non-public areas of the Site. In addition, 
          if you have a password to a non-public area of the Site, you may not disclose to, or share your 
          password, with any third parties and/or use your password for unauthorized purposes;<br>
          13.&nbsp;&nbsp;Attempting to decipher, decompile, disassemble or reverse engineer any of the software comprising 
          or in any way making up all or any part of the Site; modifying any meta data, copying or duplicating 
          in any manner any of the content; framing of or linking to any of the Site, its content or information 
          available from the Site without the express written consent of agents of the Site;<br>
          14.&nbsp;&nbsp;Discriminating on the grounds of race, religion, national origin, gender, disability, 
          age, marital status, sexual orientation, or refers to such matters in any manner prohibited by law;<br>
          15.&nbsp;&nbsp;Posting any employment ads violating the anti-discrimination provisions of the Immigration 
          and Nationality Act or messages which violate any law or regulation, or any ad which violate labor 
          law of the country.<br>
          16.&nbsp;&nbsp;Using the Site to engage in or assist another individual or entity to engage in fraudulent, 
          abusive, manipulative or illegal activity.<br>
          17.&nbsp;&nbsp;Posting free ads promoting links to commercial services or web sites except in areas of the Site 
          where such ads are expressly permitted;<br>
          <p>Use of Materials:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;Any ads or messages that you post, transmit, or otherwise make available for viewing on public areas of the Site will be treated as non-confidential and non-proprietary to you. You understand and agree that any such ads and messages may be used by the Site or our affiliates, without review or approval by you, for any purpose whatsoever, and in any medium, including our print media, if any. You grant the Site (and our affiliates) the irrevocable right to use and/or edit your ads and messages, without review or approval by you, for any purpose whatsoever, including, without limitation, reproduction, disclosure, transmission, publication, broadcast, posting, and advertising in any media in perpetuity without notice or compensation to you.
          <p>Termination of Access:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;The Site has the right terminate your access for any reason if we believe you have violated these Terms in any manner. You agree not to hold the Site liable for such termination, and further agree not to attempt to use the Site after termination.
          <p>No Third Party Beneficiaries:</p>
          &nbsp;&nbsp;&nbsp;&nbsp;You agree that, except as otherwise provided in this Terms of Use, there shall be no third party beneficiaries to these Terms.
        </div>
        <div class="confirm-btn" @click="showUserAgreement = false">confirm</div>
      </div>
    </van-popup>
    <div class="info-box" v-if="status == 2">
      <div class="logo-title">abcd69</div>
      <div class="info-main">
        <div class="info-img-box">
          <img
            class="info-img"
            src="../../assets/images/login/success.png"
            alt=""
          />
        </div>
        <div class="info-text">Congratulations on completing registration</div>
        <van-button class="info-btn" @click="login">Confirm</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import {
  apiGetVerificationCode,
  apiRegister,
  apiForgotEmail,
  apiLoginApp,
} from "../../request/api";
export default {
  name: "register",
  data() {
    return {
      email: "",
      password: "",
      code: "",
      status: 0,
      showPassword: false,
      showUserAgreement:false
    };
  },
  created() {},
  mounted() {},
  methods: {
    clickUserAgreement(){
      this.showUserAgreement=true
    },
    attention(){
      this.$router.push("/");
    },
    sendEmail() {
      const mailReg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
      //const pass = /(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[\W]).{6,}/;
      const pass =/^\S{6,}$/;
      if (!mailReg.test(this.email)) {
        this.$toast.success(" Email format\n incorrect");
      }else if(!pass.test(this.password)){
        this.$toast.success("Minimum 6 characters required");
      }else{
        apiGetVerificationCode({
          userName:this.email,
          type:'register'
        }).then((res) => {
          if (res.code == 200) {
            this.status = 1;
            this.$toast.success(res.msg);
          }else{
          this.$toast.fail(res.msg);
          }
        });
      }
    },
    goLogin() {
      this.$router.push("/login");
    },
    register() {
      const mailReg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
      //const pass = /(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[\W]).{6,}/;
      const pass =/^\S{6,}$/;
      if (!mailReg.test(this.email)) {
        this.$toast.success("邮箱格式不正确");
      }else if(!pass.test(this.password)){
        this.$toast.success("密码不可少于六位数");
      }else{
        apiForgotEmail({
          username: this.email,
          code: this.code,
        }).then((res) => {
          if (res.code == 200) {
            console.log(res);
            apiRegister({
              username: this.email,
              password: this.password,
            }).then((res) => {
              if (res.code == 200) {
                this.status = 2;
                console.log(res);
              } else {
                this.$toast.fail(res.msg);
              }
            });
          } else {
            this.$toast.fail(res.msg);
          }
        });
      }
    },
    login() {
      apiLoginApp({
        username: this.email,
        password: this.password,
      }).then((res) => {
        if (res.code == 200) {
          console.log(res);
          localStorage.setItem("userId",res.userId);
          localStorage.setItem("key", res.token);
          localStorage.setItem("invitationCode",res.invitationCode);
          this.$toast.success(res.msg);
          this.$router.replace("/");
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.logo-title {
  font-size: 70px;
  font-weight: 800;
  color: #273458;
  margin: 166px auto 0;
  text-align: center;
}
.ipt-box {
  margin-top: 196px;
  padding: 0 56px;
  .ipt-title{
      margin-top: 40px;
      float: right;
      font-size: 26px;
      font-weight: 500;
      margin-bottom: 30px;
      .ipt-pth{
        font-size: 32px;
        font-weight: 800;

      }
    }
  .ipt-main {
    .ipt-header {
      color: #273458;
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 40px;
    }
    .ipt-item {
      margin-bottom: 40px;
    }
    .ipt-item-title {
      color: #273458;
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .ipt-item-input {
      border: 1px solid #a6a6a6;
      height: 90px;
      align-items: center;
    }
    :deep(.van-field__control) {
      font-size: 28px;
    }
    .code-box {
      display: flex;
      align-items: center;
    }
    .code-item-input {
      border: 1px solid #a6a6a6;
      height: 90px;
      align-items: center;
      flex: 1;
    }
    .ipt-info {
      color: #273458;
      font-size: 26px;
      margin: 10px 0;
    }
    .show-psd {
      margin: 20px 0;
    }

    :deep(.van-checkbox__label) {
      font-size: 28px;
      line-height: 36px;
    }
    :deep(.van-checkbox__icon) {
      font-size: 36px;
    }
    .code-button {
      width: 262px;
      height: 90px;
      background: #273458;
      font-size: 26px;
      font-weight: 400;
      color: #ffffff;
      border: 1px solid #273458;
      box-sizing: border-box;
    }
  }
  .confirm-box {
    margin-top: 170px;
    .confirm-btn {
      width: 100%;
      height: 90px;
      background: #273458;
      box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
      border: 1px solid #ffffff;
      font-size: 26px;
      color: #ffffff;
      font-weight: 400;
    }
  }
  .login-box {
    margin-top: 25px;
    .confirm-btn {
      width: 100%;
      height: 90px;
      background: #273458;
      box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
      border: 1px solid #ffffff;
      font-size: 26px;
      color: #ffffff;
      font-weight: 400;
    }
  }
}
.info-box {
  padding: 0 90px;
  margin-top: 212px;
  .info-main {
    border: 1px solid #a6a6a6;
    padding: 51px 35px 20px;
    margin-top: 160px;

    .info-img-box {
      width: 78px;
      text-align: center;
      height: 78px;
      background: #21b66d;
      border-radius: 50%;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .info-img {
      width: 30px;
      height: 21px;
    }
    .info-text {
      margin-top: 60px;
      font-size: 26px;
      font-weight: 400;
      color: #000000;
      text-align: center;
    }
    .info-btn {
      width: 100%;
      height: 73px;
      background: #273458;
      box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
      border: 1px solid #ffffff;
      font-size: 26px;
      color: #ffffff;
      font-weight: 400;
      margin-top: 60px;
    }
  }
}
.mail-box {
  padding: 0 40px;
  margin-top: 100px;
  .mail-box-title {
    margin: 0 0 40px;
    font-size: 30px;
    font-weight: 600;
    color: #273458;
  }
  .mail-box-info {
    margin: 0 0 70px;
    font-size: 26px;
    font-weight: 600;
    color: #273458;
  }
  .ipt-item {
    margin-bottom: 60px;
  }
  .ipt-item-title {
    color: #273458;
    font-size: 28px;
    font-weight: bold;
    margin-bottom: 20px;
  }
  .ipt-item-input {
    border: 1px solid #a6a6a6;
    height: 90px;
    align-items: center;
  }
  :deep(.van-field__control) {
    font-size: 28px;
  }

  .confirm-btn {
    width: 100%;
    height: 90px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
    border: 1px solid #ffffff;
    font-size: 26px;
    color: #ffffff;
    font-weight: 400;
  }
  .mail-box-info-text {
    color: #273458;
    font-size: 26px;
    margin: 20px 0 60px;
    .user-agreement{
      font-size: 30px;
      font-weight: 600;
    }
  }
  .ipt-title{
      margin-top:20 px;
      font-size: 26px;
      font-weight: 500;
      margin-bottom: 30px;
      .ipt-pth{
        font-size: 32px;
        font-weight: 800;

      }
    }
  .reset-box {
    color: #273458;
    font-size: 30px;
    text-align: center;
  }
}
// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
    .muen-icon-img{
      width: 35px;
      height: 35px;
      margin-right: 10px;
    }
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }

  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 150px;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }
  .content-Agreement{
    margin: 5px 5px;
    padding: 15px;
    height: 800px;
    overflow-y: auto;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }
  .content-Feedback{
    margin: 21px 35px;
    padding: 15px;
    height: 400px;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }
  .contact-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 210px;
    font-size: 24px;
    float: left;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
</style>
