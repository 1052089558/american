<template>
  <div class="page">
    <div class="header" v-if="isEdit == false">
      <van-nav-bar
        title="Post AD"
        :left-arrow="stepOneAndTwo == true ? false : true"
        @click-left="onClickLeft"
      />
    </div>

    <div class="header" v-if="isEdit == true">
      <div class="header-title">details</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>

    <div class="content">
      <div class="step-box" v-if="!vipPublish">
        <div class="step-title">Just 5 mins to publish an ad</div>
        <div class="step-imgBox">
          <img
            class="step-imgBox-img"
            src="../../assets/images/postAd/success.png"
            alt=""
          />
          <div class="green-line"></div>
          <img
            class="step-imgBox-img"
            src="../../assets/images/postAd/success.png"
            alt=""
          />
          <div class="green-line"></div>
          <img
            v-if="stepOneAndTwo"
            class="step-imgBox-img"
            src="../../assets/images/postAd/three.png"
            alt=""
          />
          <img
            v-if="stepThree"
            class="step-imgBox-img"
            src="../../assets/images/postAd/success.png"
            alt=""
          />
          <img
            v-if="stepFour"
            class="step-imgBox-img"
            src="../../assets/images/postAd/success.png"
            alt=""
          />
          <div class="black-line" v-if="!stepFour"></div>
          <div class="green-line" v-if="stepFour"></div>

          <img
            v-if="!stepFour"
            class="step-imgBox-img"
            src="../../assets/images/postAd/four.png"
            alt=""
          />
          <img
            v-if="stepFour"
            class="step-imgBox-img"
            src="../../assets/images/postAd/success.png"
            alt=""
          />
        </div>
        <div class="step-textBox">
          <span class="step-text1">Category</span>
          <span class="step-text2">location</span>
          <span class="step-text3">Detail</span>
          <span class="step-text4">Publish</span>
        </div>
      </div>
      <!-- 步骤一二的分类和地区选择 -->
      <div
        class="category-box"
        v-if="stepOneAndTwo"
        :style="{ 'pointer-events': isEdit == true ? 'none' : '' }"
      >
        <div class="category-header">
          <img
            class="category-box-img"
            src="../../assets/images/postAd/one.png"
            alt=""
          />
          <div class="category-header-title">Category</div>
        </div>
        <div class="choose-info">Choose a Category for Your Ad</div>
        <div
          class="category-item"
          v-for="item in classificationList"
          :key="item.dictValue"
          :class="{ activeCategoryBg: category == item.dictValue }"
          @click="checkClassification(item)"
        >
          {{ item.dictLabel }}
        </div>
      </div>
      <div class="location-box" v-if="stepOneAndTwo">
        <div class="location-header">
          <img
            class="location-box-img"
            src="../../assets/images/postAd/two.png"
            alt=""
          />
          <div class="location-header-title">Select the city</div>
        </div>
        <div class="location-info">Choose 1 city only</div>
        <!-- 地区选择 -->
        <!-- <h1>地区选择框TODO</h1> -->
        <!-- 选择框 -->
        <div class="showRight-box">
          <div class="area-flex-box" @click="show_are = !show_are">
            <div class="area-box-lf">{{ deptTree_select }}</div>
            <div class="area-box-rg">
              <img
                class="bottom-icon-bl-img"
                src="../../assets/images/home/bottom-icon-bl.png"
                alt=""
              />
            </div>
          </div>
          <!-- 选择框弹出 -->
          <van-popup
            v-model="show_are"
            round
            position="bottom"
            :style="{
              height: '90%',
              margin: '10px',
              width: '-webkit-fill-available',
            }"
          >
            <img
              style="z-index: 99; position: absolute; left: 90%; top: 1%"
              width="24px"
              height="24px"
              src="../../assets/images/postAd/close_black.png"
              alt=""
              @click="show_are = false"
            />
            <van-radio-group v-model="deptTree_select_id">
              <van-cell-group>
                <van-cell
                  style="
                    font-size: 20px;
                    height: 40px;
                    line-height: 40px;
                    position: relative;
                  "
                  center
                >
                  <!-- @click="showcountries" -->
                  <template>
                    <div
                      class="area-box-rg"
                      style="
                        /* background-color: #f3f3f3; */
                        width: 65%;
                        padding: 20px 20px;
                        position: relative;
                      "
                    >
                      USA
                      <!-- <img
                        v-if="!showcountriesflag"
                        width="14px"
                        height="14px"
                        src="../../assets/images/home/right-icon1.png"
                        alt=""
                        style="position: absolute; right: 20px; top: 10px"
                      />
                      <img
                        v-else
                        class="bottom-icon-bl-img"
                        width="14px"
                        height="14px"
                        src="../../assets/images/home/down-icon1.png"
                        alt=""
                        style="position: absolute; right: 20px; top: 10px"
                      /> -->
                    </div>
                  </template>
                </van-cell>
                <!-- <div
                  class="location-select-box"
                  v-if="showcountriesflag"
                  style="
                    width: 65%;
                    height: 100%;
                    border: 2px solid #f3f3f3;
                    background-color: #fff;
                    position: absolute;
                    top: 40px;
                    left: 8px;
                    z-index: 9999;
                    font-size: 18px;
                    padding: 30px 13px 10px;
                  "
                  >
                  <img
                    style="position: absolute; top: 5px; right: 5px"
                    width="20px"
                    height="20px"
                    src="../../assets/images/postAd/close_black.png"
                    alt=""
                    @click="showcountriesflag = false"
                  />
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="country_select">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in deptTreeCountries"
                              clickable
                              :key="item.deptId"
                              :title="item.cityName"
                              @click="selectTocity(item)"
                              style="
                                height: 40px;
                                border-bottom: 1px solid #f3f3f3;
                                font-size: 20px;
                                line-height: 30px;
                              "
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.parentId"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div> -->
                <van-cell
                  :title="item.cityName"
                  clickable
                  center
                  @click="Check_deptTree_select(item)"
                  v-for="(item, index) in deptTree"
                  :key="index"
                  style="font-size: 20px; height: 40px; padding: 0px 20px"
                >
                  <template #right-icon>
                    <van-radio
                      :name="item.cityName"
                      icon-size="20px"
                      shape="square"
                      checked-color="#273458"
                    />
                  </template>
                </van-cell>
              </van-cell-group>
            </van-radio-group>
          </van-popup>

          <!-- 选择框弹出2 -->
          <div class="location-select-box" v-if="show_are_maney">
            <div class="location-list">
              <div class="location-state">
                <div class="location-list-box">
                  <van-checkbox-group
                    v-model="dept_list_select"
                    @change="Change_dept_list_select"
                  >
                    <van-cell-group>
                      <van-cell
                        v-for="(item, index) in dept_list"
                        clickable
                        :key="item.cityId + item.cityName"
                        :title="item.cityName"
                        @click="toggle(index)"
                        style="
                          font-size: 14px !important;
                          line-height: 20px;
                          font-weight: 700;
                        "
                      >
                        <template #right-icon>
                          <span
                            style="
                              font-size: 14px !important;
                              margin-right: 5px;
                              line-height: 20px;
                              font-weight: 700;
                            "
                            >$:{{ item.maney }}USD</span
                          >
                          <van-checkbox
                            ref="checkboxes"
                            checked-color="#273458"
                            icon-size="20px"
                            :name="item"
                          />
                        </template>
                      </van-cell>
                    </van-cell-group>
                  </van-checkbox-group>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="totol">
          <div class="location-select-box">
            <div class="location-list">
              <div class="location-state">
                <div class="location-list-box">
                  <van-cell-group>
                    <!-- <van-cell  style="font-weight: 700;font-size: 14px;padding: 10px 0px;height: 35px;"> -->
                    <p
                      style="
                        font-weight: 700;
                        font-size: 14px;
                        padding: 10px 0px;
                        border-bottom: 1px solid #f4f4f4;
                      "
                    >
                      Summary
                    </p>
                    <!-- <template #right-icon> </template> -->
                    <!-- </van-cell> -->
                    <div
                      v-if="categorytext"
                      style="font-weight: 700; margin-left: 9px; color: #323233"
                    >
                      {{ categorytext + ' - 30Days' }}
                    </div>
                    <van-cell
                      v-for="item in dept_list_select"
                      :key="item.cityId + dept_list_select"
                      :title="item.cityName"
                      style="
                        font-size: 14px !important;
                        line-height: 40px;
                        font-weight: 700;
                      "
                    >
                      <template #right-icon>
                        <span
                          style="
                            font-size: 14px !important;
                            line-height: 20px;
                            font-weight: 700;
                            margin-right: 10px;
                          "
                          >$:{{ item.maney }}USD</span
                        >
                        <img
                          class="close-img"
                          src="../../assets/images/postAd/close_black.png"
                          alt=""
                          @click="removeCity(item)"
                        />
                      </template>
                    </van-cell>
                    <van-cell :title="' '">
                      <template #right-icon>
                        <span
                          style="
                            font-size: 14px !important;
                            line-height: 20px;
                            font-weight: 700;
                          "
                          >Total $:<strong
                            >{{ dept_list_select_totol }} USD</strong
                          ></span
                        >
                      </template>
                    </van-cell>
                  </van-cell-group>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="confirm-btn" @click="goStepThree">Continue</div>
      </div>

      <!-- 步骤三的详情填写 又分普通、vip、商铺 -->
      <div class="detail-box" v-if="stepThree">
        <div class="normal-box" v-if="normalPublish">
          <div class="normal-city-iptBox">
            <div class="city-header">
              <div class="city-header-lf">
                <img
                  class="city-three-img"
                  src="../../assets/images/postAd/three.png"
                  alt=""
                />
              </div>
              <div class="city-header-rg">
                <p class="header-rg-p1">Detail</p>
              </div>
            </div>
            <div>
              <div class="city-detail-info">
                Please provide the selected city and the specific l ocation
                information for customer visits. It is crucial to provide
                accurate location details as it determines the number of
                potential customers you may receive later on. (To protect your
                privacy and safety, you can provide the detailed street
                information of public places within a 100 meter radius of your
                service location)
              </div>
              <div class="ipt-flexBox">
                <van-radio-group
                  checked-color="#21b66d"
                  v-model="selectCity"
                  icon-size="20px"
                  style="display: none"
                >
                  <van-radio
                    v-for="(item, index) in dept_list_select"
                    :name="item.cityName"
                    :key="index"
                    style="
                      font-size: 18px;
                      margin-top: 5px;
                      padding-bottom: 10px;
                    "
                    @click="chooseCity(item)"
                    >{{ item.cityName }}</van-radio
                  >
                </van-radio-group>
                <div class="flexBox-lf1">
                  <div style="width: 70%">
                    <div ref="refAddress">
                      <span style="color: red">*</span>Address
                    </div>
                    <van-field
                      type="textarea"
                      class="city-ipt"
                      v-model="street_info"
                      placeholder="street Information"
                      style="
                        height: 100%;
                        border-top-width: 0px;
                        border-right-width: 0px;
                        border-bottom-width: 1px;
                        border-left-width: 0px;
                        font: initial;
                      "
                      @input="streetInfoChange()"
                    />
                  </div>

                  <div style="width: 20%" ref="refInputCity">
                    <div><span style="color: red">*</span>City</div>
                    <van-field
                      type="textarea"
                      class="city-ipt"
                      v-model="user_input_city_name"
                      placeholder="city"
                      style="
                        height: 100%;
                        border-top-width: 0px;
                        border-right-width: 0px;
                        border-bottom-width: 1px;
                        border-left-width: 0px;
                        font: initial;
                      "
                      @input="streetInfoChange()"
                    />
                  </div>
                </div>
                <div class="flexBox-lf1" style="justify-content: center">
                  <van-button
                    size="normal"
                    :disabled="streetInfoStatus"
                    :style="{
                      width: '80%',
                      height: '100%',
                      'margin-left': '5px',
                      'background-color':
                        isConfirmStreetInfo == true ? '#F9F284' : '#F2F15F',
                      color: 'black',
                      'font-size': 'large',
                    }"
                    @click="getNearBys"
                    >confirm address</van-button
                  >

                  <div
                    class="isConfirmStreetInfo"
                    :style="{
                      display: isConfirmStreetInfo == true ? '' : 'none',
                    }"
                  >
                    <span>√</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="normal-person-iptBox">
            <div class="normal-person-iptBox1">
              <div style="font-size: 20px; margin: -10px 0px">About</div>
              <van-form>
                <div class="num-info" style="color: #273458" ref="refName">
                  <span style="color: red">*</span> Name
                </div>
                <div>
                  <van-field
                    class="city-ipt"
                    v-model="name"
                    type="text"
                    :rules="[{ required: true, message: 'Please fill in' }]"
                  />
                </div>

                <div class="ipt-title" style="color: #273458" ref="refAge">
                  <span style="color: red">*</span> Age
                </div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = !showAgeBox),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ ageName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>

                  <van-popup
                    style="
                      padding: 10px;
                      width: 300px;
                      background: #eeeeee;
                      height: 500px;
                    "
                    v-model="showAgeBox"
                  >
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="age">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in ageList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseAge(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </van-popup>
                </div>

                <div
                  class="num-info"
                  style="color: #273458"
                  ref="refPhoneEmail"
                >
                  <span style="color: red">*</span> Phone number or Email
                  <div
                    class="num-info"
                    style="
                      color: gray;
                      margin-top: 0px;
                      margin-bottom: 0px;
                      margin-left: 15px;
                      font-size: 0.3rem;
                    "
                  >
                    Fill in one or two
                  </div>
                </div>

                <div>
                  <div style="display: flex">
                    <!-- <van-field
                      class="city-ipt"
                      v-bind="full_areacode_text"
                      placeholder="Code"
                      style="width: 40%; margin-right: 10px; margin-top: 5px"
                      @click="areaCodeShow=true"
                    /> -->
                    <van-cell
                      class="city-ipt"
                      style="
                        margin-top: 5px;
                        margin-bottom: 5px;
                        width: 40%;
                        font: caption;
                      "
                      :value="
                        (this.schemaInput.selectedObjDefault.iso2 == undefined
                          ? 'usa'
                          : this.schemaInput.selectedObjDefault.iso2) +
                        ' +' +
                        this.phone_area_code
                      "
                      @click="areaCodeShow = true"
                    />

                    <VueCountryIntl
                      schema="modal"
                      modal-class="modal-class"
                      :visible.sync="areaCodeShow"
                      v-model="phone_area_code"
                      cancelText="X"
                      searchInputPlaceholder="select"
                      @onChange="onDefaultChange"
                    >
                      <template slot="vueCountryNoData"
                        ><h1>not data！</h1></template
                      >
                    </VueCountryIntl>

                    <van-field
                      class="city-ipt"
                      v-model="phone_number"
                      type="number"
                      placeholder="Phone number"
                      style="margin: 5px 0px"
                    />
                  </div>

                  <van-field
                    class="city-ipt"
                    v-model="email"
                    type="email"
                    placeholder="Email"
                    style="margin: 5px 0px"
                  />
                </div>
              </van-form>
            </div>
          </div>

          <div class="normal-person-iptBox">
            <div class="ipt-flexBox">
              <div class="flexBox-lf" style="width: 100%">
                <div class="ipt-title" style="color: #273458">Gender</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = !showgenderBox),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ genderName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="location-select-box" v-if="showgenderBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="gender">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in genderList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseGender(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="ipt-flexBox">
              <div class="flexBox-lf">
                <div class="ipt-title" style="color: #273458">Ethnicity</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = !showRaceBox),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ raceName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>

                  <van-popup
                    style="padding: 10px; width: 300px; background: #eeeeee"
                    v-model="showRaceBox"
                  >
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="race">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in raceList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseRace(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </van-popup>
                </div>
              </div>

              <div class="flexBox-rg">
                <div class="ipt-title">Breast size</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = !showbreastSizeBox),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ breastSizeName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>

                  <van-popup
                    style="padding: 10px; width: 300px; background: #eeeeee"
                    v-model="showbreastSizeBox"
                  >
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="breastSize">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in breastSizeList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseBreastSize(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </van-popup>
                </div>
              </div>
            </div>

            <div class="ipt-flexBox">
              <div class="flexBox-lf">
                <div class="ipt-title">Weight</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = !showWeightBox),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ weightName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>

                  <van-popup
                    style="padding: 10px; width: 300px; background: #eeeeee"
                    v-model="showWeightBox"
                  >
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="weight">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in weightList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseWeight(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </van-popup>
                </div>
              </div>

              <div class="flexBox-rg">
                <div class="ipt-title">Height</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = !showHeightBox),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ heightName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>

                  <van-popup
                    style="padding: 10px; width: 300px; background: #eeeeee"
                    v-model="showHeightBox"
                  >
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="height">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in heightList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseHeight(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </van-popup>
                </div>
              </div>
            </div>

            <div class="ipt-flexBox">
              <div class="flexBox-lf">
                <div class="ipt-title">Hair color</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = !showhairColorBox),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ hairColorName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="location-select-box" v-if="showhairColorBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="hairColor">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in hairColorList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseHairColor(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="flexBox-rg">
                <div class="ipt-title">Hair length</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = !showhairLengthBox),
                        (showeyeColorBox = false),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ hairLengthName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="location-select-box" v-if="showhairLengthBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="hairLength">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in hairLengthList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseHairLength(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="ipt-flexBox">
              <div class="flexBox-lf">
                <div class="ipt-title">Eye color</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = !showeyeColorBox),
                        (showTravelBox = false)
                    "
                  >
                    <div class="area-box-lf">
                      {{ eyeColorName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="location-select-box" v-if="showeyeColorBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="eyeColor">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in eyeColorList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseEyeColor(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="flexBox-rg">
                <div class="ipt-title">Travel</div>
                <div class="lang-box">
                  <div
                    class="area-flex-box"
                    @click="
                      ;(showHeightBox = false),
                        (showWeightBox = false),
                        (showRaceBox = false),
                        (showgenderBox = false),
                        (showLanguageBox = false),
                        (showbreastSizeBox = false),
                        (showhairColorBox = false),
                        (showAgeBox = false),
                        (showOccupationBox = false),
                        (showRecommendSection = false),
                        (showhairLengthBox = false),
                        (showeyeColorBox = false),
                        (showTravelBox = !showTravelBox)
                    "
                  >
                    <div class="area-box-lf">
                      {{ travelName }}
                    </div>
                    <div class="area-box-rg">
                      <img
                        class="bottom-icon-bl-img"
                        src="../../assets/images/home/bottom-icon-bl.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="location-select-box" v-if="showTravelBox">
                    <div class="location-list">
                      <div class="location-state">
                        <div class="location-list-box">
                          <van-radio-group v-model="travel">
                            <van-cell-group>
                              <van-cell
                                class="state-cell"
                                v-for="item in travelList"
                                clickable
                                :key="item.dictValue"
                                :title="item.dictLabel"
                                @click="chooseTravel(item)"
                              >
                                <template #right-icon>
                                  <van-radio
                                    icon-size="20px"
                                    shape="square"
                                    checked-color="#273458"
                                    :name="item.dictValue"
                                  />
                                </template>
                              </van-cell>
                            </van-cell-group>
                          </van-radio-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="normal-person-iptBox">
            <div style="margin-top: 10px">
              <div
                style="font-size: 19px; font-weight: 700; color: #273458"
                ref="refAvailableTo"
              >
                <span style="color: red">*</span> Available TO
              </div>
              <div class="ipt-title" style="font-size: 18px" ref="refOneOrMore">
                Select one or more
              </div>
              <van-checkbox-group
                v-model="oneOrMoreAvailable"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-checkbox
                  v-for="(item, index) in list2"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="margin-top: 5px; width: 100px"
                  >{{ item.dictLabel }}</van-checkbox
                >
              </van-checkbox-group>
            </div>

            <div style="margin-top: 10px">
              <div
                class="ipt-title"
                style="font-size: 18px; color: #273458"
                ref="refProvideAs"
              >
                <span style="color: red">*</span> ServIce provide as
              </div>
              <van-checkbox-group
                v-model="provideService"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-checkbox
                  v-for="(item, index) in list3"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="margin-top: 5px; width: 100px"
                  >{{ item.dictLabel }}</van-checkbox
                >
              </van-checkbox-group>
            </div>

            <div style="margin-top: 10px">
              <div
                class="ipt-title"
                style="font-size: 18px; color: #273458"
                ref="refIndependent"
              >
                <span style="color: red">*</span>Independent
              </div>
              <van-radio-group
                v-model="independent"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-radio
                  v-for="(item, index) in list4"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="margin-top: 5px; width: 100px"
                  >{{ item.dictLabel }}</van-radio
                >
              </van-radio-group>
            </div>
          </div>

          <div class="normal-upload-box">
            <div class="upload-title" ref="refPhotos">Upload Your Photos</div>
            <div class="upload-info">
              High-definition, sexy and beautiful photos are better. The first
              photo is the cover. Nine photos at most. Naked photos are not
              allowed.
            </div>
            <div class="upload-img-box">
              <div class="upload-container">
                <div class="upload-item-box">
                  <van-loading ref="images_one_uploading" size="24px"
                    >uploading...<template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_one_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template>
                  </van-loading>
                  <CUT
                    :size_w="164"
                    :size_h="175"
                    :name="'images_one'"
                    :uploadingStop="images_one_uploading_stop"
                    @UpUrl="UpUrl"
                    @showImagesUploading="showImagesUploading"
                    @showImagesUploadingClose="showImagesUploadingClose"
                  ></CUT>
                  <div class="uploader-box" v-if="images_one == ''">
                    <img
                      class="upload-icon"
                      src="../../assets/images/postAd/upload.png"
                      alt=""
                    />
                    <div class="upload-icon-text">Click to upload pictures</div>
                    <div
                      class="upload-icon-text"
                      style="font-size: medium; font-weight: 600; color: red"
                      >
                      *Thumbnail
                    </div>
                  </div>
                  <div class="uploader-img" v-else>
                    <div class="delImg" @click="images_one = ''">
                      <span>X</span>
                    </div>
                    <img :src="images_one" alt="" />
                  </div>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_two_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_two_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile2" multiple>
                    <div class="uploader-box" v-if="images_two == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_two = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_two" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_three_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_three_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile3" multiple>
                    <div class="uploader-box" v-if="images_three == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_three = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_three" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_four_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_four_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile4" multiple>
                    <div class="uploader-box" v-if="images_four == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_four = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_four" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_five_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_five_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile5" multiple>
                    <div class="uploader-box" v-if="images_five == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_five = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_five" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_six_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_six_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile6" multiple>
                    <div class="uploader-box" v-if="images_six == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_six = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_six" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_seven_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_seven_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile7" multiple>
                    <div class="uploader-box" v-if="images_seven == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_seven = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_seven" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_eight_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_eight_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile8" multiple>
                    <div class="uploader-box" v-if="images_eight == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_eight = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_eight" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="images_nine_uploading" size="24px"
                    >uploading...
                    <template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('images_nine_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <van-uploader :after-read="uploadFile9" multiple>
                    <div class="uploader-box" v-if="images_nine == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <div class="delImg" @click="images_nine = ''">
                        <span>X</span>
                      </div>
                      <img :src="images_nine" alt="" />
                    </div>
                  </van-uploader>
                </div>
              </div>
            </div>

            <div style="text-align: center">
              <span style="color: gray">At least 4 photos are required</span>
            </div>
          </div>

          <!-- 增加视频上传 -->
          <!-- <div class="normal-upload-box">
            <div class="upload-title">video</div>
            <div class="upload-info">
              Naked videos& genitalia are NOT ALLOWED. This includes topless
              video. <br />
              Max.video length is 20 sec or 10MB. This only uploads video files.
            </div>
            <div class="text-area-box">
              <van-uploader
                :after-read="uploadVideoFunc"
                accept="video/*"
                :max-size="10 * 1024 * 1024"
                @oversize="onOversize"
              >
                <div class="uploader-box" v-if="videos_one == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload video</div>
                </div>
                <div class="uploader-img" v-else>
                  <div
                    class="delImg"
                    style="
                      left: 85%;
                      z-index: 3;
                      text-align: center;
                      font-size: xx-large;
                    "
                    @click="videos_one = ''"
                  >
                    <span>X</span>
                  </div>
                  <video :src="videos_one" controls>
                    <source src="movie.mp4" type="video/mp4" />
                    <source src="movie.ogg" type="video/ogg" />
                    <source src="movie.webm" type="video/webm" />
                    <object data="movie.mp4">
                      <embed src="movie.swf" />
                    </object>
                  </video>
                </div>
              </van-uploader>
            </div>
          </div> -->

          <div class="normal-upload-box">
            <div class="upload-title">Introduce</div>
            <div class="upload-info">
              Please don't include "bj","bbbj","bbfs","greek",etc.Illegal
              content is not allowed.
            </div>
            <div class="text-area-box">
              <van-field
                v-model="introduce"
                rows="3"
                autosize
                :border="true"
                type="textarea"
                placeholder="Enter text information,Within 300 words"
              />
            </div>
          </div>

          <div class="normal-adType-box" v-if="isEdit == false">
            <div class="rec-box" v-if="configurationList[0]">
              <div class="adType-header">
                <div class="ad-header-lf">
                  <img
                    class="ad-header-img"
                    src="../../assets/images/postAd/recommendedAdShow.png"
                    alt=""
                  />
                </div>
                <div class="ad-header-rg">
                  <div class="ad-header-rg-1">Recommended ad</div>
                  <div class="ad-header-rg-2">
                    Your ad will be on the homepage of the your area.All viewers
                    will see it first. Highly recommended.
                  </div>
                  <div v-if="false" class="ad-header-rg-3">
                    ${{ configurationList[0].configValue }} per day
                  </div>
                </div>
              </div>
              <div class="adType-line"></div>
              <div
                @click="chooseType(type)"
                class="type-upgrade-box"
                :style="{
                  'border-color':
                    showRecommendSection == true ? 'red' : 'black',
                }"
              >
                <!-- <div class="upgrade-box" >Upgrade to Recommended ad</div> -->
                <div>
                  <img
                    style="width: 190px; height: 22px"
                    src="../../assets/images/myAds/recommendedAD.png"
                  />
                </div>

                <div
                  class="upgradeIsCheck"
                  :style="{
                    display: showRecommendSection == true ? '' : 'none',
                    color: 'red',
                  }"
                >
                  <span>√</span>
                </div>

                <van-checkbox-group
                  v-model="type"
                  ref="recommondRef"
                  style="display: none"
                >
                  <van-checkbox
                    name="3"
                    icon-size="20px"
                    checked-color="#273458"
                    @click="chooseType(type)"
                  ></van-checkbox>
                </van-checkbox-group>
              </div>

              <div style="padding-bottom: 15px" v-if="showRecommendSection">
                <div class="upload-title">Advertising cover image</div>
                <div class="upload-img-box">
                  <div class="upload-container">
                    <div class="upload-item-box">
                      <van-loading ref="recommendImageOne_uploading" size="24px"
                        >uploading...
                        <template>
                          <div
                            style="
                              font-size: large;
                              position: relative;
                              display: inline;
                              bottom: 20px;
                            "
                            @click="
                              stopUploading('recommendImageOne_uploading')
                            "
                          >
                            <span>X</span>
                          </div>
                        </template></van-loading
                      >
                      <CUT
                        :size_w="176"
                        :size_h="236"
                        :name="'recommendImageOne'"
                        :uploadingStop="recommendImageOne_uploading_stop"
                        @UpUrl="UpUrl"
                        @showImagesUploading="showImagesUploading"
                        @showImagesUploadingClose="showImagesUploadingClose"
                      ></CUT>
                      <div class="uploader-box" v-if="recommendImageOne == ''">
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <div class="delImg" @click="recommendImageOne = ''">
                          <span>X</span>
                        </div>
                        <img :src="recommendImageOne" alt="" />
                      </div>
                    </div>
                    <div class="upload-item-box">
                      <van-loading ref="recommendImageTwo_uploading" size="24px"
                        >uploading...
                        <template>
                          <div
                            style="
                              font-size: large;
                              position: relative;
                              display: inline;
                              bottom: 20px;
                            "
                            @click="
                              stopUploading('recommendImageTwo_uploading')
                            "
                          >
                            <span>X</span>
                          </div>
                        </template></van-loading
                      >
                      <CUT
                        :size_w="153"
                        :size_h="112"
                        :name="'recommendImageTwo'"
                        :uploadingStop="recommendImageTwo_uploading_stop"
                        @UpUrl="UpUrl"
                        @showImagesUploading="showImagesUploading"
                        @showImagesUploadingClose="showImagesUploadingClose"
                      ></CUT>
                      <div class="uploader-box" v-if="recommendImageTwo == ''">
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <div class="delImg" @click="recommendImageTwo = ''">
                          <span>X</span>
                        </div>
                        <img :src="recommendImageTwo" alt="" />
                      </div>
                    </div>
                    <div class="upload-item-box">
                      <van-loading
                        ref="recommendImageThree_uploading"
                        size="24px"
                      >uploading...
                        <template>
                          <div
                            style="
                              font-size: large;
                              position: relative;
                              display: inline;
                              bottom: 20px;
                            "
                            @click="
                              stopUploading('recommendImageThree_uploading')
                            "
                          >
                            <span>X</span>
                          </div>
                        </template></van-loading
                      >
                      <CUT
                        :size_w="153"
                        :size_h="112"
                        :name="'recommendImageThree'"
                        :uploadingStop="recommendImageThree_uploading_stop"
                        @UpUrl="UpUrl"
                        @showImagesUploading="showImagesUploading"
                        @showImagesUploadingClose="showImagesUploadingClose"
                      ></CUT>
                      <div
                        class="uploader-box"
                        v-if="recommendImageThree == ''"
                      >
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <div class="delImg" @click="recommendImageThree = ''">
                          <span>X</span>
                        </div>
                        <img :src="recommendImageThree" alt="" />
                      </div>
                    </div>
                  </div>
                  <div style="text-align: center">
                    <span style="color: gray"
                      >At least 3 photos are required</span
                    >
                  </div>
                </div>
                <div
                  class="price-box"
                  v-for="item in dept_list_select_ad"
                  :key="item.cityName + 'ad'"
                >
                  <div class="price-box-1">{{ item.cityName }}</div>
                  <div class="price-box-2">
                    ${{ item.recommendShowPreDay * 10 }}/10 Days
                    <van-radio-group v-model="selected1">
                      <van-radio
                        name="10"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseRecommend('10', 0)"
                        ref="refRecommend10"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                  <div class="price-box-3">
                    ${{ item.recommendShowPreDay * 30 }}/30 Days
                    <van-radio-group v-model="selected1">
                      <van-radio
                        name="30"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseRecommend('30', 1)"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                </div>
              </div>
            </div>

            <div class="big-line"></div>

            <div class="rec-box" v-if="configurationList[1]">
              <div class="adType-header">
                <div class="ad-header-lf">
                  <img
                    class="ad-header-img"
                    src="../../assets/images/postAd/topAdShow.png"
                    alt=""
                  />
                </div>
                <div class="ad-header-rg">
                  <div class="ad-header-rg-1">Top ad</div>
                  <div class="ad-header-rg-2">
                    Your ad will be on the top of other normal ads,and 4 times
                    bigger than normal ad.It's easy to get viewer's attention.
                  </div>
                  <div v-if="false" class="ad-header-rg-3">
                    ${{ configurationList[1].configValue }} per day
                  </div>
                </div>
              </div>
              <div class="adType-line"></div>
              <div
                @click="chooseTypeTop(type)"
                class="type-upgrade-box"
                :style="{
                  'border-color': showTopSection == true ? 'blue' : 'black',
                }"
              >
                <!-- <div class="upgrade-box" >Upgrade to Top ad</div> -->
                <div>
                  <img
                    style="width: 190px; height: 22px"
                    src="../../assets/images/myAds/topAD.png"
                  />
                </div>
                <div
                  class="upgradeIsCheck"
                  :style="{
                    display: showTopSection == true ? '' : 'none',
                    color: 'blue',
                  }"
                >
                  <span>√</span>
                </div>

                <van-checkbox-group
                  v-model="type"
                  ref="topRef"
                  style="display: none"
                >
                  <van-checkbox
                    name="2"
                    icon-size="20px"
                    checked-color="#273458"
                    @click="chooseTypeTop(type)"
                  ></van-checkbox>
                </van-checkbox-group>
              </div>
              <div style="padding-bottom: 15px" v-if="showTopSection">
                <div class="upload-title">Advertising cover image</div>
                <div class="upload-img-box">
                  <div
                    class="upload-container"
                    style="
                      display: flex;
                      justify-content: center;
                      align-items: center;
                    "
                  >
                    <div class="upload-item-box">
                      <van-loading ref="largeImage_uploading" size="24px"
                        >uploading...
                        <template>
                          <div
                            style="
                              font-size: large;
                              position: relative;
                              display: inline;
                              bottom: 20px;
                            "
                            @click="stopUploading('largeImage_uploading')"
                          >
                            <span>X</span>
                          </div>
                        </template></van-loading
                      >
                      <CUT
                        :size_w="337"
                        :size_h="266"
                        :name="'largeImage'"
                        :uploadingStop="largeImage_uploading_stop"
                        @UpUrl="UpUrl"
                        @showImagesUploading="showImagesUploading"
                        @showImagesUploadingClose="showImagesUploadingClose"
                      ></CUT>
                      <div class="uploader-box" v-if="largeImage == ''">
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <div class="delImg" @click="largeImage = ''">
                          <span>X</span>
                        </div>
                        <img :src="largeImage" alt="" />
                      </div>
                    </div>
                  </div>
                  <div style="text-align: center">
                    <span style="color: gray"
                      >At least 1 top photo are required</span
                    >
                  </div>
                </div>
                <div
                  class="price-box"
                  v-for="item in dept_list_select_ad_top"
                  :key="item.cityName + 'top'"
                >
                  <div class="price-box-1">{{ item.cityName }}</div>
                  <div class="price-box-2">
                    ${{ item.topShowPreDay * 10 }}/10 Days
                    <van-radio-group v-model="selected2">
                      <van-radio
                        name="10"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseTop('10', 1)"
                        ref="refTop10"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                  <div class="price-box-3">
                    ${{ item.topShowPreDay * 30 }}/30 Days
                    <van-radio-group v-model="selected2">
                      <van-radio
                        name="30"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseTop('30', 1)"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="shop-box" v-if="shopPublish">
          <div class="shop-city-iptBox">
            <!-- <div class="city-info">
              According to a study done by University of Michigan researchers,
              shopping to relieve stress was up to 40 time smore effective at
              giving people a sense of control andshoppers were three times less
              sad compared to those thatonly browsed for items.
            </div> -->
            <div class="city-header">
              <div class="city-header-lf">
                <img
                  class="city-three-img"
                  src="../../assets/images/postAd/three.png"
                  alt=""
                />
              </div>
              <div class="city-header-rg">
                <p class="header-rg-p1">
                  Shop info <span class="header-rg-p2">(* must fll)</span>
                </p>
              </div>
            </div>
            <div class="city-title">* shop name</div>
            <van-field class="city-ipt" v-model="shopname" />
            <div class="num-info">* Your phone number</div>
            <div>
              <van-field
                class="city-ipt"
                v-model="phone_number"
                placeholder="fill in"
              />
            </div>

            <div
              class="ipt-flexBox"
              style="
                display: flex;
                flex-direction: column;
                justify-content: space-around;
                align-items: flex-start;
                margin-top: 10px;
              "
            >
              <p style="height: 35px; font-size: 14px">{{ selectCity }}</p>
              <div
                class="flexBox-lf1"
                style="
                  display: flex;
                  flex-direction: row;
                  justify-content: flex-start;
                  align-items: center;
                  width: 100%;
                  height: 40px;
                "
              >
                <span style="color: red">*</span>
                <van-field
                  class="city-ipt"
                  v-model="street_info"
                  placeholder="street Information"
                  style="width: 80%; height: 100%"
                  @input="streetInfoChange()"
                />
                <van-button
                  size="normal"
                  :disabled="streetInfoStatus"
                  style="
                    width: 20%;
                    height: 100%;
                    margin-left: 5px;
                    background-color: #273458;
                    color: #fff;
                  "
                  @click="getNearBys"
                  >confirm</van-button
                >
              </div>
            </div>

            <!-- <div class="city-detail-info">
              * Please fll location or the street
            </div>
            <div class="ipt-flexBox">
              <div class="flexBox-lf">
                <van-field
                  class="city-ipt"
                  v-model="city_street"
                  placeholder="street"
                />
              </div>
              <div class="flexBox-rg">
                <van-field
                  class="city-ipt"
                  v-model="city_number"
                  placeholder="number"
                />
              </div>
            </div> -->
          </div>
          <div class="shop-person-iptBox">
            <div class="checkedOut-box">
              <div class="checkedOut-lf">Table Shower</div>
              <div class="checkedOut-rg">
                <van-radio-group v-model="table_shower" direction="horizontal">
                  <van-radio
                    name="1"
                    checked-color="#273458"
                    icon-size="20px"
                    style="margin-right: 20px"
                    >Yes</van-radio
                  >
                  <van-radio name="2" checked-color="##273458" icon-size="20px"
                    >No</van-radio
                  >
                </van-radio-group>
              </div>
            </div>
            <div class="checkedOut-box">
              <div class="checkedOut-lf">Sauna</div>
              <div class="checkedOut-rg">
                <van-radio-group v-model="sauna" direction="horizontal">
                  <van-radio
                    name="1"
                    checked-color="#273458"
                    icon-size="20px"
                    style="margin-right: 20px"
                    >Yes</van-radio
                  >
                  <van-radio name="2" checked-color="##273458" icon-size="20px"
                    >No</van-radio
                  >
                </van-radio-group>
              </div>
            </div>
            <div class="checkedOut-box">
              <div class="checkedOut-lf">Jacuzzi</div>
              <div class="checkedOut-rg">
                <van-radio-group v-model="jacuzzi" direction="horizontal">
                  <van-radio
                    name="1"
                    checked-color="#273458"
                    icon-size="20px"
                    style="margin-right: 20px"
                    >Yes</van-radio
                  >
                  <van-radio name="2" checked-color="##273458" icon-size="20px"
                    >No</van-radio
                  >
                </van-radio-group>
              </div>
            </div>
            <div class="checkedOut-box">
              <div class="checkedOut-lf">Accept credit card</div>
              <div class="checkedOut-rg">
                <van-radio-group
                  v-model="accept_credit_card"
                  direction="horizontal"
                >
                  <van-radio
                    name="1"
                    checked-color="#273458"
                    icon-size="20px"
                    style="margin-right: 20px"
                    >Yes</van-radio
                  >
                  <van-radio name="2" checked-color="##273458" icon-size="20px"
                    >No</van-radio
                  >
                </van-radio-group>
              </div>
            </div>
            <!-- Masseur todo  -->
            <div class="charging-box">
              <div class="charging-box-lf">Rate for 30 miuntes</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="ratefor30" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">Rate for 45 miuntes</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="ratefor45" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">Rate for60 miuntes</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="ratefor60" />
              </div>
            </div>
            <div class="charging-box">Hours</div>
            <div class="charging-box">
              <div class="charging-box-lf">mondayAm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="mondayAm" />
              </div>
              <div class="charging-box-lf">mondayPm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="mondayPm" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">tuesdayAm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="tuesdayAm" />
              </div>
              <div class="charging-box-lf">tuesdayPm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="tuesdayPm" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">wednesdayAm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="wednesdayAm" />
              </div>
              <div class="charging-box-lf">wednesdayPm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="wednesdayPm" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">thursdayAm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="thursdayAm" />
              </div>
              <div class="charging-box-lf">thursdayPm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="thursdayPm" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">fridayAm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="fridayAm" />
              </div>
              <div class="charging-box-lf">fridayPm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="fridayPm" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">saturdayAm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="saturdayAm" />
              </div>
              <div class="charging-box-lf">saturdayPm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="saturdayPm" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">sundayAm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="sundayAm" />
              </div>
              <div class="charging-box-lf">sundayPm</div>
              <div class="charging-box-rg">
                <van-field class="charging-ipt" v-model="sundayPm" />
              </div>
            </div>
            <div class="charging-box">
              <div class="charging-box-lf">Payment method:</div>
              <van-radio-group v-model="payment" direction="horizontal">
                <van-radio
                  name="1"
                  checked-color="##273458"
                  style="margin-right: 40px"
                  shape="square"
                  icon-size="20px"
                  >cash</van-radio
                >
                <van-radio
                  name="2"
                  checked-color="##273458"
                  shape="square"
                  icon-size="20px"
                  >bank
                </van-radio>
              </van-radio-group>
            </div>
          </div>
          <div class="shop-upload-box">
            <div class="upload-title">Upload Your Photos</div>
            <div class="upload-info">
              提示: 最少上传1张，最多8张，上传店铺门面
            </div>
            <div class="upload-img-box">
              <div class="upload-container">
                <!-- <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile1">
                    <div class="uploader-box" v-if="images_one == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_one" alt="" />
                    </div>
                  </van-uploader>
                </div> -->
                <div class="upload-item-box">
                  <CUT
                    :size_w="164"
                    :size_h="175"
                    :name="'images_one'"
                    @UpUrl="UpUrl"
                  ></CUT>
                  <div class="uploader-box" v-if="images_one == ''">
                    <img
                      class="upload-icon"
                      src="../../assets/images/postAd/upload.png"
                      alt=""
                    />
                    <div class="upload-icon-text">Click to upload pictures</div>
                  </div>
                  <div class="uploader-img" v-else>
                    <img :src="images_one" alt="" />
                  </div>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile2">
                    <div class="uploader-box" v-if="images_two == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_two" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile3">
                    <div class="uploader-box" v-if="images_three == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_three" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile4">
                    <div class="uploader-box" v-if="images_four == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_four" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile5">
                    <div class="uploader-box" v-if="images_five == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_five" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile6">
                    <div class="uploader-box" v-if="images_six == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_six" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile7">
                    <div class="uploader-box" v-if="images_seven == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_seven" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile8">
                    <div class="uploader-box" v-if="images_eight == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_eight" alt="" />
                    </div>
                  </van-uploader>
                </div>
                <div class="upload-item-box">
                  <van-uploader :after-read="uploadFile9">
                    <div class="uploader-box" v-if="images_nine == ''">
                      <img
                        class="upload-icon"
                        src="../../assets/images/postAd/upload.png"
                        alt=""
                      />
                      <div class="upload-icon-text">
                        Click to upload pictures
                      </div>
                    </div>
                    <div class="uploader-img" v-else>
                      <img :src="images_nine" alt="" />
                    </div>
                  </van-uploader>
                </div>
              </div>
            </div>
          </div>
          <div class="normal-adType-box">
            <div class="rec-box" v-if="configurationList[0]">
              <div class="adType-header">
                <div class="ad-header-lf">
                  <img
                    class="ad-header-img"
                    src="../../assets/images/postAd/recommendedAdShow.png"
                    alt=""
                  />
                </div>
                <div class="ad-header-rg">
                  <div class="ad-header-rg-1">Recommended ad</div>
                  <div class="ad-header-rg-2">
                    Your ad will be on the homepage of the your area.All viewers
                    will see it first. Highly recommended.
                  </div>
                  <div v-if="false" class="ad-header-rg-3">
                    ${{ configurationList[0].configValue }} per day
                  </div>
                </div>
              </div>
              <div class="adType-line"></div>
              <div
                class="type-upgrade-box"
                :style="{
                  'border-color':
                    showRecommendSection == true ? 'red' : 'black',
                }"
              >
                <!-- <div class="upgrade-box"  >Upgrade to Recommended ad</div> -->
                <div>
                  <img
                    style="width: 190px; height: 22px"
                    src="../../assets/images/myAds/recommendedAD.png"
                  />
                </div>
                <van-checkbox-group v-model="type" ref="recommondRef">
                  <van-checkbox
                    name="3"
                    icon-size="20px"
                    checked-color="#273458"
                    @click="chooseType(type)"
                  ></van-checkbox>
                </van-checkbox-group>
              </div>
              <div v-if="showRecommendSection">
                <div class="upload-title">Advertising cover image</div>
                <div class="upload-img-box">
                  <div class="upload-container">
                    <div class="upload-item-box">
                      <CUT
                        :size_w="176"
                        :size_h="236"
                        :name="'recommendImageOne'"
                        @UpUrl="UpUrl"
                      ></CUT>
                      <div class="uploader-box" v-if="recommendImageOne == ''">
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <img :src="recommendImageOne" alt="" />
                      </div>
                    </div>
                    <div class="upload-item-box">
                      <CUT
                        :size_w="153"
                        :size_h="112"
                        :name="'recommendImageTwo'"
                        @UpUrl="UpUrl"
                      ></CUT>
                      <div class="uploader-box" v-if="recommendImageTwo == ''">
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <img :src="recommendImageTwo" alt="" />
                      </div>
                    </div>
                    <div class="upload-item-box">
                      <CUT
                        :size_w="153"
                        :size_h="112"
                        :name="'recommendImageThree'"
                        @UpUrl="UpUrl"
                      ></CUT>
                      <div
                        class="uploader-box"
                        v-if="recommendImageThree == ''"
                      >
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <img :src="recommendImageThree" alt="" />
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="price-box"
                  v-for="item in dept_list_select_ad"
                  :key="item.cityName + 'ad'"
                >
                  <div class="price-box-1">{{ item.cityName }}</div>
                  <div class="price-box-2">
                    {{ item.recommendShowPreDay * 10 }}/10天
                    <van-radio-group v-model="selected1">
                      <van-radio
                        name="10"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseRecommend('10', 0)"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                  <div class="price-box-3">
                    {{ item.recommendShowPreDay * 30 }}/30天
                    <van-radio-group v-model="selected1">
                      <van-radio
                        name="30"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseRecommend('30', 1)"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                </div>
              </div>
            </div>

            <div class="rec-box" v-if="configurationList[1]">
              <div class="adType-header">
                <div class="ad-header-lf">
                  <img
                    class="ad-header-img"
                    src="../../assets/images/postAd/topAdShow.png"
                    alt=""
                  />
                </div>
                <div class="ad-header-rg">
                  <div class="ad-header-rg-1">Top ad</div>
                  <div class="ad-header-rg-2">
                    Your ad will be on the top of other normal ads,and 4 times
                    bigger than normal ad.It's easy to get viewer's attention.
                  </div>
                  <div v-if="false" class="ad-header-rg-3">
                    ${{ configurationList[1].configValue }} per day
                  </div>
                </div>
              </div>
              <div class="adType-line"></div>
              <div
                class="type-upgrade-box"
                :style="{
                  'border-color': showTopSection == true ? 'blue' : 'black',
                }"
              >
                <!-- <div class="upgrade-box" >Upgrade to Top ad</div> -->
                <div>
                  <img
                    style="width: 190px; height: 22px"
                    src="../../assets/images/myAds/topAD.png"
                  />
                </div>
                <van-checkbox-group v-model="type" ref="topRef">
                  <van-checkbox
                    name="2"
                    icon-size="20px"
                    checked-color="#273458"
                    @click="chooseTypeTop(type)"
                  ></van-checkbox>
                </van-checkbox-group>
              </div>
              <div v-if="showTopSection">
                <div class="upload-title">Advertising cover image</div>
                <div class="upload-img-box">
                  <div
                    class="upload-container"
                    style="
                      display: flex;
                      justify-content: center;
                      align-items: center;
                    "
                  >
                    <div class="upload-item-box">
                      <CUT
                        :size_w="337"
                        :size_h="266"
                        :name="'largeImage'"
                        @UpUrl="UpUrl"
                      ></CUT>
                      <div class="uploader-box" v-if="largeImage == ''">
                        <img
                          class="upload-icon"
                          src="../../assets/images/postAd/upload.png"
                          alt=""
                        />
                        <div class="upload-icon-text">
                          Click to upload pictures
                        </div>
                      </div>
                      <div class="uploader-img" v-else>
                        <img :src="largeImage" alt="" />
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="price-box"
                  v-for="item in dept_list_select_ad_top"
                  :key="item.cityName + 'top'"
                >
                  <div class="price-box-1">{{ item.cityName }}</div>
                  <div class="price-box-2">
                    {{ item.topShowPreDay * 10 }}/10天
                    <van-radio-group v-model="selected2">
                      <van-radio
                        name="10"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseTop('10', 1)"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                  <div class="price-box-3">
                    {{ item.topShowPreDay * 30 }}/30天
                    <van-radio-group v-model="selected2">
                      <van-radio
                        name="30"
                        icon-size="20px"
                        checked-color="#273458"
                        @click="chooseTop('30', 1)"
                      ></van-radio>
                    </van-radio-group>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- vip -->
        <div class="normal-box vip-box" v-if="vipPublish">
          <!-- 图片1 -->
          <div class="upload-item-box-vip-one">
            <van-loading ref="images_one_uploading" size="24px"
              >uploading...
              <template>
                <div
                  style="
                    font-size: large;
                    position: relative;
                    display: inline;
                    bottom: 20px;
                  "
                  @click="stopUploading('images_one_uploading')"
                >
                  <span>X</span>
                </div>
              </template></van-loading
            >
            <!-- <van-uploader :after-read="uploadFile1"> -->
            <CUT
              :size_w="306"
              :size_h="420"
              :name="'images_one'"
              :uploadingStop="images_one_uploading_stop"
              @UpUrl="UpUrl"
              @showImagesUploading="showImagesUploading"
              @showImagesUploadingClose="showImagesUploadingClose"
            ></CUT>
            <div class="uploader-box" v-if="images_one == ''">
              <img
                class="upload-icon"
                src="../../assets/images/postAd/upload.png"
                alt=""
              />
              <div class="upload-icon-text">Click to upload pictures</div>
              <div
                      class="upload-icon-text"
                      style="font-size: medium; font-weight: 600; color: red"
                      >
                      *Thumbnail
                    </div>
            </div>
            <div class="uploader-img" v-else>
              <div class="delImg-vip" @click="images_one = ''">
                <span>X</span>
              </div>
              <img :src="images_one" alt="" />
            </div>
            <!-- </van-uploader> -->
          </div>
          <div class="paragraph">
            <!-- <div class="paragraph-title">Aspen BanksIndependent Lscort</div> -->
            <!-- 标题1和内容1 -->
            <!-- <div class="paragraph-title-text">
              <van-field
                class="city-ipt"
                v-model="advertisementTitleOne"
                placeholder="Paragraph heading"
              />
            </div> -->
            <div class="paragraph-context">
              <tinymce-editor
                v-model="advertisementRemarkOne"
                :init="init_advertisementRemarkOne"
              ></tinymce-editor>
            </div>
            <!-- 标题2 -->
            <!-- <div class="paragraph-title">Aspen BanksIndependent Lscort</div> -->
            <!-- <div class="paragraph-title-text-w">
              <van-field
                class="city-ipt"
                v-model="advertisementTitleTwo"
                placeholder="Paragraph heading"
              />
            </div> -->
          </div>
          <!-- 图片2 -->
          <div class="upload-item-box-vip-one">
            <van-loading ref="images_two_uploading" size="24px"
              >uploading...
              <template>
                <div
                  style="
                    font-size: large;
                    position: relative;
                    display: inline;
                    bottom: 20px;
                  "
                  @click="stopUploading('images_two_uploading')"
                >
                  <span>X</span>
                </div>
              </template></van-loading
            >
            <van-uploader :after-read="uploadFile2">
              <div class="uploader-box" v-if="images_two == ''">
                <img
                  class="upload-icon"
                  src="../../assets/images/postAd/upload.png"
                  alt=""
                />
                <div class="upload-icon-text">Click to upload pictures</div>
              </div>
              <div class="uploader-img" v-else>
                <div class="delImg-vip" @click="images_two = ''">
                  <span>X</span>
                </div>
                <img :src="images_two" alt="" />
              </div>
            </van-uploader>
          </div>
          <!-- 图片3 -->
          <div class="upload-item-box-vip-one upload-item-box-vip-one-702">
            <van-loading ref="images_three_uploading" size="24px"
              >uploading...
              <template>
                <div
                  style="
                    font-size: large;
                    position: relative;
                    display: inline;
                    bottom: 20px;
                  "
                  @click="stopUploading('images_three_uploading')"
                >
                  <span>X</span>
                </div>
              </template></van-loading
            >
            <van-uploader :after-read="uploadFile3">
              <div class="uploader-box" v-if="images_three == ''">
                <img
                  class="upload-icon"
                  src="../../assets/images/postAd/upload.png"
                  alt=""
                />
                <div class="upload-icon-text">Click to upload pictures</div>
              </div>
              <div class="uploader-img" v-else>
                <div class="delImg-vip" @click="images_three = ''">
                  <span>X</span>
                </div>
                <img :src="images_three" alt="" />
              </div>
            </van-uploader>
          </div>
          <!-- 图片4 和 5  -->
          <div class="upload-item-box-vip-two">
            <div class="upload-item-box-vip-two-item">
              <van-loading ref="images_four_uploading" size="24px"
                >uploading...
                <template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_four_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile4">
                <div class="uploader-box" v-if="images_four == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg-vip" @click="images_four = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_four" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box-vip-two-item">
              <van-loading ref="images_five_uploading" size="24px"
                >uploading...
                <template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_five_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile5">
                <div class="uploader-box" v-if="images_five == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg-vip" @click="images_five = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_five" alt="" />
                </div>
              </van-uploader>
            </div>
          </div>
          <!-- 图片6 -->
          <div class="upload-item-box-vip-one upload-item-box-vip-one-501">
            <van-loading ref="images_six_uploading" size="24px"
              >uploading...
              <template>
                <div
                  style="
                    font-size: large;
                    position: relative;
                    display: inline;
                    bottom: 20px;
                  "
                  @click="stopUploading('images_six_uploading')"
                >
                  <span>X</span>
                </div>
              </template></van-loading
            >
            <van-uploader :after-read="uploadFile6">
              <div class="uploader-box" v-if="images_six == ''">
                <img
                  class="upload-icon"
                  src="../../assets/images/postAd/upload.png"
                  alt=""
                />
                <div class="upload-icon-text">Click to upload pictures</div>
              </div>
              <div class="uploader-img" v-else>
                <div class="delImg-vip" @click="images_six = ''">
                  <span>X</span>
                </div>
                <img :src="images_six" alt="" />
              </div>
            </van-uploader>
          </div>
          <!-- 图片7 -->
          <div class="upload-item-box-vip-one">
            <van-loading ref="images_seven_uploading" size="24px"
              >uploading...
              <template>
                <div
                  style="
                    font-size: large;
                    position: relative;
                    display: inline;
                    bottom: 20px;
                  "
                  @click="stopUploading('images_seven_uploading')"
                >
                  <span>X</span>
                </div>
              </template></van-loading
            >
            <van-uploader :after-read="uploadFile7">
              <div class="uploader-box" v-if="images_seven == ''">
                <img
                  class="upload-icon"
                  src="../../assets/images/postAd/upload.png"
                  alt=""
                />
                <div class="upload-icon-text">Click to upload pictures</div>
              </div>
              <div class="uploader-img" v-else>
                <div class="delImg-vip" @click="images_seven = ''">
                  <span>X</span>
                </div>
                <img :src="images_seven" alt="" />
              </div>
            </van-uploader>
          </div>
          <div class="paragraph">
            <!-- <div class="paragraph-title">Aspen BanksIndependent Lscort</div> -->
            <!-- 标题3和内容3 -->
            <!-- <div class="paragraph-title-text">
              <van-field
                class="city-ipt"
                v-model="advertisementTitleThree"
                placeholder="Paragraph heading"
              />
            </div> -->
            <div class="paragraph-context">
              <tinymce-editor
                v-model="advertisementRemarkTwo"
                :init="init_advertisementRemarkTwo"
              ></tinymce-editor>
            </div>
          </div>
          <!-- 图片8\9 -->
          <div class="upload-item-box-vip-one">
            <van-loading ref="images_eight_uploading" size="24px"
              >uploading...
              <template>
                <div
                  style="
                    font-size: large;
                    position: relative;
                    display: inline;
                    bottom: 20px;
                  "
                  @click="stopUploading('images_eight_uploading')"
                >
                  <span>X</span>
                </div>
              </template></van-loading
            >
            <van-uploader :after-read="uploadFile8">
              <div class="uploader-box" v-if="images_eight == ''">
                <img
                  class="upload-icon"
                  src="../../assets/images/postAd/upload.png"
                  alt=""
                />
                <div class="upload-icon-text">Click to upload pictures</div>
              </div>
              <div class="uploader-img" v-else>
                <div class="delImg-vip" @click="images_eight = ''">
                  <span>X</span>
                </div>
                <img :src="images_eight" alt="" />
              </div>
            </van-uploader>
          </div>
          <div class="upload-item-box-vip-one">
            <van-loading ref="images_nine_uploading" size="24px"
              >uploading...
              <template>
                <div
                  style="
                    font-size: large;
                    position: relative;
                    display: inline;
                    bottom: 20px;
                  "
                  @click="stopUploading('images_nine_uploading')"
                >
                  <span>X</span>
                </div>
              </template></van-loading
            >
            <van-uploader :after-read="uploadFile9">
              <div class="uploader-box" v-if="images_nine == ''">
                <img
                  class="upload-icon"
                  src="../../assets/images/postAd/upload.png"
                  alt=""
                />
                <div class="upload-icon-text">Click to upload pictures</div>
              </div>
              <div class="uploader-img" v-else>
                <div class="delImg-vip" @click="images_nine = ''">
                  <span>X</span>
                </div>
                <img :src="images_nine" alt="" />
              </div>
            </van-uploader>
          </div>
          <div class="paragraph">
            <!-- 内容2 -->
            <div class="paragraph-context">
              <tinymce-editor
                v-model="advertisementRemarkThree"
                :init="init_advertisementRemarkThree"
              ></tinymce-editor>
              <div style="text-align: left;">
              <span style="color: gray">At least 4 photos are required</span>
          </div>
            </div>
          </div>

          

          <!-- 增加视频上传 -->
          <!-- <div class="normal-upload-box">
            <div class="upload-title">video</div>
            <div class="upload-info">
              Naked videos& genitalia are NOT ALLOWED. This includes topless
              video. <br />
              Max.video length is 20 sec or 10MB. This only uploads video files.
            </div>
            <div class="text-area-box">
              <van-uploader
                :after-read="uploadVideoFunc"
                accept="video/*"
                :max-size="10 * 1024 * 1024"
                @oversize="onOversize"
              >
                <div class="uploader-box" v-if="videos_one == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload video</div>
                </div>
                <div class="uploader-img" v-else>
                  <div
                    class="delImg"
                    style="
                      left: 85%;
                      z-index: 3;
                      text-align: center;
                      font-size: xx-large;
                    "
                    @click="videos_one = ''"
                  >
                    <span>X</span>
                  </div>
                  <video :src="videos_one" controls>
                    <source src="movie.mp4" type="video/mp4" />
                    <source src="movie.ogg" type="video/ogg" />
                    <source src="movie.webm" type="video/webm" />
                    <object data="movie.mp4">
                      <embed src="movie.swf" />
                    </object>
                  </video>
                </div>
              </van-uploader>
            </div>
          </div> -->
          <div class="vip-input-box">
            <div class="vip-input-box-title" ref="refName">
              <span style="color: red">*</span> Name
            </div>
            <div class="vip-input-box-input">
              <van-field v-model="name" type="text" placeholder="Name" />
            </div>
          </div>
          <div class="num-info" style="color: #273458" ref="refPhoneEmail">
            <span style="color: red">*</span> Phone number or Email
            <div
              class="num-info"
              style="
                color: gray;
                margin-top: 0px;
                margin-bottom: 0px;
                margin-left: 15px;
                font-size: 0.3rem;
              "
            >
              Fill in one or two
            </div>
          </div>

          <div>
            <div style="display: flex">
              <!-- <van-field
                class="city-ipt"
                label="+"
                v-model="phone_area_code"
                type="number"
                maxlength="3"
                placeholder="Code"
                style="width: 35%; margin-right: 10px; margin-top: 5px"
                @click="areaCodeShow=true"
                
              /> -->
              <van-cell
                class="city-ipt"
                style="
                  margin-top: 5px;
                  margin-bottom: 5px;
                  width: 40%;
                  font: caption;
                "
                :value="
                  (this.schemaInput.selectedObjDefault.iso2 == undefined
                    ? 'usa'
                    : this.schemaInput.selectedObjDefault.iso2) +
                  ' +' +
                  this.phone_area_code
                "
                @click="areaCodeShow = true"
              />

              <VueCountryIntl
                schema="modal"
                modal-class="modal-class"
                :visible.sync="areaCodeShow"
                v-model="phone_area_code"
                cancelText="X"
                searchInputPlaceholder="select"
                @onChange="onDefaultChange"
              >
                <template slot="vueCountryNoData"><h1>not data！</h1></template>
              </VueCountryIntl>

              <van-field
                class="city-ipt"
                v-model="phone_number"
                type="number"
                placeholder="Phone number"
                style="margin: 5px 0px"
              />
            </div>
            <van-field
              class="city-ipt"
              v-model="email"
              type="email"
              placeholder="Email"
              style="margin: 5px 0px"
            />
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title" ref="refAge">
              <span style="color: red">*</span>Age
            </div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = !showAgeBox),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ ageName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>

                <van-popup
                  style="
                    padding: 10px;
                    width: 300px;
                    background: #eeeeee;
                    height: 500px;
                  "
                  v-model="showAgeBox"
                >
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="age">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in ageList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseAge(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </van-popup>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Gender</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = !showgenderBox),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ genderName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div
                  class="location-select-box"
                  v-if="showgenderBox"
                  style="border: 1px solid #f4f4f4"
                >
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="gender">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in genderList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseGender(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Ethnicity</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = !showRaceBox),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ raceName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <van-popup
                  style="padding: 10px; width: 300px; background: #eeeeee"
                  v-model="showRaceBox"
                >
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="race">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in raceList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseRace(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </van-popup>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Breast size</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = !showbreastSizeBox),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ breastSizeName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>

                <van-popup
                  style="padding: 10px; width: 300px; background: #eeeeee"
                  v-model="showbreastSizeBox"
                >
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="breastSize">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in breastSizeList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseBreastSize(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </van-popup>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Weight</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = !showWeightBox),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ weightName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>

                <van-popup
                  style="padding: 10px; width: 300px; background: #eeeeee"
                  v-model="showWeightBox"
                >
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="weight">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in weightList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseWeight(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </van-popup>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Height</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = !showHeightBox),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ heightName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>

                <van-popup
                  style="padding: 10px; width: 300px; background: #eeeeee"
                  v-model="showHeightBox"
                >
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="height">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in heightList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseHeight(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </van-popup>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Hair color</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = !showhairColorBox),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ hairColorName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showhairColorBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="hairColor">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in hairColorList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseHairColor(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Hair length</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = !showhairLengthBox),
                      (showeyeColorBox = false),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ hairLengthName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showhairLengthBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="hairLength">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in hairLengthList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseHairLength(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Eye color</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = !showeyeColorBox),
                      (showTravelBox = false)
                  "
                >
                  <div class="area-box-lf">
                    {{ eyeColorName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showeyeColorBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="eyeColor">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in eyeColorList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseEyeColor(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="vip-input-box">
            <div class="vip-input-box-title">Travel</div>
            <div class="vip-input-box-input">
              <div class="lang-box">
                <div
                  class="area-flex-box"
                  @click="
                    ;(showHeightBox = false),
                      (showWeightBox = false),
                      (showRaceBox = false),
                      (showgenderBox = false),
                      (showLanguageBox = false),
                      (showbreastSizeBox = false),
                      (showhairColorBox = false),
                      (showAgeBox = false),
                      (showOccupationBox = false),
                      (showRecommendSection = false),
                      (showhairLengthBox = false),
                      (showeyeColorBox = false),
                      (showTravelBox = !showTravelBox)
                  "
                >
                  <div class="area-box-lf">
                    {{ travelName }}
                  </div>
                  <div class="area-box-rg">
                    <img
                      class="bottom-icon-bl-img"
                      src="../../assets/images/home/bottom-icon-bl.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="location-select-box" v-if="showTravelBox">
                  <div class="location-list">
                    <div class="location-state">
                      <div class="location-list-box">
                        <van-radio-group v-model="travel">
                          <van-cell-group>
                            <van-cell
                              class="state-cell"
                              v-for="item in travelList"
                              clickable
                              :key="item.dictValue"
                              :title="item.dictLabel"
                              @click="chooseTravel(item)"
                            >
                              <template #right-icon>
                                <van-radio
                                  icon-size="20px"
                                  shape="square"
                                  checked-color="#273458"
                                  :name="item.dictValue"
                                />
                              </template>
                            </van-cell>
                          </van-cell-group>
                        </van-radio-group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="normal-person-iptBox">
            <div style="margin-top: 10px">
              <div
                style="font-size: 19px; font-weight: 700; color: #273458"
                ref="refAvailableTo"
              >
                <span style="color: red">*</span> Available TO
              </div>
              <div class="ipt-title" style="font-size: 18px" ref="refOneOrMore">
                Select one or more
              </div>
              <van-checkbox-group
                v-model="oneOrMoreAvailable"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-checkbox
                  v-for="(item, index) in list2"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="margin-top: 5px; width: 100px"
                  >{{ item.dictLabel }}</van-checkbox
                >
              </van-checkbox-group>
            </div>

            <div style="margin-top: 10px">
              <div
                class="ipt-title"
                style="font-size: 18px; color: #273458"
                ref="refProvideAs"
              >
                <span style="color: red">*</span> ServIce provide as
              </div>
              <van-checkbox-group
                v-model="provideService"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-checkbox
                  v-for="(item, index) in list3"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="margin-top: 5px; width: 100px"
                  >{{ item.dictLabel }}</van-checkbox
                >
              </van-checkbox-group>
            </div>

            <div style="margin-top: 10px">
              <div
                class="ipt-title"
                style="font-size: 18px; color: #273458"
                ref="refIndependent"
              >
                <span style="color: red">*</span> Independent
              </div>
              <van-radio-group
                v-model="independent"
                direction="horizontal"
                style="font-size: 16px"
              >
                <van-radio
                  v-for="(item, index) in list4"
                  :name="item.dictValue"
                  :key="index"
                  shape="square"
                  checked-color="#273458"
                  icon-size="20px"
                  style="margin-top: 5px; width: 100px"
                  >{{ item.dictLabel }}</van-radio
                >
              </van-radio-group>
            </div>
          </div>
        </div>

        <!-- vip -->
        <div class="big-line"></div>

        <!-- 是否是二次编辑基础信息 -->
        <div v-if="isEdit == true">
          <div class="goDown-back" @click="editInfo()">Save</div>
        </div>
        <!-- 不是二次编辑基础信息 -->
        <div v-else>
          <div class="goDown-back" @click="postDraft()" v-if="!vipPublish">
            Continue
          </div>
          <div class="goBack-box">
            <div
              class="goDown-go"
              @click=";(stepThree = false), (stepOneAndTwo = true)"
            >
              Previous step
            </div>

            <div class="goDown-go" @click="postDraft()" v-if="vipPublish">
              Continue
            </div>

            <div class="Review-btn" v-if="!vipPublish">Review your ad</div>
          </div>
        </div>
      </div>

      <!-- 步骤四的发布确认-->
      <div class="publish-box" v-if="stepFour">
        <div class="publish-info">
          <div class="publish-info-header">
            <div class="info-header-lf">4</div>
            <div class="info-header-rg">Publish</div>
          </div>
          <div class="publish-info-text">
            Your normal ads display time is 30 days, If your normal
            advertisement doesn't purchase ad display duration, it will only
            shows for 30 minutes per day, reaching around 300 viewers. If you
            purchase the standard advertisement display duration, it will be
            displayed 24 hours a day during the purchased time period, allowing
            you to reach more customers. If your Ad type contain TOP type,As TOP
            Ad,your ad will be displayed 24 hours a day with normal ad.
          </div>
        </div>
        <!-- <div v-show="type.indexOf('2') == -1" class="upgrade-days"> -->
        <div class="upgrade-days">
          <div class="upgrade-days-header">
            <div class="days-header-lf"></div>
            <div class="days-header-rg">Buy normal ad's display time</div>
          </div>
          <div class="days-menu">
            <div class="days-item" @click="checked1 = !checked1">
              <div class="days-text" :class="{ activeDaysBg: checked1 }">
                5days
              </div>
              <div class="days-btn">
                <van-checkbox
                  v-model="checked1"
                  checked-color="#273458"
                  icon-size="20px"
                ></van-checkbox>
              </div>
            </div>
            <div class="days-item" @click="checked2 = !checked2">
              <div class="days-text" :class="{ activeDaysBg: checked2 }">
                10days
              </div>
              <div class="days-btn">
                <van-checkbox
                  v-model="checked2"
                  checked-color="#273458"
                  icon-size="20px"
                ></van-checkbox>
              </div>
            </div>
            <div class="days-item" @click="checked3 = !checked3">
              <div class="days-text" :class="{ activeDaysBg: checked3 }">
                20days
              </div>
              <div class="days-btn">
                <van-checkbox
                  v-model="checked3"
                  checked-color="#273458"
                  icon-size="20px"
                ></van-checkbox>
              </div>
            </div>
            <div class="days-item" @click="checked4 = !checked4">
              <div class="days-text" :class="{ activeDaysBg: checked4 }">
                30days
              </div>
              <div class="days-btn">
                <van-checkbox
                  v-model="checked4"
                  checked-color="#273458"
                  icon-size="20px"
                ></van-checkbox>
              </div>
            </div>
            <div class="days-item last-item" @click="checked5 = !checked5">
              <div class="days-text" :class="{ activeDaysBg: checked5 }">
                Automatic renewal
              </div>
              <div class="days-btn">
                <van-checkbox
                  v-model="checked5"
                  checked-color="#273458"
                  icon-size="20px"
                ></van-checkbox>
              </div>
            </div>
          </div>
          <div class="total-box">
            <div class="total-box-text">$:{{ totol_normal }}</div>
          </div>
        </div>
        <div class="my-ads-box">
          <div class="my-ads-header">
            <div class="my-ads-header-lf"></div>
            <div class="my-ads-header-rg">My AD</div>
          </div>
          <div class="my-ads-header">
            <div>
              {{ category_text }}-{{ nowCityName }}-30Days-${{
                nowCityAdManeyPreMonth
              }}
            </div>
          </div>
          <div class="table-box">
            <table class="my-table">
              <tr>
                <td class="col1">Ad type</td>
                <td class="col2">AD Display time</td>
                <td class="col3">Price</td>
              </tr>
              <tr
                v-for="item in dept_list_select"
                :key="item.deptId"
                v-show="normalAdDays == 0"
              >
                <td class="col1">Normal AD</td>
                <td class="col2">30 minutes every day</td>
                <td class="col3"></td>
              </tr>
              <tr
                v-for="item in dept_list_select"
                :key="item.deptId"
                v-show="normalAdDays > 0"
              >
                <td class="col1">Normal AD</td>
                <td class="col2">{{ normalAdDays }} Days</td>
                <td class="col3">${{ totol_normal }}</td>
              </tr>
              <tr
                v-for="item in dept_list_select_ad"
                :key="item.deptId + 'pt'"
                v-show="item.selected1 != 0"
              >
                <td class="col1">Recommended AD</td>
                <td class="col2">{{ item.selected1 }} Days</td>
                <td class="col3">
                  ${{ (item.recommendShowPreDay * 100 * item.selected1) / 100 }}
                </td>
              </tr>
              <tr
                v-for="item in dept_list_select_ad_top"
                :key="item.deptId + 'top'"
                v-show="item.selected2 != 0"
              >
                <td class="col1">Top AD</td>
                <td class="col2">{{ item.selected2 }} Days</td>
                <td class="col3">
                  ${{ (item.topShowPreDay * 100 * item.selected2) / 100 }}
                </td>
              </tr>
            </table>
          </div>
          <div class="fee-text">
            Total：<span class="fee-num"
              >${{
                (nowCityAdManeyPreMonth * 100 +
                  totol_normal * 100 +
                  totol_top_and_tuijian * 100) /
                100
              }}</span
            >
          </div>
          <!-- <div class="sure-btn" @click="showReleasePopup">Publish</div> -->
          <div class="sure-btn" @click="showconfirm">Publish</div>
        </div>
      </div>
    </div>

    <van-popup v-model="showReleaseBox">
      <div class="questionPopup-box">
        <img
          @click="showReleaseBox = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">
          The advertising balance is insufficient, please top up <br />
          Advertising information has been saved to: My Ads-Draft Box
        </div>
        <div class="confirm-btn" @click="goMyAd">Got it</div>
      </div>
    </van-popup>

    <van-popup v-model="showErrorMsgBox">
      <div class="questionPopup-box">
        <!-- <div>
          <img
          @click="showErrorMsgBox = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
          />
        </div> -->
        <div style="font-size: initial">
          *The following content is a required option, please fill it out
          completely
        </div>
        <div class="content">
          {{ errorMsg }}
        </div>
        <div class="confirm-btn" @click="showErrorMsgBox = false">OK</div>
      </div>
    </van-popup>

    <router-view />
    <van-tabbar
      route
      active-color="#027AFC"
      inactive-color="#666666"
      style="z-index: 3"
    >
      <van-tabbar-item replace to="/vip">
        <span> {{ $t('vip') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active1 : icon.inactive1" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/">
        <span> {{ $t('home') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active2 : icon.inactive2" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/postAd">
        <span> {{ $t('post AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active3 : icon.inactive3" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item v-if="tokenKey" replace to="/myAD">
        <span> {{ $t('my AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active4 : icon.inactive4" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item v-if="tokenKey" replace to="/personal">
        <span> {{ $t('Profile') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active5 : icon.inactive5" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
    <van-popup
      v-model="showstreetpopup"
      round
      position="bottom"
      :style="{ height: '65%' }"
    >
      <!-- <div class="flexBox-lf1" style="display: flex">
        <van-field
          type="textarea"
          class="city-ipt"
          v-model="street_info"
          placeholder="View advertisements within a 40 mile radius of location"
          style="height: 100%; font-size: medium; text-align: left"
          @input="streetInfoChange(street_info)"
        />
        <van-button
          size="normal"
          :disabled="streetInfoStatus"
          style="
            width: 20%;
            height: auto;
            margin-left: 5px;
            margin-bottom: 5px;
            background-color: #273458;
            color: #fff;
          "
          @click="showstreetpopup = false"
          >confirm
        </van-button>
      </div> -->
      <van-cell-group>
        <van-cell
          v-for="(item, index) in streetPopupList"
          center
          :key="index"
          style="
            margin-top: 5px;
            text-align: center;
            font-size: 17px;
            height: auto;
            line-height: 34px;
          "
          @click="choosepopupInfo(item)"
        >
          <template #title>
            <img
              width="20px"
              height="20px"
              src="../../assets/images/postAd/position.png"
            />
            {{ item }}
          </template>
          <template #right-icon>
            <van-checkbox checked-color="#273458" icon-size="20px" />
          </template>
        </van-cell>
      </van-cell-group>
    </van-popup>
  </div>
</template>

<script>
import {
  apiAdvertisingClassification,
  apiOccupation,
  apiRace,
  apiLanguage,
  apiAvailable,
  apiUpload,
  apiConfigurationList,
  apiGetDeptList,
  apiGetDeptList_p,
  apiPOSTadvertisement,
  apiPOSTadvertisement_put,
  apiGetAdDetailForEdit,
  apiGetindependent,
  apiGetgenderList,
  apiGetservlce_provided_as,
  apiGetavailable_to,
  apiGetselect_one_or_more,
  apiGetbreast_size,
  apiGetEyeColor,
  apiGetage,
  apiGetweight,
  apiGetheight,
  apiGethai_color,
  apiGethai_length,
  apiGettravel,
  apiGetGoogleMapDetail,
  getStataCity,
  getStateData,
  getCityDetails,
  apiPOSTadvertisementEditBase,
  apiPOSTAdUpdateDraftInfo,
  apiGetInfo,
} from '../../request/api'
import { Toast } from 'vant'
// 富文本
import Editor from '@tinymce/tinymce-vue'
// 富文本
import CUT from './Cut.vue'
import { Dialog } from 'vant'
import VueCountryIntl from '../../components/vue-country-intl/index.vue'
export default {
  name: 'postAd',
  components: { 'tinymce-editor': Editor, CUT, VueCountryIntl },
  data() {
    return {
      images_one_uploading_stop: false,
      images_two_uploading_stop: false,
      images_three_uploading_stop: false,
      images_four_uploading_stop: false,
      images_five_uploading_stop: false,
      images_six_uploading_stop: false,
      images_seven_uploading_stop: false,
      images_eight_uploading_stop: false,
      images_nine_uploading_stop: false,
      recommendImageOne_uploading_stop: false,
      recommendImageTwo_uploading_stop: false,
      recommendImageThree_uploading_stop: false,
      largeImage_uploading_stop: false,

      schemaInput: {
        selectedObjDefault: {},
      },
      countryCode_node: '',
      areaCodeShow: false,
      draftSaved: false,
      errorMsg: '',
      showErrorMsgBox: false,
      activeIndex: 0,
      tokenKey: localStorage.getItem('key'),
      // 发布广告的id
      advertisementId: null,
      // advertisementRemarkOne 编辑器
      init_advertisementRemarkOne: {
        placeholder: 'Click to enter content ',
        // language_url: "/lib/js/zh_CN.js",
        // language: "zh_CN",
        height: 500,
        plugins: 'link lists image code table  wordcount ',
        // toolbar:
        //   "bold italic underline strikethrough | fontsizeselect | forecolor backcolor | alignleft aligncenter alignright alignjustify|bullist numlist |outdent indent blockquote | undo redo | link unlink image code | removeformat",
        toolbar:
          'formatselect | bold italic underline strikethrough | fontsizeselect | forecolor backcolor ',
        branding: false,
        images_upload_handler: (blobInfo, success, failure) => {
          success('data:image/jpeg;base64,' + blobInfo.base64())
        },
        // 监听用户输入事件
        init_instance_callback: (editor) => {
          editor.on('input', (e) => {
            this.advertisementRemarkOne = editor.getContent()
          })
        },
      },
      // advertisementRemarkTwo 编辑器
      init_advertisementRemarkTwo: {
        placeholder: 'Click to enter content ',
        // language_url: "/lib/js/zh_CN.js",
        // language: "zh_CN",
        height: 500,
        plugins: 'link lists image code table  wordcount ',
        // toolbar:
        //   "bold italic underline strikethrough | fontsizeselect | forecolor backcolor | alignleft aligncenter alignright alignjustify|bullist numlist |outdent indent blockquote | undo redo | link unlink image code | removeformat",
        toolbar:
          'formatselect | bold italic underline strikethrough | fontsizeselect | forecolor backcolor ',
        branding: false,
        images_upload_handler: (blobInfo, success, failure) => {
          success('data:image/jpeg;base64,' + blobInfo.base64())
        },
        // 监听用户输入事件
        init_instance_callback: (editor) => {
          editor.on('input', (e) => {
            this.advertisementRemarkTwo = editor.getContent()
          })
        },
      },
      // advertisementRemarkThree 编辑器
      init_advertisementRemarkThree: {
        placeholder: 'Click to enter content ',
        // language_url: "/lib/js/zh_CN.js",
        // language: "zh_CN",
        height: 500,
        plugins: 'link lists image code table  wordcount ',
        // toolbar:
        //   "bold italic underline strikethrough | fontsizeselect | forecolor backcolor | alignleft aligncenter alignright alignjustify|bullist numlist |outdent indent blockquote | undo redo | link unlink image code | removeformat",
        toolbar:
          'formatselect | bold italic underline strikethrough | fontsizeselect | forecolor backcolor ',
        branding: false,
        images_upload_handler: (blobInfo, success, failure) => {
          success('data:image/jpeg;base64,' + blobInfo.base64())
        },
        // 监听用户输入事件
        init_instance_callback: (editor) => {
          editor.on('input', (e) => {
            this.advertisementRemarkThree = editor.getContent()
          })
        },
      },
      active: 0,
      icon: {
        active1: require('../../assets/images/tabbar/tabbar1.png'),
        inactive1: require('../../assets/images/tabbar/tabbar2.png'),
        active2: require('../../assets/images/tabbar/tabbar3.png'),
        inactive2: require('../../assets/images/tabbar/tabbar4.png'),
        active3: require('../../assets/images/tabbar/tabbar5.png'),
        inactive3: require('../../assets/images/tabbar/tabbar6.png'),
        active4: require('../../assets/images/tabbar/tabbar7.png'),
        inactive4: require('../../assets/images/tabbar/tabbar8.png'),
        active5: require('../../assets/images/tabbar/tabbar9.png'),
        inactive5: require('../../assets/images/tabbar/tabbar10.png'),
      },
      // 分类列表
      classificationList: [],
      category: '',
      // 步骤
      stepOneAndTwo: true,
      stepThree: false,
      stepFour: false,

      // 步骤三详情参数
      city_detail: '', // 城市名称
      city_street: '', // 城市街道
      city_number: '', // 城市街道号码
      phone_number: '', //电话号码
      phone_area_code: '1', //电话区号
      age: '', //年龄
      height: '', //身高
      language: '', //语言
      languageName: '', //语言名称（展示）
      race: '', //种族
      raceName: '', //种族名称（展示）
      occupation: '', //职业
      occupationName: '', //职业名称（展示）
      available: '',
      introduce: '', //多行文本输入介绍部分
      type: [], //升级广告类型
      // 语言列表
      languageList: [],
      // 种族列表
      raceList: [],
      // 职业列表
      occupationList: [],
      // Available列表
      availableList: [],
      // 控制语言\种族/职业下拉框
      showLanguageBox: false,
      showRaceBox: false,
      showOccupationBox: false,
      images_one: '',
      images_two: '',
      images_three: '',
      images_four: '',
      images_five: '',
      images_six: '',
      images_seven: '',
      images_eight: '',
      images_nine: '',

      //上传视频
      videos_one: '',

      // 普通、店铺、vip发布
      normalPublish: true,
      shopPublish: false,
      vipPublish: false,
      shopname: '', //商铺名称
      table_shower: '', //table_shower
      sauna: '',
      jacuzzi: '',
      accept_credit_card: '',
      ratefor30: '',
      ratefor45: '',
      ratefor60: '',
      payment: '', //付款方式
      // 店铺
      mondayAm: '9:00',
      tuesdayAm: '9:00',
      wednesdayAm: '9:00',
      thursdayAm: '9:00',
      fridayAm: '9:00',
      saturdayAm: '9:00',
      sundayAm: '9:00',
      mondayPm: '24:00',
      tuesdayPm: '24:00',
      wednesdayPm: '24:00',
      thursdayPm: '24:00',
      fridayPm: '24:00',
      saturdayPm: '24:00',
      sundayPm: '24:00',
      // vip
      name: '',
      email: '',
      // advertisementTitleOne: '',
      // advertisementTitleTwo: '',
      // advertisementTitleThree: '',
      advertisementRemarkOne: '',
      advertisementRemarkTwo: '',
      advertisementRemarkThree: '',
      // 选择升级几天
      checked1: false,
      checked2: false,
      checked3: false,
      checked4: false,
      checked5: false,
      // 确认发布弹框
      showReleaseBox: false,
      show_are: false, //步骤二下拉框弹出
      show_are_maney: false, //步骤二下拉框弹出2
      deptTree: [], //步骤二地址树形数据
      dept_list: [], //步骤二地址数据
      deptTree_select: 'Please select your city', //步骤二地址选择
      deptTree_select_id: '', //步骤二地址选择_id
      dept_list_select: [], //步骤二地址选择2
      dept_list_select_totol: 0, //步骤二地址选择2 统计
      dept_list_select_totol_days: 0, // 统计乘以天数
      configurationList: [], // 金额数据及系统配置获取接口-数据
      dept_list_select_ad: [], //步骤三地址选择2 ==》ad选择推荐广告
      dept_list_select_ad_top: [], //步骤三地址选择2 ==》ad选择大图广告
      dept_list_select_ad_normal: [], //步骤三地址选择 ==》ad选择小图广告时间
      cityData: [],
      recommendImageOne: '',
      recommendImageTwo: '',
      recommendImageThree: '',
      largeImage: '',
      //recommend days
      selected1: '0',
      //top days
      selected2: '0',
      showRecommendSection: false,
      showTopSection: false,
      selectCity: null,
      street_info: '',
      showgenderBox: false,
      gender: '',
      genderName: '',
      genderList: [],
      hip: null,
      list4: [],
      independent: '',

      list3: [],
      provideService: [],
      list2: [],
      oneOrMoreAvailable: [],
      list1: [],
      oneOrMore: [],

      breastSizeList: [],
      showbreastSizeBox: false,
      breastSize: '',
      breastSizeName: '',

      ageList: [],
      showAgeBox: false,
      ageName: '',

      weightList: [],
      showWeightBox: false,
      weight: '',
      weightName: '',

      heightList: [],
      showHeightBox: false,
      heightName: '',

      hairColorList: [],
      showhairColorBox: false,
      hairColor: '',
      hairColorName: '',

      travelList: [],
      showTravelBox: false,
      travel: '',
      travelName: '',

      eyeColorList: [],
      showeyeColorBox: false,
      eyeColor: '',
      eyeColorName: '',

      hairLengthList: [],
      showhairLengthBox: false,
      hairLength: '',
      hairLengthName: '',

      streetPopupList: [],
      showstreetpopup: false,
      showcountriesflag: false,
      country_select: '',
      deptTreeCountries: [],
      contactWechat: '',
      contactTelefram: '',
      contactTwitter: '',
      contactFacebook: '',
      contactIngstagram: '',
      categorytext: '',
      streetInfoStatus: true,

      normalAdDays: 0,
      topAdDays: 0,
      recommendedAdDays: 0,

      //当前设计为单选城市，每月金额设置，在步骤三开始时记录
      nowCityAdManeyPreMonth: 0,
      totol_top_and_tuijian: 0,
      nowCityName: '',

      nowStateName: '',
      user_input_city_name: '',
      isConfirmStreetInfo: false,

      //设置二次编辑
      isEdit: false,
      //二次编辑是否展示大图 推荐区域
      draftEditShowRecommendSection: false,
      draftEditShowTopSection: false,
    }
  },
  computed: {
    full_areacode_text() {
      return (
        (this.schemaInput.selectedObjDefault.iso2 == undefined
          ? 'usa'
          : this.schemaInput.selectedObjDefault.iso2) +
        '+' +
        this.phone_area_code
      )
    },

    // 换算category 类型 id变题目
    category_text() {
      let category = this.category
      let dictLabel = null
      this.classificationList.forEach((element, index) => {
        if (element.dictValue == category) {
          dictLabel = element.dictLabel
        } else {
        }
      })
      return dictLabel
    },
    // 换算天数为文字
    checked_days_text() {
      if (this.checked1) {
        return 5
      } else if (this.checked2) {
        return 10
      } else if (this.checked3) {
        return 20
      } else if (this.checked4) {
        return 30
      } else if (this.checked5) {
        return 1
      }
      return 0
    },
    // 计算推荐和大图
    // totol_top_and_tuijian() {
    //   let totol = 0
    //   this.dept_list_select_ad.forEach((element, index) => {
    //     totol += element.recommendShowPreDay * element.selected1
    //   })
    //   this.dept_list_select_ad_top.forEach((element, index) => {
    //     totol += element.topShowPreDay * element.selected2
    //   })
    //   console.log(
    //     this.dept_list_select_ad,
    //     this.dept_list_select_ad_top,
    //     '--------++++++++',
    //     totol,
    //     '-==+++>>>>>>'
    //   )
    //   return totol
    // },

    // 计算小图广告展示金额
    totol_normal() {
      let totol = 0
      this.dept_list_select_ad_normal.forEach((element, index) => {
        totol += (element.normalShowPreDay * 100 * this.normalAdDays) / 100
      })

      console.log(
        this.dept_list_select_ad_normal,
        '--------++++++++',
        totol,
        '-==+++>>>>>>'
      )
      return totol
    },
  },
  watch: {
    //设置步骤三当输入的城市信息变更时
    //检测与步骤二选中的城市是否一致,若不一致，则以用户步骤3输入的城市信息为准
    selected1() {
      let totol = 0
      this.dept_list_select_ad.forEach((element, index) => {
        totol += (element.recommendShowPreDay * 100 * this.selected1) / 100
      })
      this.dept_list_select_ad_top.forEach((element, index) => {
        totol += (element.topShowPreDay * 100 * this.selected2) / 100
      })
      this.totol_top_and_tuijian = totol
    },
    selected2() {
      let totol = 0
      this.dept_list_select_ad.forEach((element, index) => {
        totol += (element.recommendShowPreDay * 100 * this.selected1) / 100
      })
      this.dept_list_select_ad_top.forEach((element, index) => {
        totol += (element.topShowPreDay * 100 * this.selected2) / 100
      })
      this.totol_top_and_tuijian = totol
    },
    type(newVal) {
      if (newVal) {
        console.log(newVal, '---------newVal_________________<<<<<<<<<<<<<<<<<')
        this.dept_list_select_ad.forEach((element, index) => {
          console.log(element.selected1, '---------')
          this.dept_list_select_ad[index].selected = '0'
          if (this.type.indexOf('3') !== -1) {
            this.dept_list_select_ad[index].selected1 =
              element.selected1 === '0' ? '10' : element.selected1
            this.selected1 =
              element.selected1 === '0' ? '10' : element.selected1
          } else {
            this.dept_list_select_ad[index].selected1 = '0'
            this.selected1 = 0
          }
        })
        this.dept_list_select_ad_top.forEach((element, index) => {
          this.dept_list_select_ad_top[index].selected = '0'
          if (this.type.indexOf('2') !== -1) {
            this.dept_list_select_ad_top[index].selected2 =
              element.selected2 === '0' ? '10' : element.selected2
            this.selected2 =
              element.selected2 === '0' ? '10' : element.selected2
          } else {
            this.dept_list_select_ad_top[index].selected2 = '0'
            this.selected2 = 0
          }
        })
      }
    },
    checked1(e) {
      if (e) {
        this.normalAdDays = 5
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
      } else {
        this.normalAdDays = 0
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
      }
    },
    checked2(e) {
      if (e) {
        this.normalAdDays = 10
        this.checked1 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
      } else {
        this.normalAdDays = 0
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
      }
    },
    checked3(e) {
      if (e) {
        this.normalAdDays = 20
        this.checked1 = false
        this.checked2 = false
        this.checked4 = false
        this.checked5 = false
      } else {
        this.normalAdDays = 0
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
      }
    },
    checked4(e) {
      if (e) {
        this.normalAdDays = 30
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked5 = false
      } else {
        this.normalAdDays = 0
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
      }
    },
    checked5(e) {
      if (e) {
        this.normalAdDays = 1
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
      } else {
        this.normalAdDays = 0
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
      }
    },
  },
  created() {
    this.tokenKey = localStorage.getItem('key') ?? ''

    getStateData().then((res) => {
      if (res.code == 200) {
        console.log('地址树形数据获取', res)
        this.deptTree = res.data
      }
    })

    // 类型分类
    apiAdvertisingClassification().then((res) => {
      if (res.code == 200) {
        this.classificationList = res.data
        // console.log(this.classificationList);
      }
    })
    apiOccupation().then((res) => {
      if (res.code == 200) {
        this.occupationList = res.data
      }
    })
    apiRace().then((res) => {
      if (res.code == 200) {
        this.raceList = res.data
      }
    })
    apiLanguage().then((res) => {
      if (res.code == 200) {
        this.languageList = res.data
      }
    })
    apiAvailable().then((res) => {
      if (res.code == 200) {
        this.availableList = res.data
      }
    })
    // 金额数据及系统配置获取接口
    apiConfigurationList().then((res) => {
      if (res.code == 200) {
        console.log('金额数据及系统配置获取接口', res)
        this.configurationList = res.rows
      }
    })
    // 地址数据获取
    apiGetDeptList().then((res) => {
      if (res.code == 200) {
        // console.log("地址数据获取", res.data);
        // this.dept_list = res.data;
      }
    })

    // 新增 start
    apiGetgenderList().then((res) => {
      if (res.code === 200) {
        this.genderList = res.data
      }
    })

    apiGetindependent().then((res) => {
      if (res.code === 200) {
        this.list4 = res.data
      }
    })
    apiGetservlce_provided_as().then((res) => {
      if (res.code === 200) {
        this.list3 = res.data
      }
    })
    apiGetavailable_to().then((res) => {
      if (res.code === 200) {
        this.list2 = res.data
      }
    })
    apiGetselect_one_or_more().then((res) => {
      if (res.code === 200) {
        this.list1 = res.data
      }
    })
    apiGetbreast_size().then((res) => {
      if (res.code === 200) {
        this.breastSizeList = res.data
      }
    })
    apiGetage().then((res) => {
      if (res.code === 200) {
        this.ageList = res.data
      }
    })
    apiGetweight().then((res) => {
      if (res.code === 200) {
        this.weightList = res.data
      }
    })
    apiGetheight().then((res) => {
      if (res.code === 200) {
        this.heightList = res.data
      }
    })
    apiGethai_color().then((res) => {
      if (res.code === 200) {
        this.hairColorList = res.data
      }
    })
    apiGethai_length().then((res) => {
      if (res.code === 200) {
        this.hairLengthList = res.data
      }
    })
    apiGettravel().then((res) => {
      if (res.code === 200) {
        this.travelList = res.data
      }
    })
    apiGetEyeColor().then((res) => {
      if (res.code === 200) {
        this.eyeColorList = res.data
      }
    })
    // 新增 end

    // 发布页的我的广告再次编辑传来广告id后获取详情
    let adId = this.$route.query.advertisementId
    //草稿页的广告的再次编辑
    let status = this.$route.query.status
    if (adId) {
      apiGetAdDetailForEdit({
        advertisementId: adId,
      }).then((res) => {
        if (res.code == 200) {
          //设置二次编辑标志位
          this.isEdit = true

          //获取基本信息之后，判断该条AD编辑来自于已发布状态还是草稿箱状态
          if (status == 'draft') {
            //设置二次编辑标志位，实际为二次发布标志位
            this.isEdit = false
            this.draftSaved = true

            if (res.data.largeImage != null) {
              this.draftEditShowTopSection = true
            }

            //推荐
            if (res.data.recommendImageOne != null) {
              this.draftEditShowRecommendSection = true
            }
          }

          this.category = res.data.category
          this.deptTree_select_id = res.data.cityData.cityId
          this.deptTree_select = res.data.cityData.parentName
          this.street_info = res.data.cityDetail
          this.age = res.data.age
          this.height = res.data.langeuage
          this.race = res.data.race
          this.occupation = res.data.occupation
          this.available = res.data.available
          this.phone_number = res.data.phoneNumber
          this.phone_area_code = res.data.phoneAreaCode
          this.images_one = res.data.imagesOne
          this.videos_one = res.data.videosOne
          this.images_two = res.data.imagesTwo
          this.images_three = res.data.imagesThree
          this.images_four = res.data.imagesFour
          this.images_five = res.data.imagesFive
          this.images_six = res.data.imagesSix
          this.images_seven = res.data.imagesSeven
          this.images_eight = res.data.imagesEight
          this.images_nine = res.data.imagesNine
          this.recommendImageOne = res.data.recommendImageOne
          this.recommendImageTwo = res.data.recommendImageTwo
          this.recommendImageThree = res.data.recommendImageThree
          this.largeImage = res.data.largeImage
          this.introduce = res.data.introduce
          this.cityData = res.data.cityData
          this.advertisementId = res.data.advertisementId
          this.shopname = res.data.shopname
          this.table_shower = res.data.tableShower
          this.sauna = res.data.sauna
          this.jacuzzi = res.data.jacuzzi
          this.accept_credit_card = res.data.acceptCreditCard
          this.ratefor30 = res.data.ratefor30
          this.ratefor45 = res.data.ratefor45
          this.ratefor60 = res.data.ratefor60
          this.payment = res.data.payment
          this.mondayAm = res.data.mondayAm
          this.thursdayAm = res.data.tuesdayAm
          this.wednesdayAm = res.data.wednesdayAm
          this.thursdayAm = res.data.thursdayAm
          this.fridayAm = res.data.fridayAm
          this.saturdayAm = res.data.saturdayAm
          this.sundayAm = res.data.sundayAm
          this.mondayPm = res.data.mondayPm
          this.tuesdayPm = res.data.tuesdayPm
          this.wednesdayPm = res.data.wednesdayPm
          this.thursdayPm = res.data.thursdayPm
          this.fridayPm = res.data.fridayPm
          this.saturdayPm = res.data.saturdayPm
          this.saturdayPm = res.data.sundayPm
          this.name = res.data.advertisementName
          this.email = res.data.email
          // this.advertisementTitleOne = res.data.advertisementTitleOne
          // this.advertisementTitleTwo = res.data.advertisementTitleTwo
          // this.advertisementTitleThree = res.data.advertisementTitleThree
          this.advertisementRemarkOne = res.data.advertisementRemarkOne
          this.advertisementRemarkTwo = res.data.advertisementRemarkTwo
          this.advertisementRemarkThree = res.data.advertisementRemarkThree
          this.dept_list_select.push(res.data.cityData)

          this.dept_list_select_totol = res.data.cityData.maney

          //available to
          this.provideService = String(res.data.provide).split(',')
          this.oneOrMoreAvailable = String(res.data.available).split(',')
          this.independent = res.data.independent

          this.age = res.data.age
          this.gender = res.data.gender
          this.race = res.data.race
          this.breastSize = res.data.breastSize
          this.weight = res.data.weight
          this.height = res.data.height
          this.hairColor = res.data.hairColor
          this.hairLength = res.data.hairLength
          this.eyeColor = res.data.eyeColor
          this.travel = res.data.travel

          // 地址数据获取
          // let dizhi_list = [];
          // getStataCity().then((res) => {
          //   if (res.code == 200) {
          //     console.log("地址数据获取===>", res.data);
          //     dizhi_list = res.data;
          //     this.dept_list_select.forEach((element, index) => {
          //       console.log(element);
          //       dizhi_list.forEach((item, index) => {
          //         if (element == item.cityId) {
          //           // this.dept_list_select[index].maney = item.maney;
          //           this.dept_list_select[index].cityName = item.cityName;
          //         }
          //       });
          //     });
          //     this.Change_dept_list_select(this.dept_list_select);
          //     // this.goStepThree();
          //   }
          // });
          console.log(this.dept_list_select)
        }
      })
    }
  },
  // beforeDestroy(){
  //   window.removeEventListener('backbutton', this.goBackPreStep());//false阻止默认事件
  //   console.log("removeEventListener");
  // },
  // beforeRouteLeave(to,from,next){
  //   console.log("back test...");
  //   next(false);
  // },
  mounted() {
    //监听安卓实体返回按键
    // if (window.history && window.history.pushState) {
    //   history.pushState(null, null, document.URL);
    //   window.addEventListener('backbutton', this.goBackPreStep(),false);//false阻止默认事件
    //   console.log("addEventListener");
    // }

    // window.onpopstate = () => {
    //   history.pushState(null, null, document.URL);
    //   this.goBackPreStep();
    // }

    // this.$nextTick(() => {
    //   window.addEventListener('popstate', this.goBackPreStep(),false);
    //   console.log("addEventListener");
    // })

    //是AD编辑,延迟处理，因为异步访问数据，数据可能还没获取获取到
    setTimeout(() => {
      var this_m = this
      if (this_m.advertisementId != null) {
        //赋值回显
        this_m.ageList.forEach((item) => {
          if (item.dictValue == this_m.age) {
            this_m.chooseAge(item)
          }
        })

        this_m.genderList.forEach((item) => {
          if (item.dictValue == this_m.gender) {
            this_m.chooseGender(item)
          }
        })

        this_m.raceList.forEach((item) => {
          if (item.dictValue == this_m.race) {
            this_m.chooseRace(item)
          }
        })

        this_m.breastSizeList.forEach((item) => {
          if (item.dictValue == this_m.breastSize) {
            this_m.chooseBreastSize(item)
          }
        })

        this_m.weightList.forEach((item) => {
          if (item.dictValue == this_m.weight) {
            this_m.chooseWeight(item)
          }
        })

        this_m.heightList.forEach((item) => {
          if (item.dictValue == this_m.height) {
            this_m.chooseHeight(item)
          }
        })

        this_m.hairColorList.forEach((item) => {
          if (item.dictValue == this_m.hairColor) {
            this_m.chooseHairColor(item)
          }
        })

        this_m.hairLengthList.forEach((item) => {
          if (item.dictValue == this_m.hairLength) {
            this_m.chooseHairLength(item)
          }
        })

        this_m.eyeColorList.forEach((item) => {
          if (item.dictValue == this_m.eyeColor) {
            this_m.chooseEyeColor(item)
          }
        })

        this_m.travelList.forEach((item) => {
          if (item.dictValue == this_m.travel) {
            this_m.chooseTravel(item)
          }
        })
      }
    }, 5000)
  },
  methods: {
    stopUploading(name) {
      console.log('stopUploading...')
      if (name == 'recommendImageOne_uploading') {
        this.$refs.recommendImageOne_uploading.style.display = 'none'
        this.recommendImageOne_uploading_stop = true
      } else if (name == 'recommendImageTwo_uploading') {
        this.$refs.recommendImageTwo_uploading.style.display = 'none'
        this.recommendImageTwo_uploading_stop = true
      } else if (name == 'recommendImageThree_uploading') {
        this.$refs.recommendImageThree_uploading.style.display = 'none'
        this.recommendImageThree_uploading_stop = true
      } else if (name == 'largeImage_uploading') {
        this.$refs.largeImage_uploading.style.display = 'none'
        this.largeImage_uploading_stop = true
      } else if (name == 'images_one_uploading') {
        this.$refs.images_one_uploading.style.display = 'none'
        this.images_one_uploading_stop = true
      } else if (name == 'images_two_uploading') {
        this.$refs.images_two_uploading.style.display = 'none'
        this.images_two_uploading_stop = true
      } else if (name == 'images_three_uploading') {
        this.$refs.images_three_uploading.style.display = 'none'
        this.images_three_uploading_stop = true
      } else if (name == 'images_four_uploading') {
        this.$refs.images_four_uploading.style.display = 'none'
        this.images_four_uploading_stop = true
      } else if (name == 'images_five_uploading') {
        this.$refs.images_five_uploading.style.display = 'none'
        this.images_five_uploading_stop = true
      } else if (name == 'images_six_uploading') {
        this.$refs.images_six_uploading.style.display = 'none'
        this.images_six_uploading_stop = true
      } else if (name == 'images_seven_uploading') {
        this.$refs.images_seven_uploading.style.display = 'none'
        this.images_seven_uploading_stop = true
      } else if (name == 'images_eight_uploading') {
        this.$refs.images_eight_uploading.style.display = 'none'
        this.images_eight_uploading_stop = true
      } else if (name == 'images_nine_uploading') {
        this.$refs.images_nine_uploading.style.display = 'none'
        this.images_nine_uploading_stop = true
      }
    },
    onDefaultChange(selected) {
      console.log(5555, selected)
      this.schemaInput.selectedObjDefault = selected
    },
    // 选择语言
    chooseLanguage(item) {
      this.language = item.dictValue
      this.languageName = item.dictLabel
      this.showLanguageBox = false
    },
    // 选择种族
    chooseRace(item) {
      this.race = item.dictValue
      this.raceName = item.dictLabel
      this.showRaceBox = false
    },
    // 选择职业
    chooseOccupation(item) {
      this.occupation = item.dictValue
      this.occupationName = item.dictLabel
      this.showOccupationBox = false
    },
    // vip选择种族
    vipChooseRace(item) {
      this.race = item.dictValue
      this.raceName = item.dictLabel
      this.showRaceBox = false
    },

    UpUrl(data) {
      console.log(data)
      if (data.name == 'recommendImageOne') {
        this.recommendImageOne = data.url
      } else if (data.name == 'recommendImageTwo') {
        this.recommendImageTwo = data.url
      } else if (data.name == 'recommendImageThree') {
        this.recommendImageThree = data.url
      } else if (data.name == 'largeImage') {
        this.largeImage = data.url
      } else if (data.name == 'images_one') {
        this.images_one = data.url
      } else if (data.name == 'images_two') {
        this.images_two = data.url
      } else if (data.name == 'images_three') {
        this.images_three = data.url
      }
    },

    showImagesUploading(data) {
      console.log(data)
      if (data.name == 'recommendImageOne') {
        this.$refs.recommendImageOne_uploading.style.display = 'block'
      } else if (data.name == 'recommendImageTwo') {
        this.$refs.recommendImageTwo_uploading.style.display = 'block'
      } else if (data.name == 'recommendImageThree') {
        this.$refs.recommendImageThree_uploading.style.display = 'block'
      } else if (data.name == 'largeImage') {
        this.$refs.largeImage_uploading.style.display = 'block'
      } else if (data.name == 'images_one') {
        this.$refs.images_one_uploading.style.display = 'block'
      } else if (data.name == 'images_two') {
        this.$refs.images_two_uploading.style.display = 'block'
      } else if (data.name == 'images_three') {
        this.$refs.images_three_uploading.style.display = 'block'
      }
    },
    showImagesUploadingClose(data) {
      console.log(data)
      if (data.name == 'recommendImageOne') {
        this.$refs.recommendImageOne_uploading.style.display = 'none'
      } else if (data.name == 'recommendImageTwo') {
        this.$refs.recommendImageTwo_uploading.style.display = 'none'
      } else if (data.name == 'recommendImageThree') {
        this.$refs.recommendImageThree_uploading.style.display = 'none'
      } else if (data.name == 'largeImage') {
        this.$refs.largeImage_uploading.style.display = 'none'
      } else if (data.name == 'images_one') {
        this.$refs.images_one_uploading.style.display = 'none'
      } else if (data.name == 'images_two') {
        this.$refs.images_two_uploading.style.display = 'none'
      } else if (data.name == 'images_three') {
        this.$refs.images_three_uploading.style.display = 'none'
      }
    },
    onClickLeft() {
      if (this.stepOneAndTwo) {
        Toast("It's already the first step")
      } else if (this.stepThree) {
        this.stepThree = false
        this.stepOneAndTwo = true
      } else if (this.stepFour) {
        this.stepFour = false
        this.stepThree = true
      } else {
        this.$router.go(-1)
      }
    },
    goStepThree() {
      let token = localStorage.getItem('key')
      if (!token) {
        this.$router.push('/login')
      }

      //已登录校验
      apiGetInfo().then((res) => {
        if (res.code == 200) {
          console.log('already logged in')
        }
      })

      let _this = this
      // 跳转发生的方法
      function GOTO() {
        _this.stepOneAndTwo = false
        _this.stepThree = true
        _this.dept_list_select_ad = _this.dept_list_select
        _this.dept_list_select_ad_top = _this.dept_list_select
        _this.dept_list_select_ad_normal = _this.dept_list_select
        _this.dept_list_select_ad.forEach((element, index) => {
          _this.dept_list_select_ad[index].selected = '0'
          if (_this.type.indexOf('3') !== -1) {
            _this.dept_list_select_ad[index].selected1 = '10'
          } else {
            _this.dept_list_select_ad[index].selected1 = '0'
          }
        })
        _this.dept_list_select_ad_top.forEach((element, index) => {
          _this.dept_list_select_ad_top[index].selected = '0'
          if (_this.type.indexOf('2') !== -1) {
            _this.dept_list_select_ad_top[index].selected2 = '10'
          } else {
            _this.dept_list_select_ad_top[index].selected2 = '0'
          }
        })
        console.log(_this.dept_list_select_ad, _this.dept_list_select_ad_top)
      }

      //判断是否已选中类别
      if (this.category == '') {
        Toast('Please select category.')
        return
      }
      //判断是否已选中城市
      if (this.dept_list_select.length == 0) {
        Toast('Please choose 1 city only.')
        return
      }
      this.selectCity = this.dept_list_select[0].cityName ?? ''
      this.nowCityAdManeyPreMonth = this.dept_list_select[0].maney
      this.nowCityName = this.dept_list_select[0].cityName
      if (this.category == 4) {
        // 去店铺
        this.normalPublish = false
        this.shopPublish = true
        this.vipPublish = false
        GOTO()
      } else if (this.category == 6) {
        // 去vip
        this.normalPublish = false
        this.shopPublish = false
        this.vipPublish = true
        GOTO()
      } else {
        // 去普通
        this.normalPublish = true
        this.shopPublish = false
        this.vipPublish = false
        this.city_detail = this.deptTree_select
        // if (this.deptTree_select == "Please select your city") {
        //   Toast("Please select your city");
        // } else {
        //   GOTO();
        // }
        if (this.deptTree_select_id == '') {
          Toast('Please select your city')
        } else {
          GOTO()
        }
      }
      document.documentElement.scrollTop = 0
    },
    showReleasePopup() {
      this.showReleaseBox = true
    },
    // 选择分类
    checkClassification(item) {
      this.category = item.dictValue
      this.categorytext = item.dictLabel
      console.log('选择分类,category:' + this.category)
    },
    // //步骤二地址选择
    Check_deptTree_select(item) {
      console.log(item, 'item')
      this.deptTree_select = item.cityName
      this.deptTree_select_id = item.cityId
      this.show_are = false
      this.show_are_maney = true
      getStataCity({ parentId: item.cityId }).then((res) => {
        {
          console.log(res, 'res')

          if (res.code === 200) {
            this.dept_list = res.data
          }
        }
      })
    },
    // //步骤二地址选择变化处理统计
    Change_dept_list_select(e) {
      //在选择第二个时，取消第一个city设置
      if (e.length == 2) {
        e.splice(0, 1)
      }
      let dept_list_select_totol = 0
      e.forEach((element) => {
        dept_list_select_totol += Number(element.maney)
      })
      this.dept_list_select_totol = dept_list_select_totol
    },
    // 上传图片
    uploadFile1(file) {
      const formData = new FormData()
      formData.append('file', file.file)
      this.$refs.images_one_uploading.style.display = 'block'
      setTimeout(() => {
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_one_uploading_stop) {
              this.images_one_uploading_stop = false
              return
            }

            this.images_one = res.url
            this.$refs.images_one_uploading.style.display = 'none'
          }
        })
      }, 5000)
    },
    uploadFile2(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_two_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_two_uploading_stop) {
              this.images_two_uploading_stop = false
              return
            }

            this.$refs.images_two_uploading.style.display = 'none'
            this.images_two = res.url
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_two_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_two_uploading_stop) {
                  this.images_two_uploading_stop = false
                  return
                }

                this.images_two = res.url
                this.$refs.images_two_uploading.style.display = 'none'
              }
            })
          }
          if (index == 1) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_three_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_three_uploading_stop) {
                  this.images_three_uploading_stop = false
                  return
                }
                this.images_three = res.url
                this.$refs.images_three_uploading.style.display = 'none'
              }
            })
          }
          if (index == 2) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_four_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_four_uploading_stop) {
                  this.images_four_uploading_stop = false
                  return
                }

                this.images_four = res.url
                this.$refs.images_four_uploading.style.display = 'none'
              }
            })
          }
          if (index == 3) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_five_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_five_uploading_stop) {
                  this.images_five_uploading_stop = false
                  return
                }
                this.images_five = res.url
                this.$refs.images_five_uploading.style.display = 'none'
              }
            })
          }
          if (index == 4) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_six_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_six_uploading_stop) {
                  this.images_six_uploading_stop = false
                  return
                }
                this.images_six = res.url
                this.$refs.images_six_uploading.style.display = 'none'
              }
            })
          }
          if (index == 5) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_seven_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_seven_uploading_stop) {
                  this.images_seven_uploading_stop = false
                  return
                }
                this.images_seven = res.url
                this.$refs.images_seven_uploading.style.display = 'none'
              }
            })
          }
          if (index == 6) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_eight_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_eight_uploading_stop) {
                  this.images_eight_uploading_stop = false
                  return
                }
                this.images_eight = res.url
                this.$refs.images_eight_uploading.style.display = 'none'
              }
            })
          }
          if (index == 7) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }
                this.$refs.images_nine_uploading.style.display = 'none'
                this.images_nine = res.url
              }
            })
          }
        })
      }
    },
    uploadFile3(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_three_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_three_uploading_stop) {
              this.images_three_uploading_stop = false
              return
            }
            this.$refs.images_three_uploading.style.display = 'none'
            this.images_three = res.url
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_three_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_three_uploading_stop) {
                  this.images_three_uploading_stop = false
                  return
                }
                this.$refs.images_three_uploading.style.display = 'none'
                this.images_three = res.url
              }
            })
          }
          if (index == 1) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_four_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_four_uploading_stop) {
                  this.images_four_uploading_stop = false
                  return
                }
                this.$refs.images_four_uploading.style.display = 'none'
                this.images_four = res.url
              }
            })
          }
          if (index == 2) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_five_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_five_uploading_stop) {
                  this.images_five_uploading_stop = false
                  return
                }
                this.$refs.images_five_uploading.style.display = 'none'
                this.images_five = res.url
              }
            })
          }
          if (index == 3) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_six_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_six_uploading_stop) {
                  this.images_six_uploading_stop = false
                  return
                }
                this.$refs.images_six_uploading.style.display = 'none'
                this.images_six = res.url
              }
            })
          }
          if (index == 4) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_seven_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_seven_uploading_stop) {
                  this.images_seven_uploading_stop = false
                  return
                }
                this.$refs.images_seven_uploading.style.display = 'none'
                this.images_seven = res.url
              }
            })
          }
          if (index == 5) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_eight_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_eight_uploading_stop) {
                  this.images_eight_uploading_stop = false
                  return
                }
                this.$refs.images_eight_uploading.style.display = 'none'
                this.images_eight = res.url
              }
            })
          }
          if (index == 6) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }
                this.$refs.images_nine_uploading.style.display = 'none'
                this.images_nine = res.url
              }
            })
          }
        })
      }
    },
    uploadFile4(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_four_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_four_uploading_stop) {
              this.images_four_uploading_stop = false
              return
            }
            this.$refs.images_four_uploading.style.display = 'none'
            this.images_four = res.url
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_four_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_four_uploading_stop) {
                  this.images_four_uploading_stop = false
                  return
                }
                this.images_four = res.url
                this.$refs.images_four_uploading.style.display = 'none'
              }
            })
          }
          if (index == 1) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_five_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_five_uploading_stop) {
                  this.images_five_uploading_stop = false
                  return
                }
                this.$refs.images_five_uploading.style.display = 'none'
                this.images_five = res.url
              }
            })
          }
          if (index == 2) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_six_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_six_uploading_stop) {
                  this.images_six_uploading_stop = false
                  return
                }
                this.$refs.images_six_uploading.style.display = 'none'
                this.images_six = res.url
              }
            })
          }
          if (index == 3) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_seven_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_seven_uploading_stop) {
                  this.images_seven_uploading_stop = false
                  return
                }
                this.$refs.images_seven_uploading.style.display = 'none'
                this.images_seven = res.url
              }
            })
          }
          if (index == 4) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_eight_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_eight_uploading_stop) {
                  this.images_eight_uploading_stop = false
                  return
                }
                this.$refs.images_eight_uploading.style.display = 'none'
                this.images_eight = res.url
              }
            })
          }
          if (index == 5) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }
                this.$refs.images_nine_uploading.style.display = 'none'
                this.images_nine = res.url
              }
            })
          }
        })
      }
    },
    uploadFile5(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_five_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_five_uploading_stop) {
              this.images_five_uploading_stop = false
              return
            }
            this.$refs.images_five_uploading.style.display = 'none'
            this.images_five = res.url
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_five_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_five_uploading_stop) {
                  this.images_five_uploading_stop = false
                  return
                }
                this.$refs.images_five_uploading.style.display = 'none'
                this.images_five = res.url
              }
            })
          }
          if (index == 1) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_six_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_six_uploading_stop) {
                  this.images_six_uploading_stop = false
                  return
                }
                this.images_six = res.url
                this.$refs.images_six_uploading.style.display = 'none'
              }
            })
          }
          if (index == 2) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_seven_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_seven_uploading_stop) {
                  this.images_seven_uploading_stop = false
                  return
                }
                this.images_seven = res.url
                this.$refs.images_seven_uploading.style.display = 'none'
              }
            })
          }
          if (index == 3) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_eight_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_eight_uploading_stop) {
                  this.images_eight_uploading_stop = false
                  return
                }
                this.images_eight = res.url
                this.$refs.images_eight_uploading.style.display = 'none'
              }
            })
          }
          if (index == 4) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }
                this.images_nine = res.url
                this.$refs.images_nine_uploading.style.display = 'none'
              }
            })
          }
        })
      }
    },
    uploadFile6(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_six_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_six_uploading_stop) {
              this.images_six_uploading_stop = false
              return
            }
            this.images_six = res.url
            this.$refs.images_six_uploading.style.display = 'none'
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_six_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_six_uploading_stop) {
                  this.images_six_uploading_stop = false
                  return
                }
                this.$refs.images_six_uploading.style.display = 'none'
                this.images_six = res.url
              }
            })
          }
          if (index == 1) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_seven_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_seven_uploading_stop) {
                  this.images_seven_uploading_stop = false
                  return
                }
                this.$refs.images_seven_uploading.style.display = 'none'
                this.images_seven = res.url
              }
            })
          }
          if (index == 2) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_eight_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_eight_uploading_stop) {
                  this.images_eight_uploading_stop = false
                  return
                }
                this.$refs.images_eight_uploading.style.display = 'none'
                this.images_eight = res.url
              }
            })
          }
          if (index == 3) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }
                this.$refs.images_nine_uploading.style.display = 'none'
                this.images_nine = res.url
              }
            })
          }
        })
      }
    },
    uploadFile7(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_seven_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_seven_uploading_stop) {
              this.images_seven_uploading_stop = false
              return
            }
            this.$refs.images_seven_uploading.style.display = 'none'
            this.images_seven = res.url
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_seven_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_seven_uploading_stop) {
                  this.images_seven_uploading_stop = false
                  return
                }
                this.images_seven = res.url
                this.$refs.images_seven_uploading.style.display = 'none'
              }
            })
          }
          if (index == 1) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_eight_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_eight_uploading_stop) {
                  this.images_eight_uploading_stop = false
                  return
                }
                this.$refs.images_eight_uploading.style.display = 'none'
                this.images_eight = res.url
              }
            })
          }
          if (index == 2) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }
                this.images_nine = res.url
                this.$refs.images_nine_uploading.style.display = 'none'
              }
            })
          }
        })
      }
    },
    uploadFile8(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_eight_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_eight_uploading_stop) {
              this.images_eight_uploading_stop = false
              return
            }

            this.$refs.images_eight_uploading.style.display = 'none'
            this.images_eight = res.url
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_eight_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_eight_uploading_stop) {
                  this.images_eight_uploading_stop = false
                  return
                }
                this.$refs.images_eight_uploading.style.display = 'none'
                this.images_eight = res.url
              }
            })
          }
          if (index == 1) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }

                this.$refs.images_nine_uploading.style.display = 'none'
                this.images_nine = res.url
              }
            })
          }
        })
      }
    },
    uploadFile9(file) {
      if (!Array.isArray(file)) {
        const formData = new FormData()
        formData.append('file', file.file)
        this.$refs.images_nine_uploading.style.display = 'block'
        apiUpload(formData).then((res) => {
          if (res.code == 200) {
            if (this.images_nine_uploading_stop) {
              this.images_nine_uploading_stop = false
              return
            }
            this.$refs.images_nine_uploading.style.display = 'none'
            this.images_nine = res.url
          }
        })
      } else {
        file.forEach((item, index) => {
          if (index == 0) {
            const formData = new FormData()
            formData.append('file', item.file)
            this.$refs.images_nine_uploading.style.display = 'block'
            apiUpload(formData).then((res) => {
              if (res.code == 200) {
                if (this.images_nine_uploading_stop) {
                  this.images_nine_uploading_stop = false
                  return
                }

                this.$refs.images_nine_uploading.style.display = 'none'
                this.images_nine = res.url
              }
            })
          }
        })
      }
    },

    uploadVideoFunc(file) {
      const formData = new FormData()
      formData.append('file', file.file)
      apiUpload(formData).then((res) => {
        if (res.code == 200) {
          this.videos_one = res.url
        }
      })
    },
    onOversize(file) {
      console.log(file)
      Toast('文件大小不能超过 10MB')
    },

    editInfo() {
      if (this.normalPublish) {
        var errInf = ''
        if (this.name == '') {
          errInf = errInf + 'name、'
          this.$refs.refName.style.color = 'red'
        } else {
          this.$refs.refName.style.color = '#273458'
        }
        if (this.age == '') {
          errInf = errInf + 'age、'
          this.$refs.refAge.style.color = 'red'
        } else {
          this.$refs.refAge.style.color = '#273458'
        }

        if (this.street_info == '') {
          errInf = errInf + 'streetInfo、'
          this.$refs.refAddress.style.color = 'red'
        } else {
          this.$refs.refAddress.style.color = '#273458'
        }
        if (this.user_input_city_name == '') {
          errInf = errInf + 'city、'
          this.$refs.refInputCity.style.color = 'red'
        } else {
          this.$refs.refInputCity.style.color = '#273458'
        }

        let bool =
          (this.phone_number !== '' && this.phone_area_code !== '') ||
          this.email !== ''
        if (!bool) {
          errInf = errInf + 'phoneNum/email、'
          this.$refs.refPhoneEmail.style.color = 'red'
        } else {
          this.$refs.refPhoneEmail.style.color = '#273458'
        }

        if (this.independent == '') {
          errInf = errInf + 'Independent、'
          this.$refs.refIndependent.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refIndependent.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        if (this.oneOrMoreAvailable.length == 0) {
          errInf = errInf + 'Available TO、'
          this.$refs.refAvailableTo.style.color = 'red'
          this.$refs.refOneOrMore.style.color = 'red'
        } else {
          this.$refs.refAvailableTo.style.color = '#273458'
          this.$refs.refOneOrMore.style.color = '#273458'
        }

        if (this.provideService.length == 0) {
          errInf = errInf + 'ServIce provide as、'
          this.$refs.refProvideAs.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refProvideAs.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        let imgNum = 0
        if (this.images_one != '') {
          imgNum++
        }
        if (this.images_two != '') {
          imgNum++
        }
        if (this.images_three != '') {
          imgNum++
        }
        if (this.images_four != '') {
          imgNum++
        }
        if (this.images_five != '') {
          imgNum++
        }
        if (this.images_six != '') {
          imgNum++
        }
        if (this.images_seven != '') {
          imgNum++
        }
        if (this.images_eight != '') {
          imgNum++
        }
        if (this.images_nine != '') {
          imgNum++
        }

        if (this.images_one == '') {
          errInf = errInf + 'Thumbnail、'
          // this.$refs.refPhotos.style.color = 'red'
        } else {
          // this.$refs.refPhotos.style.color = '#273458'
        }

        if (imgNum < 4) {
          errInf = errInf + 'Upload 4 pictures、'
          this.$refs.refPhotos.style.color = 'red'
        } else {
          this.$refs.refPhotos.style.color = '#273458'
        }

        if (errInf != '') {
          this.errorMsg = errInf
          this.showErrorMsgBox = true
          // this.toastDialog(errInf);
          return
        }
      } else if (this.shopPublish) {
        if (
          this.images_one == '' ||
          this.images_two == '' ||
          this.images_three == ''
        ) {
          this.$toast.fail('Please fill it out completely')
          return
        }
      } else {
        //vip发布条件判断
        //用户最少上传4张照片，任意位置的照片均可以
        var errInf = ''
        if (this.name == '') {
          errInf = errInf + 'name、'
          this.$refs.refName.style.color = 'red'
        } else {
          this.$refs.refName.style.color = '#273458'
        }
        if (this.age == '') {
          errInf = errInf + 'age、'
          this.$refs.refAge.style.color = 'red'
        } else {
          this.$refs.refAge.style.color = '#273458'
        }

        // if (this.street_info == "") {
        //   errInf = errInf + "streetInfo、";
        //   this.$refs.refAddress.style.color="red"
        // }else{
        //   this.$refs.refAddress.style.color="#273458"
        // }
        // if (this.user_input_city_name == "") {
        //   errInf = errInf + "city、";
        //   this.$refs.refInputCity.style.color="red"
        // }else{
        //   this.$refs.refInputCity.style.color="#273458"
        // }

        let bool =
          (this.phone_number !== '' && this.phone_area_code !== '') ||
          this.email !== ''
        if (!bool) {
          errInf = errInf + 'phoneNum/email、'
          this.$refs.refPhoneEmail.style.color = 'red'
        } else {
          this.$refs.refPhoneEmail.style.color = '#273458'
        }

        if (this.independent == '') {
          errInf = errInf + 'Independent、'
          this.$refs.refIndependent.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refIndependent.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        if (this.oneOrMoreAvailable.length == 0) {
          errInf = errInf + 'Available TO、'
          this.$refs.refAvailableTo.style.color = 'red'
          this.$refs.refOneOrMore.style.color = 'red'
        } else {
          this.$refs.refAvailableTo.style.color = '#273458'
          this.$refs.refOneOrMore.style.color = '#273458'
        }

        if (this.provideService.length == 0) {
          errInf = errInf + 'ServIce provide as、'
          this.$refs.refProvideAs.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refProvideAs.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        let imgNum = 0
        if (this.images_one != '') {
          imgNum++
        }
        if (this.images_two != '') {
          imgNum++
        }
        if (this.images_three != '') {
          imgNum++
        }
        if (this.images_four != '') {
          imgNum++
        }
        if (this.images_five != '') {
          imgNum++
        }
        if (this.images_six != '') {
          imgNum++
        }
        if (this.images_seven != '') {
          imgNum++
        }
        if (this.images_eight != '') {
          imgNum++
        }
        if (this.images_nine != '') {
          imgNum++
        }

        if (this.images_one == '') {
          errInf = errInf + 'Thumbnail、'
          // this.$refs.refPhotos.style.color = 'red'
        } else {
          // this.$refs.refPhotos.style.color = '#273458'
        }

        if (imgNum < 4) {
          errInf = errInf + 'Upload 4 pictures、'
          // this.$refs.refPhotos.style.color="red"
        } else {
          // this.$refs.refPhotos.style.color="#273458"
        }

        if (errInf != '') {
          this.errorMsg = errInf
          this.showErrorMsgBox = true
          // this.toastDialog(errInf);
          return
        }
      }

      //必填校验通过，进行数据保存
      apiPOSTadvertisementEditBase({
        advertisementId: this.advertisementId,
        advertisementName: this.name,
        email: this.email,
        gender: this.gender,
        hairColor: this.hairColor,
        hairLength: this.hairLength,
        height: this.height,
        weight: this.weight,
        breastSize: this.breastSize,
        available: this.oneOrMoreAvailable.toString(),
        provide: this.provideService.toString(),
        independent: this.independent,

        eyeColor: this.eyeColor,
        travel: this.travel,

        //当前为单选城市
        city: this.dept_list_select[0].cityId,
        cityDetail: this.street_info,
        age: this.age,

        race: this.race,

        phoneNumber: this.phone_number,
        phoneAreaCode: this.phone_area_code,
        imagesOne: this.images_one,
        videosOne: this.videos_one,
        imagesTwo: this.images_two,
        imagesThree: this.images_three,
        imagesFour: this.images_four,
        imagesFive: this.images_five,
        imagesSix: this.images_six,
        imagesSeven: this.images_seven,
        imagesEight: this.images_eight,
        imagesNine: this.images_nine,

        introduce: this.introduce,

        // 店铺
        // shopname: this.shopname, //商铺名称
        // tableShower: this.table_shower, //table_shower
        // sauna: this.sauna,
        // jacuzzi: this.jacuzzi,
        // acceptCreditCard: this.accept_credit_card,
        // ratefor30: this.ratefor30,
        // ratefor45: this.ratefor45,
        // ratefor60: this.ratefor60,
        // payment: this.payment, //付款方式
        // mondayAm: this.mondayAm,
        // tuesdayAm: this.thursdayAm,
        // wednesdayAm: this.wednesdayAm,
        // thursdayAm: this.thursdayAm,
        // fridayAm: this.fridayAm,
        // saturdayAm: this.saturdayAm,
        // sundayAm: this.sundayAm,
        // mondayPm: this.mondayPm,
        // tuesdayPm: this.tuesdayPm,
        // wednesdayPm: this.wednesdayPm,
        // thursdayPm: this.thursdayPm,
        // fridayPm: this.fridayPm,
        // saturdayPm: this.saturdayPm,
        // sundayPm: this.saturdayPm,

        // vip
        // advertisementTitleOne: this.advertisementTitleOne,
        // advertisementTitleTwo: this.advertisementTitleTwo,
        // advertisementTitleThree: this.advertisementTitleThree,
        advertisementRemarkOne: this.advertisementRemarkOne,
        advertisementRemarkTwo: this.advertisementRemarkTwo,
        advertisementRemarkThree: this.advertisementRemarkThree,
      }).then((res) => {
        if (res.code == 200) {
          Toast.success(res.msg)
          this.advertisementId = res.data
          setTimeout(() => {
            this.$router.push('/myAD')
          }, 2000)
        } else {
          Toast.fail(res.msg)
        }
      })
    },
    updateDraftInfo() {
      if (this.normalPublish) {
        var errInf = ''
        if (this.name == '') {
          errInf = errInf + 'name、'
          this.$refs.refName.style.color = 'red'
        } else {
          this.$refs.refName.style.color = '#273458'
        }
        if (this.age == '') {
          errInf = errInf + 'age、'
          this.$refs.refAge.style.color = 'red'
        } else {
          this.$refs.refAge.style.color = '#273458'
        }

        if (this.street_info == '') {
          errInf = errInf + 'streetInfo、'
          this.$refs.refAddress.style.color = 'red'
        } else {
          this.$refs.refAddress.style.color = '#273458'
        }
        if (this.user_input_city_name == '') {
          errInf = errInf + 'city、'
          this.$refs.refInputCity.style.color = 'red'
        } else {
          this.$refs.refInputCity.style.color = '#273458'
        }

        let bool =
          (this.phone_number !== '' && this.phone_area_code !== '') ||
          this.email !== ''
        if (!bool) {
          errInf = errInf + 'phoneNum/email、'
          this.$refs.refPhoneEmail.style.color = 'red'
        } else {
          this.$refs.refPhoneEmail.style.color = '#273458'
        }

        if (this.independent == '') {
          errInf = errInf + 'Independent、'
          this.$refs.refIndependent.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refIndependent.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        if (this.oneOrMoreAvailable.length == 0) {
          errInf = errInf + 'Available TO、'
          this.$refs.refAvailableTo.style.color = 'red'
          this.$refs.refOneOrMore.style.color = 'red'
        } else {
          this.$refs.refAvailableTo.style.color = '#273458'
          this.$refs.refOneOrMore.style.color = '#273458'
        }

        if (this.provideService.length == 0) {
          errInf = errInf + 'ServIce provide as、'
          this.$refs.refProvideAs.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refProvideAs.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        let imgNum = 0
        if (this.images_one != '') {
          imgNum++
        }
        if (this.images_two != '') {
          imgNum++
        }
        if (this.images_three != '') {
          imgNum++
        }
        if (this.images_four != '') {
          imgNum++
        }
        if (this.images_five != '') {
          imgNum++
        }
        if (this.images_six != '') {
          imgNum++
        }
        if (this.images_seven != '') {
          imgNum++
        }
        if (this.images_eight != '') {
          imgNum++
        }
        if (this.images_nine != '') {
          imgNum++
        }

        if (this.images_one == '') {
          errInf = errInf + 'Thumbnail、'
          // this.$refs.refPhotos.style.color = 'red'
        } else {
          // this.$refs.refPhotos.style.color = '#273458'
        }

        if (this.images_one != '') {
          errInf = errInf + 'Thumbnail、'
          // this.$refs.refPhotos.style.color = 'red'
        } else {
          // this.$refs.refPhotos.style.color = '#273458'
        }

        if (imgNum < 4) {
          errInf = errInf + 'Upload 4 pictures、'
          this.$refs.refPhotos.style.color = 'red'
        } else {
          this.$refs.refPhotos.style.color = '#273458'
        }

        if (errInf != '') {
          this.errorMsg = errInf
          this.showErrorMsgBox = true
          // this.toastDialog(errInf);
          return
        }
      } else if (this.shopPublish) {
        if (
          this.images_one == '' ||
          this.images_two == '' ||
          this.images_three == ''
        ) {
          this.$toast.fail('Please fill it out completely')
          return
        }
      } else {
        //vip发布条件判断
        //用户最少上传4张照片，任意位置的照片均可以
        var errInf = ''
        if (this.name == '') {
          errInf = errInf + 'name、'
          this.$refs.refName.style.color = 'red'
        } else {
          this.$refs.refName.style.color = '#273458'
        }
        if (this.age == '') {
          errInf = errInf + 'age、'
          this.$refs.refAge.style.color = 'red'
        } else {
          this.$refs.refAge.style.color = '#273458'
        }

        // if (this.street_info == "") {
        //   errInf = errInf + "streetInfo、";
        //   this.$refs.refAddress.style.color="red"
        // }else{
        //   this.$refs.refAddress.style.color="#273458"
        // }
        // if (this.user_input_city_name == "") {
        //   errInf = errInf + "city、";
        //   this.$refs.refInputCity.style.color="red"
        // }else{
        //   this.$refs.refInputCity.style.color="#273458"
        // }

        let bool =
          (this.phone_number !== '' && this.phone_area_code !== '') ||
          this.email !== ''
        if (!bool) {
          errInf = errInf + 'phoneNum/email、'
          this.$refs.refPhoneEmail.style.color = 'red'
        } else {
          this.$refs.refPhoneEmail.style.color = '#273458'
        }

        if (this.independent == '') {
          errInf = errInf + 'Independent、'
          this.$refs.refIndependent.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refIndependent.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        if (this.oneOrMoreAvailable.length == 0) {
          errInf = errInf + 'Available TO、'
          this.$refs.refAvailableTo.style.color = 'red'
          this.$refs.refOneOrMore.style.color = 'red'
        } else {
          this.$refs.refAvailableTo.style.color = '#273458'
          this.$refs.refOneOrMore.style.color = '#273458'
        }

        if (this.provideService.length == 0) {
          errInf = errInf + 'ServIce provide as、'
          this.$refs.refProvideAs.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refProvideAs.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        let imgNum = 0
        if (this.images_one != '') {
          imgNum++
        }
        if (this.images_two != '') {
          imgNum++
        }
        if (this.images_three != '') {
          imgNum++
        }
        if (this.images_four != '') {
          imgNum++
        }
        if (this.images_five != '') {
          imgNum++
        }
        if (this.images_six != '') {
          imgNum++
        }
        if (this.images_seven != '') {
          imgNum++
        }
        if (this.images_eight != '') {
          imgNum++
        }
        if (this.images_nine != '') {
          imgNum++
        }

        if (this.images_one == '') {
          errInf = errInf + 'Thumbnail、'
          // this.$refs.refPhotos.style.color = 'red'
        } else {
          // this.$refs.refPhotos.style.color = '#273458'
        }

        if (imgNum < 4) {
          errInf = errInf + 'Upload 4 pictures、'
          // this.$refs.refPhotos.style.color="red"
        } else {
          // this.$refs.refPhotos.style.color="#273458"
        }

        if (errInf != '') {
          this.errorMsg = errInf
          this.showErrorMsgBox = true
          // this.toastDialog(errInf);
          return
        }
      }

      let type = ''
      this.type.forEach((e, index) => {
        if (index == this.type.length - 1) {
          type += e
        } else {
          type += e + ','
        }
      })

      //必填校验通过，进行数据保存
      apiPOSTAdUpdateDraftInfo({
        advertisementId: this.advertisementId,
        advertisementName: this.name,
        email: this.email,
        gender: this.gender,
        hairColor: this.hairColor,
        hairLength: this.hairLength,
        height: this.height,
        weight: this.weight,
        breastSize: this.breastSize,
        available: this.oneOrMoreAvailable.toString(),
        provide: this.provideService.toString(),
        independent: this.independent,

        eyeColor: this.eyeColor,
        travel: this.travel,

        //当前为单选城市
        city: this.dept_list_select[0].cityId,
        cityDetail: this.street_info,
        age: this.age,

        race: this.race,

        phoneNumber: this.phone_number,
        phoneAreaCode: this.phone_area_code,
        imagesOne: this.images_one,
        videosOne: this.videos_one,
        imagesTwo: this.images_two,
        imagesThree: this.images_three,
        imagesFour: this.images_four,
        imagesFive: this.images_five,
        imagesSix: this.images_six,
        imagesSeven: this.images_seven,
        imagesEight: this.images_eight,
        imagesNine: this.images_nine,

        introduce: this.introduce,

        // 店铺
        // shopname: this.shopname, //商铺名称
        // tableShower: this.table_shower, //table_shower
        // sauna: this.sauna,
        // jacuzzi: this.jacuzzi,
        // acceptCreditCard: this.accept_credit_card,
        // ratefor30: this.ratefor30,
        // ratefor45: this.ratefor45,
        // ratefor60: this.ratefor60,
        // payment: this.payment, //付款方式
        // mondayAm: this.mondayAm,
        // tuesdayAm: this.thursdayAm,
        // wednesdayAm: this.wednesdayAm,
        // thursdayAm: this.thursdayAm,
        // fridayAm: this.fridayAm,
        // saturdayAm: this.saturdayAm,
        // sundayAm: this.sundayAm,
        // mondayPm: this.mondayPm,
        // tuesdayPm: this.tuesdayPm,
        // wednesdayPm: this.wednesdayPm,
        // thursdayPm: this.thursdayPm,
        // fridayPm: this.fridayPm,
        // saturdayPm: this.saturdayPm,
        // sundayPm: this.saturdayPm,

        // vip
        // advertisementTitleOne: this.advertisementTitleOne,
        // advertisementTitleTwo: this.advertisementTitleTwo,
        // advertisementTitleThree: this.advertisementTitleThree,
        advertisementRemarkOne: this.advertisementRemarkOne,
        advertisementRemarkTwo: this.advertisementRemarkTwo,
        advertisementRemarkThree: this.advertisementRemarkThree,

        contactWechat: this.contactWechat,
        contactTelefram: this.contactTelefram,
        contactTwitter: this.contactTwitter,
        contactFacebook: this.contactFacebook,
        contactIngstagram: this.contactIngstagram,

        category: this.category,

        recommendImageOne: this.recommendImageOne,
        recommendImageTwo: this.recommendImageTwo,
        recommendImageThree: this.recommendImageThree,
        largeImage: this.largeImage,

        type: type,
        status: 'draft',
        // 店铺
        shopname: this.shopname, //商铺名称
        tableShower: this.table_shower, //table_shower
        sauna: this.sauna,
        jacuzzi: this.jacuzzi,
        acceptCreditCard: this.accept_credit_card,
        ratefor30: this.ratefor30,
        ratefor45: this.ratefor45,
        ratefor60: this.ratefor60,
        payment: this.payment, //付款方式
        mondayAm: this.mondayAm,
        tuesdayAm: this.thursdayAm,
        wednesdayAm: this.wednesdayAm,
        thursdayAm: this.thursdayAm,
        fridayAm: this.fridayAm,
        saturdayAm: this.saturdayAm,
        sundayAm: this.sundayAm,
        mondayPm: this.mondayPm,
        tuesdayPm: this.tuesdayPm,
        wednesdayPm: this.wednesdayPm,
        thursdayPm: this.thursdayPm,
        fridayPm: this.fridayPm,
        saturdayPm: this.saturdayPm,
        sundayPm: this.saturdayPm,

        //设置购买时长 小图 大图 推荐 默认天数（默认30天）
        expireDateDays: 0,
        topExpireDateDays: this.dept_list_select_ad_top[0].selected2,
        recommendExpireDateDays: this.dept_list_select_ad[0].selected1,
        normalExpireDateDays: this.checked_days_text,

        advertisementMoney:
          (this.totol_top_and_tuijian * 100 +
            this.nowCityAdManeyPreMonth * 100) /
          100,
      }).then((res) => {
        if (res.code == 200) {
          // Toast.success(res.msg);
          this.advertisementId = res.data
        } else {
          // Toast.fail(res.msg);
        }
      })
    },

    postDraft() {
      // debugger

      if (this.normalPublish) {
        var errInf = ''
        if (this.name == '') {
          errInf = errInf + 'name、'
          this.$refs.refName.style.color = 'red'
        } else {
          this.$refs.refName.style.color = '#273458'
        }
        if (this.age == '') {
          errInf = errInf + 'age、'
          this.$refs.refAge.style.color = 'red'
        } else {
          this.$refs.refAge.style.color = '#273458'
        }

        if (this.street_info == '') {
          errInf = errInf + 'streetInfo、'
          this.$refs.refAddress.style.color = 'red'
        } else {
          this.$refs.refAddress.style.color = '#273458'
        }
        if (this.user_input_city_name == '') {
          errInf = errInf + 'city、'
          this.$refs.refInputCity.style.color = 'red'
        } else {
          this.$refs.refInputCity.style.color = '#273458'
        }

        let bool =
          (this.phone_number !== '' && this.phone_area_code !== '') ||
          this.email !== ''
        if (!bool) {
          errInf = errInf + 'phoneNum/email、'
          this.$refs.refPhoneEmail.style.color = 'red'
        } else {
          this.$refs.refPhoneEmail.style.color = '#273458'
        }

        if (this.independent == '') {
          errInf = errInf + 'Independent、'
          this.$refs.refIndependent.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refIndependent.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        if (this.oneOrMoreAvailable.length == 0) {
          errInf = errInf + 'Available TO、'
          this.$refs.refAvailableTo.style.color = 'red'
          this.$refs.refOneOrMore.style.color = 'red'
        } else {
          this.$refs.refAvailableTo.style.color = '#273458'
          this.$refs.refOneOrMore.style.color = '#273458'
        }

        if (this.provideService.length == 0) {
          errInf = errInf + 'ServIce provide as、'
          this.$refs.refProvideAs.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refProvideAs.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        let imgNum = 0
        if (this.images_one != '') {
          imgNum++
        }
        if (this.images_two != '') {
          imgNum++
        }
        if (this.images_three != '') {
          imgNum++
        }
        if (this.images_four != '') {
          imgNum++
        }
        if (this.images_five != '') {
          imgNum++
        }
        if (this.images_six != '') {
          imgNum++
        }
        if (this.images_seven != '') {
          imgNum++
        }
        if (this.images_eight != '') {
          imgNum++
        }
        if (this.images_nine != '') {
          imgNum++
        }

        if (this.images_one == '') {
          errInf = errInf + 'Thumbnail、'
          // this.$refs.refPhotos.style.color = 'red'
        } else {
          // this.$refs.refPhotos.style.color = '#273458'
        }

        if (imgNum < 4) {
          errInf = errInf + 'Upload 4 pictures、'
          this.$refs.refPhotos.style.color = 'red'
        } else {
          this.$refs.refPhotos.style.color = '#273458'
        }

        if (errInf != '') {
          this.errorMsg = errInf
          this.showErrorMsgBox = true
          // this.toastDialog(errInf);
          return
        }
      } else if (this.shopPublish) {
        if (
          this.images_one == '' ||
          this.images_two == '' ||
          this.images_three == ''
        ) {
          this.$toast.fail('Please fill it out completely')
          return
        }
      } else {
        //vip发布条件判断
        //用户最少上传4张照片，任意位置的照片均可以
        var errInf = ''
        if (this.name == '') {
          errInf = errInf + 'name、'
          this.$refs.refName.style.color = 'red'
        } else {
          this.$refs.refName.style.color = '#273458'
        }
        if (this.age == '') {
          errInf = errInf + 'age、'
          this.$refs.refAge.style.color = 'red'
        } else {
          this.$refs.refAge.style.color = '#273458'
        }

        // if (this.street_info == "") {
        //   errInf = errInf + "streetInfo、";
        //   this.$refs.refAddress.style.color="red"
        // }else{
        //   this.$refs.refAddress.style.color="#273458"
        // }
        // if (this.user_input_city_name == "") {
        //   errInf = errInf + "city、";
        //   this.$refs.refInputCity.style.color="red"
        // }else{
        //   this.$refs.refInputCity.style.color="#273458"
        // }

        let bool =
          (this.phone_number !== '' && this.phone_area_code !== '') ||
          this.email !== ''
        if (!bool) {
          errInf = errInf + 'phoneNum/email、'
          this.$refs.refPhoneEmail.style.color = 'red'
        } else {
          this.$refs.refPhoneEmail.style.color = '#273458'
        }

        if (this.independent == '') {
          errInf = errInf + 'Independent、'
          this.$refs.refIndependent.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refIndependent.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        if (this.oneOrMoreAvailable.length == 0) {
          errInf = errInf + 'Available TO、'
          this.$refs.refAvailableTo.style.color = 'red'
          this.$refs.refOneOrMore.style.color = 'red'
        } else {
          this.$refs.refAvailableTo.style.color = '#273458'
          this.$refs.refOneOrMore.style.color = '#273458'
        }

        if (this.provideService.length == 0) {
          errInf = errInf + 'ServIce provide as、'
          this.$refs.refProvideAs.style.color = 'red'
          this.$refs.refAvailableTo.style.color = 'red'
        } else {
          this.$refs.refProvideAs.style.color = '#273458'
          this.$refs.refAvailableTo.style.color = '#273458'
        }

        let imgNum = 0
        if (this.images_one != '') {
          imgNum++
        }
        if (this.images_two != '') {
          imgNum++
        }
        if (this.images_three != '') {
          imgNum++
        }
        if (this.images_four != '') {
          imgNum++
        }
        if (this.images_five != '') {
          imgNum++
        }
        if (this.images_six != '') {
          imgNum++
        }
        if (this.images_seven != '') {
          imgNum++
        }
        if (this.images_eight != '') {
          imgNum++
        }
        if (this.images_nine != '') {
          imgNum++
        }
        
        if (this.images_one == '') {
          errInf = errInf + 'Thumbnail、'
          // this.$refs.refPhotos.style.color = 'red'
        } else {
          // this.$refs.refPhotos.style.color = '#273458'
        }

        if (imgNum < 4) {
          errInf = errInf + 'Upload 4 pictures、'
          // this.$refs.refPhotos.style.color="red"
        } else {
          // this.$refs.refPhotos.style.color="#273458"
        }

        if (errInf != '') {
          this.errorMsg = errInf
          this.showErrorMsgBox = true
          // this.toastDialog(errInf);
          return
        }
      }

      if (
        (!this.recommendImageOne ||
          !this.recommendImageTwo ||
          !this.recommendImageThree) &&
        this.type.includes('3')
      ) {
        this.toastDialog('Must upload recommended three images')
        return
      }
      if (!this.largeImage && this.type.includes('2')) {
        this.toastDialog('Must upload one large image')
        return
      }

      // if(this.street_info==''){
      //   Toast('MUst input street info!')
      //   return
      // }
      this.stepThree = false
      this.stepFour = true
      this.dept_list_select_totol_days = this.dept_list_select_totol
      let adId = this.$route.query.advertisementId
      console.log('adId' + adId)

      // if (adId) {
      //   this.PUT_apiPOSTadvertisement();
      //   return;
      // }
      //一次发布流程仅保存一条数据
      if (this.draftSaved == true) {
        //进行数据修改
        this.updateDraftInfo()
      } else {
        //保存草稿箱
        this.POST_apiPOSTadvertisement()
      }
    },
    //发布广告接口  === 草稿
    POST_apiPOSTadvertisement() {
      let upgrade = this.checked_days_text
      // let cityData = []
      this.cityData = {}
      //当前为单选城市
      this.dept_list_select.forEach((element, index) => {
        this.deptTree_select_id = element.cityId
        this.cityData = {
          cityName: element.cityName,
          cityType: element.cityType,
          isPopularCity: element.isPopularCity,
          // european: element.cityName,
          // street: element.city_street,
          // number: element.city_number,
          // fillin: element.phone_number,
          // cityId: element.parentId,
          // upgrade: upgrade,
          // cityDetail: '',
        }
        // if (element.parentId === this.selectCity) {
        //   data.cityDetail = this.street_info
        // }
        // cityData.push(data)
      })

      let type = ''
      this.type.forEach((e, index) => {
        if (index == this.type.length - 1) {
          type += e
        } else {
          type += e + ','
        }
      })
      if (this.checked_days_text > 0) {
        if (this.type.length > 0) {
          type = type + ',1'
        } else {
          type = '1'
        }
      }
      apiPOSTadvertisement({
        advertisementName: this.name,
        email: this.email,
        chooseGender: this.gender,
        hairColor: this.hairColor,
        hairLength: this.hairLength,
        height: this.height,
        weight: this.weight,
        breastSize: this.breastSize,
        available: this.oneOrMoreAvailable.toString(),
        provide: this.provideService.toString(),
        independent: this.independent,
        contactWechat: this.contactWechat,
        contactTelefram: this.contactTelefram,
        contactTwitter: this.contactTwitter,
        contactFacebook: this.contactFacebook,
        contactIngstagram: this.contactIngstagram,

        gender: this.gender,
        eyeColor: this.eyeColor,
        travel: this.travel,

        category: this.category,
        city: this.deptTree_select_id,
        cityDetail: this.street_info,
        step3InputCity: this.user_input_city_name,

        age: this.age,
        langeuage: this.language,
        race: this.race,
        occupation: this.occupation,
        phoneNumber: this.phone_number,
        phoneAreaCode: this.phone_area_code,
        imagesOne: this.images_one,
        videosOne: this.videos_one,
        imagesTwo: this.images_two,
        imagesThree: this.images_three,
        imagesFour: this.images_four,
        imagesFive: this.images_five,
        imagesSix: this.images_six,
        imagesSeven: this.images_seven,
        imagesEight: this.images_eight,
        imagesNine: this.images_nine,
        recommendImageOne: this.recommendImageOne,
        recommendImageTwo: this.recommendImageTwo,
        recommendImageThree: this.recommendImageThree,
        largeImage: this.largeImage,
        introduce: this.introduce,
        cityData: this.cityData,
        type: type,
        status: 'draft',
        // 店铺
        shopname: this.shopname, //商铺名称
        tableShower: this.table_shower, //table_shower
        sauna: this.sauna,
        jacuzzi: this.jacuzzi,
        acceptCreditCard: this.accept_credit_card,
        ratefor30: this.ratefor30,
        ratefor45: this.ratefor45,
        ratefor60: this.ratefor60,
        payment: this.payment, //付款方式
        mondayAm: this.mondayAm,
        tuesdayAm: this.thursdayAm,
        wednesdayAm: this.wednesdayAm,
        thursdayAm: this.thursdayAm,
        fridayAm: this.fridayAm,
        saturdayAm: this.saturdayAm,
        sundayAm: this.sundayAm,
        mondayPm: this.mondayPm,
        tuesdayPm: this.tuesdayPm,
        wednesdayPm: this.wednesdayPm,
        thursdayPm: this.thursdayPm,
        fridayPm: this.fridayPm,
        saturdayPm: this.saturdayPm,
        sundayPm: this.saturdayPm,
        // vip
        advertisementName: this.name,
        email: this.email,
        // advertisementTitleOne: this.advertisementTitleOne,
        // advertisementTitleTwo: this.advertisementTitleTwo,
        // advertisementTitleThree: this.advertisementTitleThree,
        advertisementRemarkOne: this.advertisementRemarkOne,
        advertisementRemarkTwo: this.advertisementRemarkTwo,
        advertisementRemarkThree: this.advertisementRemarkThree,

        //设置购买时长 小图 大图 推荐 默认天数（默认30天）
        expireDateDays: 0,
        topExpireDateDays: this.dept_list_select_ad_top[0].selected2,
        recommendExpireDateDays: this.dept_list_select_ad[0].selected1,
        normalExpireDateDays: this.checked_days_text,

        advertisementMoney:
          (this.totol_top_and_tuijian * 100 +
            this.nowCityAdManeyPreMonth * 100) /
          100,
      }).then((res) => {
        if (res.code == 200) {
          // Toast.success(res.msg);
          this.advertisementId = res.data

          //设置标志位，已保存,用于校验，一次正常发布流程，仅保存一条数据
          this.draftSaved = true
          // setTimeout(() => {
          //   this.$router.push("/myAD");
          // }, 2000);
        } else {
          Toast.fail(res.msg)
        }
      })
    },
    //发布广告接口  ==编辑
    PUT_apiPOSTadvertisement() {
      let adId = this.$route.query.advertisementId
      // if (!adId) {
      // let upgrade = this.checked_days_text;
      // this.cityData = []
      // this.cityData = {};
      //当前为单选城市
      // this.dept_list_select.forEach((element, index) => {
      //   this.deptTree_select_id = element.cityId;
      //   this.cityData = {
      //     cityName: element.cityName,
      //     cityType: element.cityType,
      //     isPopularCity: element.isPopularCity,
      // european: element.cityName,
      // street: element.city_street,
      // number: element.city_number,
      // fillin: element.phone_number,
      // cityId: element.parentId,
      // upgrade: upgrade,
      // };
      // if (element.parentId === this.selectCity) {
      //   data.cityDetail = this.street_info
      // }
      // this.cityData.push(data)
      // });
      // }
      let type = ''
      this.type.forEach((e, index) => {
        if (index == this.type.length - 1) {
          type += e
        } else {
          type += e + ','
        }
      })

      if (this.checked_days_text > 0) {
        if (this.type.length > 0) {
          type = type + ',1'
        } else {
          type = '1'
        }
      }
      apiPOSTadvertisement_put({
        advertisementName: this.name,
        email: this.email,
        chooseGender: this.gender,
        hairColor: this.hairColor,
        hairLength: this.hairLength,
        height: this.height,
        weight: this.weight,
        breastSize: this.breastSize,
        available: this.oneOrMoreAvailable.toString(),
        provide: this.provideService.toString(),
        independent: this.independent,
        contactWechat: this.contactWechat,
        contactTelefram: this.contactTelefram,
        contactTwitter: this.contactTwitter,
        contactFacebook: this.contactFacebook,
        contactIngstagram: this.contactIngstagram,

        gender: this.gender,
        eyeColor: this.eyeColor,
        travel: this.travel,

        advertisementMoney:
          (this.dept_list_select_totol_days * 100 +
            this.totol_top_and_tuijian * 100 +
            this.totol_normal * 100) /
          100,
        category: this.category,
        city: this.dept_list_select[0].cityId,
        cityDetail: this.street_info,
        age: this.age,
        langeuage: this.language,
        race: this.race,
        occupation: this.occupation,
        phoneNumber: this.phone_number,
        phoneAreaCode: this.phone_area_code,
        imagesOne: this.images_one,
        videosOne: this.videos_one,
        imagesTwo: this.images_two,
        imagesThree: this.images_three,
        imagesFour: this.images_four,
        imagesFive: this.images_five,
        imagesSix: this.images_six,
        imagesSeven: this.images_seven,
        imagesEight: this.images_eight,
        imagesNine: this.images_nine,
        recommendImageOne: this.recommendImageOne,
        recommendImageTwo: this.recommendImageTwo,
        recommendImageThree: this.recommendImageThree,
        largeImage: this.largeImage,
        introduce: this.introduce,
        cityData: this.cityData,
        // PUT字段
        type: type,
        advertisementId: this.advertisementId,
        // 店铺
        shopname: this.shopname, //商铺名称
        tableShower: this.table_shower, //table_shower
        sauna: this.sauna,
        jacuzzi: this.jacuzzi,
        acceptCreditCard: this.accept_credit_card,
        ratefor30: this.ratefor30,
        ratefor45: this.ratefor45,
        ratefor60: this.ratefor60,
        payment: this.payment,
        mondayAm: this.mondayAm,
        tuesdayAm: this.thursdayAm,
        wednesdayAm: this.wednesdayAm,
        thursdayAm: this.thursdayAm,
        fridayAm: this.fridayAm,
        saturdayAm: this.saturdayAm,
        sundayAm: this.sundayAm,
        mondayPm: this.mondayPm,
        tuesdayPm: this.tuesdayPm,
        wednesdayPm: this.wednesdayPm,
        thursdayPm: this.thursdayPm,
        fridayPm: this.fridayPm,
        saturdayPm: this.saturdayPm,
        sundayPm: this.saturdayPm,
        // vip
        advertisementName: this.name,
        email: this.email,
        // advertisementTitleOne: this.advertisementTitleOne,
        // advertisementTitleTwo: this.advertisementTitleTwo,
        // advertisementTitleThree: this.advertisementTitleThree,
        advertisementRemarkOne: this.advertisementRemarkOne,
        advertisementRemarkTwo: this.advertisementRemarkTwo,
        advertisementRemarkThree: this.advertisementRemarkThree,

        //设置购买时长 小图 大图 推荐 默认天数（默认30天）
        expireDateDays: 30,
        topExpireDateDays: this.dept_list_select_ad_top[0].selected2,
        recommendExpireDateDays: this.dept_list_select_ad[0].selected1,
        normalExpireDateDays: this.checked_days_text,
      }).then((res) => {
        if (res.code == 200) {
          Toast.success()
          this.advertisementId = res.data
          setTimeout(() => {
            this.$router.push('/myAD')
          }, 2000)
        } else if (res.code == 205) {
          this.showReleaseBox = true
        } else {
          Toast.fail(res.msg)
        }
      })
    },
    rechargeMoney() {
      this.showReleaseBox = false
      this.$router.replace('/recharge')
    },
    goMyAd() {
      this.showReleaseBox = false
      this.$router.push('/myAD')
    },
    chooseRecommend(item) {
      this.selected1 = item
      // this.dept_list_select_ad.forEach((element, index) => {
      //   this.dept_list_select_ad[index].selected1 = item
      // })
      this.dept_list_select_ad.map((x) => {
        x.selected1 = item
        return x
      })
    },
    chooseTop(item) {
      this.selected2 = item
      // this.dept_list_select_ad_top.forEach((element, index) => {
      //   this.dept_list_select_ad_top[index].selected2 = item
      // })
      this.dept_list_select_ad_top.map((x) => {
        x.selected2 = item
        return x
      })
    },
    chooseType() {
      //判断显示与否
      this.showRecommendSection = !this.showRecommendSection
      //若升级
      if (this.showRecommendSection) {
        //设置天数为10 watch type 触发
        this.selected1 = this.dept_list_select_ad[0].selected1
        // this.$refs.recommondRef.toggleAll(true)
        if (this.type.indexOf('3') == -1) {
          this.type.push('3')
        }
        //若不升级
      } else {
        //设置天数为0 watch type 触发
        this.selected1 = 0
        // this.$refs.recommondRef.toggleAll(false)
        if (this.type.indexOf('3') !== -1) {
          this.type = this.type.filter((x) => x !== '3')
        }
      }
    },
    chooseTypeTop() {
      this.showTopSection = !this.showTopSection
      //若升级
      if (this.showTopSection) {
        //设置天数为10 watch type 触发
        this.selected2 = this.dept_list_select_ad_top[0].selected2
        // this.$refs.topRef.toggleAll(true)
        if (this.type.indexOf('2') == -1) {
          this.type.push('2')
        }
        //若不升级
      } else {
        //设置天数为0 watch type 触发
        this.selected2 = 0
        // this.$refs.topRef.toggleAll(false)
        if (this.type.indexOf('2') !== -1) {
          this.type = this.type.filter((x) => x !== '2')
        }
      }
    },
    removeCity(item) {
      this.dept_list_select = this.dept_list_select.filter(
        (x) => x.deptId !== item.deptId
      )
    },
    chooseCity(item) {
      console.log(item, '-----======')
    },
    getNearBys() {
      apiGetGoogleMapDetail({
        streetInfo: this.street_info,
        cityName: this.user_input_city_name,
        state: this.deptTree_select,
      }).then((res) => {
        if (res.code === 200) {
          this.showstreetpopup = true
          this.streetPopupList = res.data
        }
      })
      console.log(this.selectCity, this.street_info, '--------')
    },
    choosepopupInfo(item) {
      this.street_info = ''
      this.street_info = item
      this.isConfirmStreetInfo = true
      this.showstreetpopup = false
    },
    chooseGender(item) {
      this.gender = item.dictValue
      this.genderName = item.dictLabel
      this.showgenderBox = false
    },
    chooseAge(item) {
      this.age = item.dictValue
      this.ageName = item.dictLabel
      this.showAgeBox = false
    },
    chooseHeight(item) {
      this.height = item.dictValue
      this.heightName = item.dictLabel
      this.showHeightBox = false
    },
    chooseBreastSize(item) {
      this.breastSize = item.dictValue
      this.breastSizeName = item.dictLabel
      this.showbreastSizeBox = false
    },
    chooseHairColor(item) {
      this.hairColor = item.dictValue
      this.hairColorName = item.dictLabel
      this.showhairColorBox = false
    },
    chooseTravel(item) {
      this.travel = item.dictValue
      this.travelName = item.dictLabel
      this.showTravelBox = false
    },
    chooseEyeColor(item) {
      this.eyeColor = item.dictValue
      this.eyeColorName = item.dictLabel
      this.showeyeColorBox = false
    },
    chooseHairLength(item) {
      this.hairLength = item.dictValue
      this.hairLengthName = item.dictLabel
      this.showhairLengthBox = false
    },
    chooseWeight(item) {
      this.weight = item.dictValue
      this.weightName = item.dictLabel
      this.showWeightBox = false
    },
    showcountries() {
      this.showcountriesflag = !this.showcountriesflag
      apiGetDeptList_p({
        parentId: '1',
        category: this.category,
      }).then((res) => {
        if (res.code === 200) {
          this.deptTreeCountries = res.data
        }
      })
    },
    selectTocity(item) {
      this.country_select = item.label
      this.showcountriesflag = false
      if (item.deptId === 100) {
        apiGetDeptList_p({
          parentId: item.deptId,
          category: this.category,
        }).then((res) => {
          if (res.code == 200) {
            this.deptTree = res.data
          }
        })
      } else {
        apiGetDeptList_p({
          parentId: item.deptId,
          category: this.category,
        }).then((res) => {
          if (res.code == 200) {
            this.deptTree_select = item.cityName
            this.deptTree_select_id = item.city
            this.show_are = false
            this.show_are_maney = true
            this.dept_list = res.data
          }
        })
      }
    },
    streetInfoChange() {
      var isStreetInfoValue = Boolean(this.street_info)
      var isInputCityNameValue = Boolean(this.user_input_city_name)
      if (isStreetInfoValue && isInputCityNameValue) {
        this.streetInfoStatus = false
      } else {
        this.streetInfoStatus = true
        this.isConfirmStreetInfo = false
      }
    },
    toggle(index) {
      console.log('点击')
      console.log(index, 'index')
      this.$refs.checkboxes[index].toggle()
    },
    showconfirm() {
      Dialog.confirm({
        title: 'confirm payment',
        message:
          '$' +
          (this.nowCityAdManeyPreMonth * 100 +
            this.totol_normal * 100 +
            this.totol_top_and_tuijian * 100) /
            100,
      })
        .then(() => {
          //on confirm
          this.PUT_apiPOSTadvertisement()
        })
        .catch(() => {
          //on cancle
          console.log('payment confirm cancle ')
        })
    },

    toastDialog(info) {
      Dialog.alert({
        title:
          '*The following content is a required option, please fill it out completely',
        message: info,
        confirmButtonText: 'ok',
      }).then(() => {
        //on confirm
      })
    },

    goBack() {
      this.$router.push({ path: '/myAD' })
    },

    goBackPreStep() {
      console.log('excuteEventListener')
      // if (this.stepOneAndTwo) {
      //   this.$router.go(-1);
      // } else if (this.stepThree) {
      //   this.stepThree = false;
      //   this.stepOneAndTwo = true;
      // } else if (this.stepFour) {
      //   this.stepFour = false;
      //   this.stepThree = true;
      // }
    },
  },
}
</script>

<style lang="scss" scoped>
.page {
  background: #ebebeb;
  padding-bottom: 240px;
}
.content {
  padding: 0 24px;
  margin-bottom: 120px;
}
.step-box {
  margin: 20px 0;
  background: #ffffff;
  padding: 27px 40px 34px;
  .step-title {
    font-size: 28px;
    font-weight: 400;
    color: #000000;
    text-align: center;
  }
  .step-imgBox {
    margin-top: 39px;
    display: flex;
    align-items: center;
  }
  .step-imgBox-img {
    width: 73px;
    height: 73px;
  }
  .green-line {
    width: 78px;
    height: 0px;
    border: 2px solid #21b66d;
    margin: 0 16px;
  }
  .black-line {
    width: 78px;
    height: 0px;
    margin: 0 16px;
    border: 2px solid #232f3e;
  }
  .step-textBox {
    margin-top: 22px;
    font-size: 28px;
    font-weight: 400;
    color: #000000;
  }
  .step-text1 {
    margin-right: 51px;
  }
  .step-text2 {
    margin-right: 91px;
  }
  .step-text3 {
    margin-right: 88px;
  }
}
.category-box {
  padding: 30px 40px 50px;
  background: #fff;
  .category-header {
    display: flex;
    align-items: center;
  }
  .category-box-img {
    width: 73px;
    height: 73px;
  }
  .category-header-title {
    margin-left: 24px;
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .choose-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 23px;
  }
  .category-item {
    margin-bottom: 20px;
    padding: 24px 0 24px 35px;
    font-size: 24px;
    font-weight: bold;
    background: #f3f3f3;
    color: #000000;
  }
  .activeCategoryBg {
    background: #273458;
    color: #fff;
  }
}
.location-box {
  padding: 30px 40px 50px;
  margin-top: 20px;
  background: #fff;
  .location-header {
    display: flex;
    align-items: center;
  }
  .location-box-img {
    width: 73px;
    height: 73px;
  }
  .location-header-title {
    margin-left: 24px;
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .location-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 23px;
  }
  .confirm-btn {
    height: 90px;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    margin: 45px auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 408px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
  .showRight-box {
    position: relative;
    margin: 20px 0;
    padding: 10px;
    .area-flex-box {
      height: 80px;
      background: #ffffff;
      border: 1px solid rgba(112, 112, 112, 0.34);
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px;
    }
    .area-box-lf {
      font-size: 28px;
      font-weight: 400;
      color: #242424;
      margin-left: 10px;
    }
    .area-box-rg {
      img {
        width: 0.64rem;
        height: 0.64rem;
      }
    }
  }
}
.publish-box {
  .publish-info {
    padding: 30px 40px;
    background: #fff;
  }
  .publish-info-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .info-header-lf {
    width: 72px;
    height: 73px;
    background: #273458;
    border-radius: 50%;
    font-size: 35px;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 24px;
  }
  .info-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .publish-info-text {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
  }
  .upgrade-days {
    margin-top: 20px;
    padding: 28px 40px 16px;
    background: #fff;
  }
  .upgrade-days-header {
    display: flex;
    align-items: center;
    margin-bottom: 47px;
  }
  .days-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .days-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .days-menu {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
  }
  .days-item {
    width: 33.3%;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  .days-text {
    height: 50px;
    border: 1px solid #bab2b2;
    background: #fff;
    font-size: 24px;
    font-weight: bold;
    color: #1f1a17;
    padding: 9px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 14px;
  }
  .activeDaysBg {
    border: 1px solid #273458;
    background: #273458;
    color: #fff;
  }
  .last-item {
    flex: 1;
  }
  .total-box {
    margin: 20px 0;
    display: flex;
    justify-content: flex-end;
  }
  .total-box-text {
    background: #273458;
    color: #fff;
    font-size: 24px;
    font-weight: bold;
    padding: 10px 20px;
    min-width: 140px;
    text-align: center;
  }
  .my-ads-box {
    margin: 20px 0;
    padding: 24px 40px 40px;
    background: #fff;
  }
  .my-ads-header {
    display: flex;
    align-items: center;
    margin-bottom: 40px;
  }
  .my-ads-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .my-ads-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }

  .table-box {
    margin-bottom: 57px;
  }
  .my-table {
    border-collapse: collapse;
    width: 100%;
  }
  .my-table td {
    text-align: center;
    vertical-align: middle;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
  }
  .col1 {
    width: 35%;
  }
  .col2 {
    width: 45%;
  }
  .col3 {
    width: 20%;
  }
  .col1,
  .col2,
  .col3 {
    height: 70px;
    border: 1px solid #707070;
  }
  .fee-text {
    font-size: 34px;
    font-weight: 400;
    color: #000000;
    text-align: center;
    margin-bottom: 55px;
  }
  .fee-num {
    font-size: 34px;
    font-weight: 800;
    color: #000000;
  }
  .sure-btn {
    margin: 0 auto 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    width: 408px;
    height: 90px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
// 弹窗
.questionPopup-box {
  width: 567px;
  background: #ffffff;
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}

// 普通店铺详情
.normal-box {
  .normal-city-iptBox {
    background: #fff;
    padding: 40px;
  }
  .city-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin-bottom: 55px;
  }
  .city-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .city-three-img {
    width: 73px;
    height: 73px;
    margin-right: 25px;
  }
  .header-rg-p1 {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .header-rg-p2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .city-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 20px;
  }
  .city-ipt {
    height: 80px;
    align-items: center;

    border: 1px solid #e2e2e2;
  }
  :deep(.van-field__control) {
    font-size: 28px;
  }
  .city-detail-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 20px;
  }
  .ipt-flexBox {
    // display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .flexBox-lf {
    width: 50%;
    margin-right: 8px;
  }
  .flexBox-lf1 {
    height: 80px;
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    margin-top: 30px;
  }
  .flexBox-rg {
    width: 50%;
    margin-left: 8px;
  }
  .num-info {
    margin: 30px 0 20px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
}
.normal-person-iptBox1 {
  background: #fff;
  // margin-top: 20px;
}
.normal-person-iptBox {
  background: #fff;
  margin-top: 20px;
  padding: 40px;
  .ipt-flexBox {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 30px;
  }
  .flexBox-lf {
    width: 50%;
    margin-right: 8px;
  }
  .flexBox-rg {
    width: 50%;
    margin-left: 8px;
  }
  .ipt-title {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 10px;
  }
  .lang-box {
    position: relative;
    .area-flex-box {
      height: 80px;
      background: #ffffff;
      border: 1px solid rgba(112, 112, 112, 0.34);
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .area-box-lf {
      font-size: 28px;
      font-weight: 400;
      color: #242424;
      margin-left: 10px;
    }
    .bottom-icon-bl-img {
      width: 48px;
      height: 48px;
    }
    .location-select-box {
      position: absolute;
      z-index: 10;
      background: #eeeeee;
      padding: 20px;
      left: 0;
      right: 0;
      border: 1px solid #d4d4d4;
      border-width: medium;
    }
    .location-ipt {
      height: 81px;
      align-items: center;
    }
    :deep(.van-field__control) {
      font-size: 28px;
    }
    .location-list {
      margin-bottom: 40px;
    }
    .location-list-title {
      font-size: 30px;
      font-weight: bold;
      color: #000000;
    }
    .state-cell {
      box-sizing: border-box;
      padding: 26px 20px;
      overflow: hidden;
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      line-height: 25px;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      font-weight: 700;
      background: #eeeeee;
    }
    .state-value {
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      text-align: center;
    }
    .city-cell {
      box-sizing: border-box;
      padding: 26px 0;
      overflow: hidden;
      font-size: 24px;
      font-weight: 400;
      color: #989898;
    }
    .city-value {
      font-size: 24px;
      font-weight: 400;
      color: #989898;
      text-align: center;
    }
  }
  .availability-box {
    margin: 20px 0;
  }
  .available-radio {
    margin-right: 30px;
  }
}
.normal-adType-box {
  margin-top: 20px;
  padding: 30px 20px;
  background: #fff;
  .adType-header {
    display: flex;
  }
  .ad-header-lf {
    margin-right: 20px;
  }
  .ad-header-img {
    width: 220px;
    height: 406px;
  }
  .rg {
    flex: 1;
    position: relative;
  }
  .ad-header-rg-1 {
    font-size: 30px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 15px;
  }
  .ad-header-rg-2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    margin-bottom: 60px;
    color: #000000;
  }
  .ad-header-rg-3 {
    font-size: 26px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }
  .adType-line {
    height: 0px;
    margin: 30px 0;
    opacity: 0.23;
    border: 1px solid #707070;
  }
  .type-upgrade-box {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 40px;
    border: 1px solid #000;
    border-radius: 10px;
    padding: 13px;
  }
  .upgrade-box {
    height: 70px;
    background: #273458;
    width: 449px;
    font-size: 28px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 30px;
  }
  .price-box {
    border: 1px solid #707070;
    height: 70px;
    display: flex;
    align-items: center;
  }
  .price-box-1 {
    width: 26%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .price-box-2 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #707070;
    height: 70px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    border-right: 1px solid #707070;
  }
  .price-box-3 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .price-box-two {
    border-top: none;
  }
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.normal-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.big-line {
  height: 0px;
  opacity: 1;
  border: 1px solid #707070;
  margin: 50px 0;
}

.goBack-box {
  display: flex;
  align-items: center;
  font-size: 24px;
  font-family: PingFang SC-Regular, PingFang SC;
  font-weight: 400;
  color: #000000;
  .goDown-go {
    width: 50%;
    margin-right: 12px;
    justify-content: center;
    display: flex;
    align-items: center;
    height: 80px;
    background: #ffffff;
    border: 1px solid #273458;
  }
}
.goDown-back {
  width: 100%;
  height: 90px;
  margin-top: 24px;
  display: flex;
  align-items: center;
  height: 80px;
  justify-content: center;
  background: #ffffff;
  border: 1px solid #273458;
}
.Review-btn {
  margin: 24px 0;
  width: 50%;
  height: 90px;
  background: #273458;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-family: PingFang SC-Bold, PingFang SC;
  font-weight: bold;
  color: #ffffff;
  box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
}

// 商铺详情
.shop-box {
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  .shop-city-iptBox {
    background: #fff;
    padding: 40px;
  }
  .city-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin-bottom: 55px;
  }
  .city-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .city-three-img {
    width: 73px;
    height: 73px;
    margin-right: 25px;
  }
  .header-rg-p1 {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .header-rg-p2 {
    font-size: 20px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #989898;
    margin-left: 70px;
  }
  .city-title {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 20px;
  }
  .city-ipt {
    height: 80px;
    align-items: center;
    border: 1px solid #e2e2e2;
  }
  :deep(.van-field__control) {
    font-size: 28px;
  }
  .city-detail-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 20px;
  }
  .ipt-flexBox {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .flexBox-lf {
    width: 50%;
    margin-right: 8px;
  }
  .flexBox-rg {
    width: 50%;
    margin-left: 8px;
  }
  .num-info {
    margin: 30px 0 20px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
}
.shop-person-iptBox {
  background: #fff;
  margin-top: 20px;
  padding: 40px;
  .checkedOut-box {
    display: flex;
    align-items: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 30px;
  }
  .checkedOut-lf {
    width: 60%;
  }
  .checkedOut-rg {
    text-align: right;
  }
  .charging-box {
    display: flex;
    align-items: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 20px;
  }
  .charging-box-lf {
    width: 40%;
  }
  .charging-box-rg {
    border: 1px solid #e2e2e2;
  }
  .charging-ipt {
    align-items: center;
    height: 70px;
    background: #ffffff;
  }
}
.shop-adType-box {
  margin-top: 20px;
  padding: 30px 20px;
  background: #fff;
  .adType-header {
    display: flex;
  }
  .ad-header-lf {
    margin-right: 20px;
  }
  .ad-header-img {
    width: 220px;
    height: 406px;
  }
  .rg {
    flex: 1;
    position: relative;
  }
  .ad-header-rg-1 {
    font-size: 30px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 15px;
  }
  .ad-header-rg-2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    margin-bottom: 60px;
    color: #000000;
  }
  .ad-header-rg-3 {
    font-size: 26px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }
  .adType-line {
    height: 0px;
    margin: 30px 0;
    opacity: 0.23;
    border: 1px solid #707070;
  }
  .type-upgrade-box {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 40px;
    border: 1px solid #000;
    border-radius: 10px;
    padding: 13px;
  }
  .upgrade-box {
    height: 70px;
    background: #273458;
    width: 449px;
    font-size: 28px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 30px;
  }
  .price-box {
    border: 1px solid #707070;
    height: 70px;
    display: flex;
    align-items: center;
  }
  .price-box-1 {
    width: 26%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .price-box-2 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #707070;
    height: 70px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    border-right: 1px solid #707070;
  }
  .price-box-3 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .price-box-two {
    border-top: none;
  }
}
.shop-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
}
// vip
.vip-box {
  .upload-item-box-vip-one {
    position: relative;
    width: 100%;
    height: 964px;
    margin-bottom: 20px;
    overflow: hidden;
    background: #ffffff;
    border: 1px solid #707070;
    display: flex;
    justify-content: center;
    align-items: center;
    .uploader-box {
      width: 250px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      .upload-icon-text {
        margin-top: 10px;
        width: 250px;
        height: 80px;
        font-size: 28px;
        font-family: PingFang SC-Regular, PingFang SC;
        font-weight: 400;
        color: #888888;
        text-align: center;
      }
    }
  }
  .upload-item-box-vip-one-702 {
    width: 100%;
    height: 702px;
  }
  .upload-item-box-vip-one-501 {
    width: 100%;
    height: 501px;
  }
  .upload-item-box-vip-one-702 {
    width: 100%;
    height: 702px;
  }
  .upload-item-box-vip-two {
    width: 100%;
    height: 501px;
    margin-bottom: 20px;
    overflow: hidden;
    // background: #ffffff;
    // border: 1px solid #707070;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .upload-item-box-vip-two-item {
      width: 49%;
      height: 100%;
      box-sizing: border-box;
      background: #ffffff;
      border: 1px solid #707070;
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
    }
    .uploader-box {
      width: 250px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      .upload-icon-text {
        margin-top: 10px;
        width: 250px;
        height: 80px;
        font-size: 28px;
        font-family: PingFang SC-Regular, PingFang SC;
        font-weight: 400;
        color: #888888;
        text-align: center;
      }
    }
  }
  .paragraph {
    width: 100%;
    .paragraph-title {
      width: 100%;
      height: 115px;
      line-height: 115px;
      padding-left: 63px;
      box-sizing: border-box;
      background: #ffffff;
      font-size: 28px;
      font-family: PingFang SC-Regular, PingFang SC;
      font-weight: 400;
      color: #989898;
    }
    .paragraph-title-text {
      .van-cell {
        font-size: 40px;
        font-family: Didot HTF-M06-Medium, Didot HTF-M06;
        font-weight: 500;
        color: #989898;
        padding-left: 65px;
        border: 0px;
        background: #f8f8f8;
      }
    }
    .paragraph-title-text-w {
      .van-cell {
        font-size: 40px;
        font-family: Didot HTF-M06-Medium, Didot HTF-M06;
        font-weight: 500;
        color: #989898;
        padding-left: 65px;
        border: 0px;
        background: #fff;
      }
    }
    .paragraph-context {
      background: #f8f8f8;
    }
  }
  .vip-input-box {
    width: 100%;
    height: 70px;
    margin: 15px 0;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    .vip-input-box-title {
      width: 30%;
      height: 100%;
      background: #273458;
      font-size: 26px;
      font-family: PingFang SC-Medium, PingFang SC;
      font-weight: 500;
      line-height: 70px;
      color: #ffffff;
      text-align: center;
    }
    .vip-input-box-input {
      background: #f3f3f3;
      width: 70%;
      height: 70px;
      .van-cell {
        width: 100%;
        height: 100%;
        background: #f3f3f3;
      }
    }
    .lang-box {
      width: 100%;
      height: 100%;
      position: relative;
      .area-flex-box {
        width: 100%;
        height: 100%;
        // border: 1px solid rgba(112, 112, 112, 0.34);
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .area-box-lf {
        font-size: 28px;
        font-weight: 400;
        color: #242424;
        margin-left: 10px;
      }
      .bottom-icon-bl-img {
        width: 48px;
        height: 48px;
      }
      .location-select-box {
        position: absolute;
        z-index: 1;
        background: #eeeeee;
        padding: 20px;
        left: 0;
        right: 0;
        border: 1px solid #d4d4d4;
        border-width: medium;
      }
      .location-ipt {
        height: 81px;
        align-items: center;
      }
      :deep(.van-field__control) {
        font-size: 28px;
      }
      .location-list {
        margin-bottom: 40px;
      }
      .location-list-title {
        font-size: 30px;
        font-weight: bold;
        color: #000000;
      }
      .state-cell {
        box-sizing: border-box;
        padding: 26px 0;
        overflow: hidden;
        font-size: 28px;
        font-weight: 400;
        background: #eeeeee;
        color: #000000;
        line-height: 25px;
      }
      .state-value {
        font-size: 28px;
        font-weight: 400;
        color: #000000;
        text-align: center;
      }
      .city-cell {
        box-sizing: border-box;
        padding: 26px 0;
        overflow: hidden;
        font-size: 24px;
        font-weight: 400;
        color: #989898;
      }
      .city-value {
        font-size: 24px;
        font-weight: 400;
        color: #989898;
        text-align: center;
      }
    }
  }
}
.uploader-img img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.van-cell_value--alone {
  font-size: 32px;
  height: 50px;
  line-height: 50px;
}
:deep(.van-uploader) {
  width: 100%;
  height: 100%;
}
:deep(.van-uploader__wrapper) {
  width: 100%;
  height: 100%;
}
:deep(.van-uploader__input-wrapper) {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.uploader-img {
  width: 100%;
  height: 100%;
}
.close-img {
  width: 37px;
  height: 37px;
}
.van-cell__title {
  line-height: inherit !important;
  text-align: left;
  margin-left: 10px;
  font-weight: 800;
}
.van-cell {
  line-height: 33px !important;
  font-weight: 800;
}

.popup_info {
  padding: 10px;
  width: 300px;
  background: #eeeeee;
  background: #eeeeee;
}

.delImg {
  position: absolute;
  left: 80%;
  width: 20%;
  font-size: large;
  z-index: 2;
}

.delImg-vip {
  position: absolute;
  left: 85%;
  width: 15%;
  font-size: xx-large;
  z-index: 2;
  text-align: center;
}

.isConfirmStreetInfo {
  position: relative;
  right: 10%;
  font-size: large;
  font-weight: 700;
}
.upgradeIsCheck {
  position: relative;
  top: 10px;
  left: 50px;
  font-size: x-large;
  font-weight: 900;
}
</style>
<style scoped>
:deep(.van-field__label) {
  width: auto !important;
  font-size: large;
  margin-right: 0px;
  color: black;
}

:deep(.van-dialog__message) {
  font-size: large;
  font-weight: 600;
}
</style>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}

video {
  width: 100%;
  position: relative;
  height: auto;
  z-index: 2;
}

:deep(.van-loading) {
  position: absolute;
  width: 100%;
  height: 100%;
  background: white;
  z-index: 1;
  line-height: 204px;
  display: none;
  text-align: center;
}
</style>
