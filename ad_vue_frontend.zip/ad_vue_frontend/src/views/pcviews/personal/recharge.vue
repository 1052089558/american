<template>
  <div class="page">
    <div class="header">
      <van-nav-bar title="Recharge" left-arrow @click-left="onClickLeft" />
    </div>
    <div v-if="status == 0">
      <div class="balance-box">
        余额$：<span class="balance-num">$ {{rechargeMoney}}</span>
      </div>
      <div class="recharge-box">
        <div class="recharge-flex-box">
          <div
            class="recharge-item"
            :class="{ activeRechargeBg: checked == index }"
            v-for="(item, index) in moneyData"
            :key="index"
            @click="checkedMoney(item, index)"
          >
            <div class="recharge-money">$ {{item.money}}</div>
            <!-- <div class="recharge-btc">BTC：0.2335458</div> -->
          </div>
        </div>
        <div>
          <van-field
            class="money-inp"
            v-model="money" readonly
            placeholder="Enter the recharge amount"
          />
        </div>
        <div class="info-text">
          Recharge the equivalent value of cryptocurrency
        </div>
        <div class="confirm-btn-box">
          <van-button class="confirm-btn" @click="status = 1"
            >Confirm recharge</van-button
          >
        </div>
      </div>
    </div>
    <div v-if="status == 1">
      <div class="pay-box">
        <div class="account">
          BTC数量：<span class="balance-num">2654</span>
        </div>
        <div class="code-box">
          <img
            class="code-img"
            src="../../assets/images/personal/code-img.jpg"
            alt=""
          />
          <div class="code-text">Scan QR code</div>
        </div>
        <div class="address-box">
          <div class="address-box-lf">https://www.baidu.com/s?tn</div>
          <div class="address-box-rg">copy address</div>
        </div>
        <div class="confirm-btn-box">
          <van-button class="confirm-btn">payment completed</van-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { apiGetInfo }  from '../../request/api'
export default {
  name: "recharge",
  components: {},
  data() {
    return {
      rechargeMoney:"",
      moneyData:[
        {money:20},
        {money:30},
        {money:50},
        {money:100},
        {money:200},
        {money:500}
      ],
      checked: 0,
      money: "",
      status: 0,
    };
  },
  created() {
    apiGetInfo().then((res) => {
      if (res.code == 200) {
        this.rechargeMoney = res.data.balance
      }
    })

  },
  mounted() {},
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    checkedMoney(item, index) {
      this.checked = index;
      this.money=item.money
    },

  },
};
</script>

<style lang="scss" scoped>
.balance-box {
  padding: 0 32px;
  margin: 30px 0;
  font-size: 34px;
  font-weight: 400;
  color: #1f1a17;
  display: flex;
  align-items: center;
  .balance-num {
    font-size: 50px;
    font-weight: 800;
    color: #000000;
  }
}
.recharge-box {
  padding: 10px 32px;
  .recharge-flex-box {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    .recharge-item {
      width: calc(50% - 9px);
      height: 116px;
      border: 1px solid rgba(39, 52, 88, 0.27);
      background: #ffffff;
      margin-bottom: 18px;
      padding: 15px 20px;
      box-sizing: border-box;
    }
    .recharge-money {
      font-size: 29px;
      font-weight: bold;
      color: #1f1a17;
      margin-bottom: 10px;
    }
    .recharge-btc {
      font-size: 25px;
      font-weight: 400;
      color: #1f1a17;
    }
    .activeRechargeBg {
      background: #273458;
      .recharge-money {
        color: #f3f3f3;
      }
      .recharge-btc {
        color: #f3f3f3;
      }
    }
  }
  .money-inp {
    height: 90px;
    margin: 65px 0 0;
    background: #ffffff;
    border: 1px solid #273458;
    align-items: center;
  }
  .info-text {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    text-align: center;
    margin: 10px 0 136px;
  }
  :deep(.van-field__control) {
    font-size: 28px;
  }
  :deep(.van-field__control::placeholder) {
    text-align: center;
  }
  .confirm-btn-box {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin-bottom: 50px;
    height: 90px;
    width: 408px;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
.pay-box {
  padding: 0 32px;
  .account {
    margin: 30px 0 80px;
    font-size: 34px;
    font-weight: 400;
    color: #1f1a17;
    display: flex;
    align-items: center;
    .balance-num {
      font-size: 50px;
      font-weight: 800;
      color: #000000;
    }
  }
  .code-box {
    text-align: center;
    margin: 0 auto;
  }
  .code-img {
    width: 300px;
    height: 300px;
    margin-bottom: 20px;
  }
  .code-text {
    font-size: 28px;
    font-weight: bold;
    margin-bottom: 100px;
    color: #000000;
  }
  .address-box {
    display: flex;
    margin-bottom: 130px;
    align-items: center;
  }
  .address-box-lf {
    padding: 10px 20px;
    font-size: 24px;
    font-weight: 400;
    background: #ffffff;
    border: 1px solid #e2e2e2;
    color: #989898;
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    height: 90px;
    text-overflow: ellipsis;
    box-sizing: border-box;
    display: flex;
    align-items: center;
  }
  .address-box-rg {
    font-size: 26px;
    background: #273458;
    width: 233px;
    font-weight: 400;
    padding: 10px 20px;
    color: #f3f3f3;
    text-align: center;
    box-sizing: border-box;
    height: 90px;
    border: 1px solid #273458;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn-box {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin-bottom: 50px;
    height: 90px;
    width: 408px;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
</style>
