<template>
  <div class="page">
    <div class="header">
      <div class="header-title">Upgrade</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>
    
    <div class="normal-adType-box">
    <div class="type-upgrade-box">
      <div class="upgrade-box"  @click="showRecommendSection = !showRecommendSection">Upgrade to Recommended ad</div>
          <van-checkbox
            v-model="showRecommendSection"
            icon-size="20px"
            checked-color="#273458"
          ></van-checkbox>
      </div>

      <div class="type-upgrade-box">
        <div class="upgrade-box" @click="showTopSection = !showTopSection">Upgrade to Top ad</div>
          <van-checkbox
            icon-size="20px"
            v-model="showTopSection"
            checked-color="#273458"
          ></van-checkbox>
      </div>
    </div>


    <div class="normal-adType-box" :style="{'display':(showRecommendSection==true?'':'none')}">
      <div class="rec-box" v-if="true">
        <div class="adType-header">
          <div class="ad-header-lf">
            <img
              class="ad-header-img"
              src="../../assets/images/home/recommend-img1.png"
              alt=""
            />
          </div>
          <div class="ad-header-rg">
            <div class="ad-header-rg-1">Recommended ad</div>
            <div class="ad-header-rg-2">
              Your ad will be on the homepage of the your area.All viewers
              will see it first. Highly recommended.
            </div>
          </div>
        </div>
        <div class="adType-line"></div>

        <div v-if="true">
          <div class="upload-title">Advertising cover image</div>
          <div class="upload-img-box">
            <div class="upload-container">
              <div class="upload-item-box">
                <CUT
                  :size_w="176"
                  :size_h="236"
                  :name="'recommendImageOne'"
                  @UpUrl="UpUrl"
                ></CUT>
                <div class="uploader-box" v-if="recommendImageOne == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">
                    Click to upload pictures
                  </div>
                </div>
                <div class="uploader-img" v-else>
                  <img :src="recommendImageOne" alt="" />
                </div>
              </div>
              <div class="upload-item-box">
                <CUT
                  :size_w="153"
                  :size_h="112"
                  :name="'recommendImageTwo'"
                  @UpUrl="UpUrl"
                ></CUT>
                <div class="uploader-box" v-if="recommendImageTwo == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">
                    Click to upload pictures
                  </div>
                </div>
                <div class="uploader-img" v-else>
                  <img :src="recommendImageTwo" alt="" />
                </div>
              </div>
              <div class="upload-item-box">
                <CUT
                  :size_w="153"
                  :size_h="112"
                  :name="'recommendImageThree'"
                  @UpUrl="UpUrl"
                ></CUT>
                <div
                  class="uploader-box"
                  v-if="recommendImageThree == ''"
                >
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">
                    Click to upload pictures
                  </div>
                </div>
                <div class="uploader-img" v-else>
                  <img :src="recommendImageThree" alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="upgrade-days" :style="{'display':(showRecommendSection==true?'':'none')}">
      <div class="upgrade-days-header">          
        <div class="days-header-rg">Recommended AD time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="recommendchecked1 = !recommendchecked1" style="width: 50%;">
          <div class="days-text" >
            5days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked2 = !recommendchecked2" style="width: 50%;">
          <div class="days-text" >
            10days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked3 = !recommendchecked3" style="width: 50%;">
          <div class="days-text" >
            20days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked4 = !recommendchecked4" style="width: 50%;">
          <div class="days-text" >
            30days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item last-item" @click="recommendchecked5 = !recommendchecked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div> 
        
        <div class="big-line"></div>

        <div class="total-box">
                <div class="total-box-text">
                  Recommended AD {{ totol_days_recommend }}Days Total $ {{ totol_days_recommend * maney}}
                </div>
        </div>
        
      </div>
    </div>


    <div class="normal-adType-box" :style="{'display':(showTopSection==true?'':'none')}">
      <div class="rec-box" v-if="true">
        <div class="adType-header">
          <div class="ad-header-lf">
            <img
              class="ad-header-img"
              src="../../assets/images/home/recommend-img1.png"
              alt=""
            />
          </div>
          <div class="ad-header-rg">
            <div class="ad-header-rg-1">Top ad</div>
            <div class="ad-header-rg-2">
              Your ad will be on the top of other normal ads,and 4 times
              bigger than normal ad.It's easy to get viewer's attention.
            </div>
            <div v-if="false" class="ad-header-rg-3">
              ${{ maney }} per day
            </div>
          </div>
        </div>
        <div class="adType-line"></div>
        
        <div >
          <div class="upload-title">Advertising cover image</div>
          <div class="upload-img-box">
            <div class="upload-container" style="display: flex;justify-content: center;align-items: center;">
              <div class="upload-item-box">
                <CUT
                  :size_w="337"
                  :size_h="266"
                  :name="'largeImage'"
                  @UpUrl="UpUrl"
                ></CUT>
                <div class="uploader-box" v-if="largeImage == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">
                    Click to upload pictures
                  </div>
                </div>
                <div class="uploader-img" v-else>
                  <img :src="largeImage" alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>  
    
    <div class="upgrade-days" :style="{'display':(showTopSection==true?'':'none')}">
      <div class="upgrade-days-header">          
        <div class="days-header-rg">Buy ads display time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="topchecked1 = !topchecked1" style="width: 50%;">
          <div class="days-text" >
            5days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked2 = !topchecked2" style="width: 50%;">
          <div class="days-text" >
            10days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked3 = !topchecked3" style="width: 50%;">
          <div class="days-text" >
            20days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked4 = !topchecked4" style="width: 50%;">
          <div class="days-text" >
            30days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item last-item" @click="topchecked5 = !topchecked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="big-line"></div>

        <div class="total-box">
                <div class="total-box-text">
                  Top AD {{ totol_days_top }}Days Total $ {{ totol_days_top * maney }}
                </div>
        </div>
      </div>
    </div>


    <div class="fee-text">
      Total：$ <span class="fee-num">{{ totol_days * maney}}</span>
    </div>
    <div class="sure-btn" @click="showconfirm" :class="{ none: !paymentisable }">
      payment 
    </div>

  </div>
</template>

<script>
import {
  getCityDetails,
} from '../../request/api'
import { Toast } from 'vant'
// 富文本
import Editor from '@tinymce/tinymce-vue'
import CUT from '../postAd/Cut.vue'
import { Dialog } from 'vant'
export default {
  name: 'upgrade',
  components: { 'tinymce-editor': Editor, CUT },
  data() {
    return {
      maney:0,
      type:[2,3],
      advertisementId:0,      
      largeImage: '',
      recommendImageOne: '',
      recommendImageTwo: '',
      recommendImageThree: '',
      city_list_select_ad: [], 
      showRecommendSection:true,
      showTopSection:true,
      dept_list_select_totol_days:0,
      cityid:0,
      recommendchecked1: false,
      recommendchecked2: false,
      recommendchecked3: false,
      recommendchecked4: false,
      recommendchecked5: false, 
      topchecked1: false,
      topchecked2: false,
      topchecked3: false,
      topchecked4: false,
      topchecked5: false, 
      autorenewaltop:0,
      autorenewalrecommend:0,
      totol_days:0,
      totol_days_normal:0,
      totol_days_top:0,
      totol_days_recommend:0,
      paymentisable:false,
    }
  },
  created() {
// 获取主页给来的路由参数
console.log('主页给来的路由参数', this.$route.query)
    let category = this.$route.query.category
    let maney = this.$route.query.maney
    // let type = this.$route.query.type
    let city = this.$route.query.city
    let advertisementId = this.$route.query.advertisementId // 实际
    this.advertisementId = Number(advertisementId)
    this.maney = Number(maney)
    this.cityid=Number(city)
    // this.type=String(type).split(",")
    console.log('this.advertisementId' + advertisementId)
    // let advertisementId = 1;
    if (category == '5' || category == '8') {
      this.homepageDetail = false
      this.storeDetail = true
    }    

    getCityDetails({
        cityId: this.cityid,
      }).then((res) => {
        if (res.code == 200) {
          this.city_list_select_ad.push(res.data)
        }
      });
    
  },
  mounted() {    
  },
  watch: {   
    showTopSection(e){
      if(e){
        this.showTopSection=true
      }else{
        if(this.showRecommendSection==false){
          this.$toast.fail("至少选择一项");
          this.showTopSection=true
        }
      }
    },
    showRecommendSection(e){
      if(e){
        this.showRecommendSection=true
      }else{
        if(this.showTopSection==false){
          this.$toast.fail("至少选择一项");
          this.showRecommendSection=true
        }
      }
    },
    totol_days(e){
      if(e){
        this.paymentisable=true
        this.totolfee=this.totol_days*this.maney
      }else{
        this.paymentisable=false
        this.totolfee=this.totol_days*this.maney
      }
    }, 
    topchecked1(e) {
      if (e) {
        this.totol_days_top=5
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked2(e) {
      if (e) {
        this.totol_days_top=10
        this.topchecked1 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked3(e) {
      if (e) {
        this.totol_days_top=20
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked4(e) {
      if (e) {
        this.totol_days_top=30
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked5(e) {
      if (e) {
        this.autorenewaltop=1
        this.totol_days_top=1
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.autorenewaltop=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked1(e) {
      if (e) {
        this.totol_days_recommend=5
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked2(e) {
      if (e) {
        this.totol_days_recommend=10
        this.recommendchecked1 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked3(e) {
      if (e) {
        this.totol_days_recommend=20
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked4(e) {
      if (e) {
        this.totol_days_recommend=30
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked5(e) {
      if (e) {
        this.autorenewalrecommend=1
        this.totol_days_recommend=1
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.autorenewalrecommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
  },
  methods: {
    showconfirm(){
      Dialog.confirm({
        title:"confirm payment",
        message:"$"+(this.totol_days*this.maney)
      }).then(()=>{
        //on confirm
        console.log("payment confirm ")    
        apiBuyAdTime({
          totolfee:this.totolfee,
          advertisementId:this.advertisementId,
          autorenewalnormal:this.autorenewalnormal,
          autorenewaltop:this.autorenewaltop,
          autorenewalrecommend:this.autorenewalrecommend,
          totol_days_normal:this.totol_days_normal,
          totol_days_top:this.totol_days_top,
          totol_days_recommend:this.totol_days_recommend
        }).then((res)=>{
          if(res.code==200){
            this.$toast.success({
              duration:2000,
              message:res.data.message,
              type:'success'
            });            
          }else{
            this.$toast.success("购买失败，请联系管理员！");            
          }
        }) 
      }).catch(()=>{
        //on cancle
        console.log("payment confirm cancle ")
      });
    },
    goBack() {
      this.$router.go(-1)
    },    
    UpUrl(data) {
      console.log(data)
      if (data.name == 'recommendImageOne') {
        this.recommendImageOne = data.url
      } else if (data.name == 'recommendImageTwo') {
        this.recommendImageTwo = data.url
      } else if (data.name == 'recommendImageThree') {
        this.recommendImageThree = data.url
      } else if (data.name == 'largeImage') {
        this.largeImage = data.url
      } else if (data.name == 'images_one') {
        this.images_one = data.url
      }
    },
  }
}
</script>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}

.normal-adType-box {
  margin-top: 20px;
  padding: 30px 20px;
  background: #fff;
  .adType-header {
    display: flex;
  }
  .ad-header-lf {
    margin-right: 20px;
  }
  .ad-header-img {
    width: 280px;
    height: 280px;
  }
  .rg {
    flex: 1;
    position: relative;
  }
  .ad-header-rg-1 {
    font-size: 30px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 15px;
  }
  .ad-header-rg-2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    margin-bottom: 60px;
    color: #000000;
  }
  .ad-header-rg-3 {
    font-size: 26px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }
  .adType-line {
    height: 0px;
    margin: 30px 0;
    opacity: 0.23;
    border: 1px solid #707070;
  }
  .type-upgrade-box {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 40px;
  }
  .upgrade-box {
    height: 70px;
    background: #273458;
    width: 90%;
    font-size: 28px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 30px;
  }
  .price-box {
    border: 1px solid #707070;
    height: 70px;
    display: flex;
    align-items: center;
  }
  .price-box-1 {
    width: 26%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .price-box-2 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #707070;
    height: 70px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    border-right: 1px solid #707070;
  }
  .price-box-3 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .price-box-two {
    border-top: none;
  }
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
    text-align: center;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.normal-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.big-line {
  height: 0px;
  opacity: 1;
  border: 1px solid #707070;
  // margin: 50px 0;
  width: 100%;
}


.upgrade-days {
    margin-top: 20px;
    padding: 28px 40px 16px;
    background: rgb(244, 244, 244);
  }
  .upgrade-days-header {
    display: flex;
    align-items: center;
    margin-bottom: 47px;
  }
  .days-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .days-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
    width: 100%;
    text-align: center;
  }
  .days-menu {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
  }
  .days-item {
    width: 33.3%;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  .days-text {
    height: 50px;
    // border: 1px solid #bab2b2;
    // background: #fff;
    font-size: 24px;
    font-weight: bold;
    color: #1f1a17;
    padding: 9px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 14px;
  }

  .activeDaysBg {
    border: 1px solid #273458;
    background: #273458;
    color: #fff;
  }

  .fee-text {
    font-size: 34px;
    font-weight: 400;
    color: #000000;
    text-align: center;
    margin-bottom: 55px;
    margin-top:20px;
  }
  .fee-num {
    font-size: 34px;
    font-weight: 800;
    color: #000000;
  }
  .sure-btn {
    margin: 0 auto 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    width: 408px;
    height: 90px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }

  .none{
    pointer-events:none;
    background-color: gray;
  }

  .total-box {
    margin: 20px 0;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
  }
  .total-box-text {
    // background: #273458;
    // color: #fff;
    font-size: 24px;
    font-weight: bold;
    padding: 10px 20px;
    min-width: 140px;
    text-align: center;
  }
</style>
