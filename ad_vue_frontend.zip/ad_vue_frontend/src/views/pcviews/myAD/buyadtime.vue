<template>
  <div class="page">
    <div class="header">
      <div class="header-title"></div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>

    <div v-if="((type.indexOf('1')) !== -1 )" class="upgrade-days">
      <div class="upgrade-days-header">
        <div class="days-header-lf"></div>            
        <div class="days-header-rg">Buy ads display time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="checked1 = !checked1" style="width: 50%;">
          <div class="days-text" >
            5days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="checked2 = !checked2" style="width: 50%;">
          <div class="days-text" >
            10days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="checked3 = !checked3" style="width: 50%;">
          <div class="days-text" >
            20days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="checked4 = !checked4" style="width: 50%;">
          <div class="days-text" >
            30days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item last-item" @click="checked5 = !checked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
      </div>
    </div>

    <div v-if="((type.indexOf('3')) !== -1 )" class="upgrade-days">
      <div class="upgrade-days-header">
        <div class="days-header-lf"></div>            
        <div class="days-header-rg">Buy ads display time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="recommendchecked1 = !recommendchecked1" style="width: 50%;">
          <div class="days-text" >
            5days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked2 = !recommendchecked2" style="width: 50%;">
          <div class="days-text" >
            10days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked3 = !recommendchecked3" style="width: 50%;">
          <div class="days-text" >
            20days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked4 = !recommendchecked4" style="width: 50%;">
          <div class="days-text" >
            30days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item last-item" @click="recommendchecked5 = !recommendchecked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
      </div>
    </div>

    <div v-if="((type.indexOf('2')) !== -1 )" class="upgrade-days">
      <div class="upgrade-days-header">
        <div class="days-header-lf"></div>            
        <div class="days-header-rg">Buy ads display time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="topchecked1 = !topchecked1" style="width: 50%;">
          <div class="days-text" >
            5days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked2 = !topchecked2" style="width: 50%;">
          <div class="days-text" >
            10days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked3 = !topchecked3" style="width: 50%;">
          <div class="days-text" >
            20days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked4 = !topchecked4" style="width: 50%;">
          <div class="days-text" >
            30days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item last-item" @click="topchecked5 = !topchecked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
      </div>
    </div>

    <div class="fee-text">
      Total：$ <span class="fee-num">{{ totol_days * maney}}</span>
    </div>
    <div class="sure-btn" @click="showconfirm" :class="{ none: !paymentisable }">
      payment 
    </div>



  </div>    
</template>

<script>
import {
  apiBuyAdTime,
} from '../../request/api'
import Swiper from 'swiper'
import 'swiper/css/swiper.css'
import { Dialog } from 'vant'
export default {
  name: 'buyadtime',
  data() {
    return {
      advertisementId:0,
      maney:10,
      type:[],
      totolfee:0,
      totol_days:0,
      totol_days_normal:0,
      totol_days_top:0,
      totol_days_recommend:0,
      checked1: false,
      checked2: false,
      checked3: false,
      checked4: false,
      checked5: false,  
      recommendchecked1: false,
      recommendchecked2: false,
      recommendchecked3: false,
      recommendchecked4: false,
      recommendchecked5: false, 
      topchecked1: false,
      topchecked2: false,
      topchecked3: false,
      topchecked4: false,
      topchecked5: false,    
      paymentisable:false,
      autorenewalnormal:0,
      autorenewaltop:0,
      autorenewalrecommend:0,
    }
  },
  created() {
    // 获取主页给来的路由参数
    console.log('主页给来的路由参数', this.$route.query)
    let category = this.$route.query.category
    let maney = this.$route.query.maney
    let type = this.$route.query.type
    let advertisementId = this.$route.query.advertisementId // 实际
    this.advertisementId = Number(advertisementId)
    this.maney = Number(maney)
    this.type=String(type).split(",")
    console.log('this.advertisementId' + advertisementId)
    // let advertisementId = 1;
    if (category == '5' || category == '8') {
      this.homepageDetail = false
      this.storeDetail = true
    }    
  },
  mounted() {
    
  },
  watch: {   
    totol_days(e){
      if(e){
        this.paymentisable=true
        this.totolfee=this.totol_days*this.maney
      }else{
        this.paymentisable=false
        this.totolfee=this.totol_days*this.maney
      }
    }, 
    checked1(e) {
      if (e) {        
        this.totol_days_normal=5
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }        
      }
    },
    checked2(e) {
      if (e) {
        this.totol_days_normal=10
        this.checked1 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }    
      }
    },
    checked3(e) {
      if (e) {
        this.totol_days_normal=20
        this.checked1 = false
        this.checked2 = false
        this.checked4 = false
        this.checked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }    
      }
    },
    checked4(e) {
      if (e) {
        this.totol_days_normal=30
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }    
      }
    },
    checked5(e) {
      if (e) {
        this.autorenewalnormal=1
        this.totol_days_normal=1
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.autorenewalnormal=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
        topchecked1(e) {
      if (e) {
        this.totol_days_top=5
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked2(e) {
      if (e) {
        this.totol_days_top=10
        this.topchecked1 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked3(e) {
      if (e) {
        this.totol_days_top=20
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked4(e) {
      if (e) {
        this.totol_days_top=30
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    topchecked5(e) {
      if (e) {
        this.autorenewaltop=1
        this.totol_days_top=1
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.autorenewaltop=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked1(e) {
      if (e) {
        this.totol_days_recommend=5
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked2(e) {
      if (e) {
        this.totol_days_recommend=10
        this.recommendchecked1 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked3(e) {
      if (e) {
        this.totol_days_recommend=20
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked4(e) {
      if (e) {
        this.totol_days_recommend=30
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked5 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
    recommendchecked5(e) {
      if (e) {
        this.autorenewalrecommend=1
        this.totol_days_recommend=1
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
      }else{
        if(
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.autorenewalrecommend=0
          this.totol_days=this.totol_days_normal+this.totol_days_top+this.totol_days_recommend
        }
      }
    },
  },
  methods: {
    goBack() {
      this.$router.go(-1)
      //window.open('http://app.abcd69.com/', '_self')
    },
    showconfirm(){
      Dialog.confirm({
        title:"confirm payment",
        message:"$"+(this.totol_days*this.maney)
      }).then(()=>{
        //on confirm
        console.log("payment confirm ")    
        apiBuyAdTime({
          totolfee:this.totolfee,
          advertisementId:this.advertisementId,
          autorenewalnormal:this.autorenewalnormal,
          autorenewaltop:this.autorenewaltop,
          autorenewalrecommend:this.autorenewalrecommend,
          totol_days_normal:this.totol_days_normal,
          totol_days_top:this.totol_days_top,
          totol_days_recommend:this.totol_days_recommend
        }).then((res)=>{
          if(res.code==200){
            this.$toast.success({
              duration:2000,
              message:res.data.message,
              type:'success'
            });            
          }else{
            this.$toast.success("购买失败，请联系管理员！");            
          }
        }) 
      }).catch(()=>{
        //on cancle
        console.log("payment confirm cancle ")
      });
    }
    
  },
}
</script>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}
// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
.msg-box {
  position: fixed;
  right: 30px;
  bottom: 30%;
  z-index: 2;

  .msg-img {
    width: 81px;
    height: 81px;
    position: relative;
  }
  .msg-pop {
    position: absolute;
    top: -700px;
    right: 30px;
    width: 645px;
    height: 694px;
    border-radius: 40px;
    background-color: #f7f7f7;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  }
  .msg-contentBox {
    position: relative;
  }
  .contentBox-header {
    font-size: 29px;
    font-weight: bold;
    color: #000000;
    height: 94px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #fff;
    border-radius: 40px 40px 0 0;
  }
  .close-icon {
    position: absolute;
    width: 26px;
    height: 26px;
    right: 40px;
  }
  .msg-body {
    background: #f7f7f7;
    padding: 20px 20px;
  }
  .avatar-img {
    width: 92px;
    height: 92px;
  }
  .msg-text {
    background: #000;
    width: 446px;
    background: #ffffff;
    box-shadow: 0px 3px 6px 1px rgba(0, 0, 0, 0.16);
    border-radius: 20px 20px 20px 20px;
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    left: 100px;
    top: 200px;
    padding: 24px;
  }
}
.swiper-img-box {
  height: 902px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
}


.upgrade-days {
    margin-top: 20px;
    padding: 28px 40px 16px;
    background: rgb(244, 244, 244);
  }
  .upgrade-days-header {
    display: flex;
    align-items: center;
    margin-bottom: 47px;
  }
  .days-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .days-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .days-menu {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
  }
  .days-item {
    width: 33.3%;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  .days-text {
    height: 50px;
    // border: 1px solid #bab2b2;
    // background: #fff;
    font-size: 24px;
    font-weight: bold;
    color: #1f1a17;
    padding: 9px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 14px;
  }

  .activeDaysBg {
    border: 1px solid #273458;
    background: #273458;
    color: #fff;
  }

  .fee-text {
    font-size: 34px;
    font-weight: 400;
    color: #000000;
    text-align: center;
    margin-bottom: 55px;
    margin-top:20px;
  }
  .fee-num {
    font-size: 34px;
    font-weight: 800;
    color: #000000;
  }
  .sure-btn {
    margin: 0 auto 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    width: 408px;
    height: 90px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }

  .none{
    pointer-events:none;
    background-color: gray;
  }
</style>
