<template>
  <div class="page">
    <div class="header">
      <div class="header-title">Replace AD Image</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>

    <div class="content">
      <!-- 步骤一二的分类和地区选择 -->

      <div class="normal-upload-box">
        <div class="upload-title">Upload Your Photos</div>
        <div class="upload-info">
          Notice：High definition,sexy,pretty photos are better.The first
          picture will be the thumbnail picture.The first photo will be the
          cover, the second and third photo will follow it. Up to 9 photos.Not
          allowed to unland nude pictures.
        </div>
        <div class="upload-img-box">
          <div class="upload-container">
            <div class="upload-item-box">
              <van-loading ref="images_one_uploading" size="24px"
                >uploading...
                <template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_one_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <CUT
                :size_w="164"
                :size_h="175"
                :name="'images_one'"
                :uploadingStop="images_one_uploading_stop"
                @UpUrl="UpUrl"
                @showImagesUploading="showImagesUploading"
                @showImagesUploadingClose="showImagesUploadingClose"
              ></CUT>
              <div class="uploader-box" v-if="images_one == ''">
                <img
                  class="upload-icon"
                  src="../../assets/images/postAd/upload.png"
                  alt=""
                />
                <div class="upload-icon-text">Click to upload pictures</div>
              </div>
              <div class="uploader-img" v-else>
                <div class="delImg" @click="images_one = ''">
                  <span>X</span>
                </div>
                <img :src="images_one" alt="" />
              </div>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_two_uploading" size="24px"
                >uploading...<template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_two_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile2">
                <div class="uploader-box" v-if="images_two == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_two = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_two" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_three_uploading" size="24px"
                >uploading...<template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_three_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile3">
                <div class="uploader-box" v-if="images_three == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_three = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_three" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_four_uploading" size="24px"
                >uploading...<template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_four_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile4">
                <div class="uploader-box" v-if="images_four == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_four = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_four" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_five_uploading" size="24px"
                >uploading...<template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_five_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile5">
                <div class="uploader-box" v-if="images_five == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_five = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_five" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_six_uploading" size="24px"
                >uploading...<template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_six_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile6">
                <div class="uploader-box" v-if="images_six == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_six = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_six" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_seven_uploading" size="24px"
                ><template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_seven_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile7">
                <div class="uploader-box" v-if="images_seven == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_seven = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_seven" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_eight_uploading" size="24px"
                >uploading...<template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_eight_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template></van-loading
              >
              <van-uploader :after-read="uploadFile8">
                <div class="uploader-box" v-if="images_eight == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_eight = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_eight" alt="" />
                </div>
              </van-uploader>
            </div>
            <div class="upload-item-box">
              <van-loading ref="images_nine_uploading" size="24px"
                >uploading...
                <template>
                  <div
                    style="
                      font-size: large;
                      position: relative;
                      display: inline;
                      bottom: 20px;
                    "
                    @click="stopUploading('images_nine_uploading')"
                  >
                    <span>X</span>
                  </div>
                </template>
              </van-loading>
              <van-uploader :after-read="uploadFile9">
                <div class="uploader-box" v-if="images_nine == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="images_nine = ''">
                    <span>X</span>
                  </div>
                  <img :src="images_nine" alt="" />
                </div>
              </van-uploader>
            </div>
          </div>
        </div>
        <div style="text-align: center">
          <span style="color: gray">At least 4 photos are required</span>
        </div>
      </div>

      <div class="normal-adType-box" v-if="topPublish">
        <div class="rec-box">
          <div>
            <div class="upload-title">Top AD</div>
            <div class="upload-title">Advertising cover image</div>
            <div class="upload-img-box">
              <div
                class="upload-container"
                style="
                  display: flex;
                  justify-content: center;
                  align-items: center;
                "
              >
                <div class="upload-item-box">
                  <van-loading ref="largeImage_uploading" size="24px"
                    >uploading...<template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('largeImage_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <CUT
                    :size_w="337"
                    :size_h="266"
                    :name="'largeImage'"
                    @UpUrl="UpUrl"
                    :uploadingStop="largeImage_uploading_stop"
                    @showImagesUploading="showImagesUploading"
                    @showImagesUploadingClose="showImagesUploadingClose"
                  ></CUT>
                  <div class="uploader-box" v-if="largeImage == ''">
                    <img
                      class="upload-icon"
                      src="../../assets/images/postAd/upload.png"
                      alt=""
                    />
                    <div class="upload-icon-text">Click to upload pictures</div>
                  </div>
                  <div class="uploader-img" v-else>
                    <div class="delImg" @click="largeImage = ''">
                      <span>X</span>
                    </div>
                    <img :src="largeImage" alt="" />
                  </div>
                </div>
              </div>
            </div>
            <div style="text-align: center">
              <span style="color: gray">At least 1 top photo are required</span>
            </div>
          </div>
        </div>
      </div>

      <div class="normal-adType-box" v-if="recommendPublish">
        <div class="rec-box">
          <div>
            <div class="upload-title">Recommended AD</div>
            <div class="upload-title">Advertising cover image</div>
            <div class="upload-img-box">
              <div class="upload-container">
                <div class="upload-item-box">
                  <van-loading ref="recommendImageOne_uploading" size="24px"
                    >uploading...<template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('recommendImageOne_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <CUT
                    :size_w="176"
                    :size_h="236"
                    :name="'recommendImageOne'"
                    :uploadingStop="recommendImageOne_uploading_stop"
                    @UpUrl="UpUrl"
                    @showImagesUploading="showImagesUploading"
                    @showImagesUploadingClose="showImagesUploadingClose"
                  ></CUT>
                  <div class="uploader-box" v-if="recommendImageOne == ''">
                    <img
                      class="upload-icon"
                      src="../../assets/images/postAd/upload.png"
                      alt=""
                    />
                    <div class="upload-icon-text">Click to upload pictures</div>
                  </div>
                  <div class="uploader-img" v-else>
                    <div class="delImg" @click="recommendImageOne = ''">
                      <span>X</span>
                    </div>
                    <img :src="recommendImageOne" alt="" />
                  </div>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="recommendImageTwo_uploading" size="24px"
                    >uploading...<template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('recommendImageTwo_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <CUT
                    :size_w="153"
                    :size_h="112"
                    :name="'recommendImageTwo'"
                    :uploadingStop="recommendImageTwo_uploading_stop"
                    @UpUrl="UpUrl"
                    @showImagesUploading="showImagesUploading"
                    @showImagesUploadingClose="showImagesUploadingClose"
                  ></CUT>
                  <div class="uploader-box" v-if="recommendImageTwo == ''">
                    <img
                      class="upload-icon"
                      src="../../assets/images/postAd/upload.png"
                      alt=""
                    />
                    <div class="upload-icon-text">Click to upload pictures</div>
                  </div>
                  <div class="uploader-img" v-else>
                    <div class="delImg" @click="recommendImageTwo = ''">
                      <span>X</span>
                    </div>
                    <img :src="recommendImageTwo" alt="" />
                  </div>
                </div>
                <div class="upload-item-box">
                  <van-loading ref="recommendImageThree_uploading" size="24px"
                    >uploading...<template>
                      <div
                        style="
                          font-size: large;
                          position: relative;
                          display: inline;
                          bottom: 20px;
                        "
                        @click="stopUploading('recommendImageThree_uploading')"
                      >
                        <span>X</span>
                      </div>
                    </template></van-loading
                  >
                  <CUT
                    :size_w="153"
                    :size_h="112"
                    :name="'recommendImageThree'"
                    :uploadingStop="recommendImageThree_uploading_stop"
                    @UpUrl="UpUrl"
                    @showImagesUploading="showImagesUploading"
                    @showImagesUploadingClose="showImagesUploadingClose"
                  ></CUT>
                  <div class="uploader-box" v-if="recommendImageThree == ''">
                    <img
                      class="upload-icon"
                      src="../../assets/images/postAd/upload.png"
                      alt=""
                    />
                    <div class="upload-icon-text">Click to upload pictures</div>
                  </div>
                  <div class="uploader-img" v-else>
                    <div class="delImg" @click="recommendImageThree = ''">
                      <span>X</span>
                    </div>
                    <img :src="recommendImageThree" alt="" />
                  </div>
                </div>
              </div>
            </div>

            <div style="text-align: center">
              <span style="color: gray">At least 3 photos are required</span>
            </div>
          </div>
        </div>
      </div>

      <div style="padding: 30px">
        <div class="sure-btn" @click="postDraft">Confirm</div>
      </div>
    </div>
  </div>
</template>

<script>
import {
  apiUpload,
  apiPOSTadvertisement_put_replace,
  apiGetAllList_detail,
} from "../../request/api";
import { Toast } from "vant";
import { Dialog } from "vant";
// 富文本
import Editor from "@tinymce/tinymce-vue";
// 富文本
import CUT from "../postAd/Cut.vue";
export default {
  name: "postAd",
  components: { "tinymce-editor": Editor, CUT },
  data() {
    return {
      tokenKey: localStorage.getItem("key"),
      // 发布广告的id
      advertisementId: null,
      icon: {
        active1: require("../../assets/images/tabbar/tabbar1.png"),
        inactive1: require("../../assets/images/tabbar/tabbar2.png"),
        active2: require("../../assets/images/tabbar/tabbar3.png"),
        inactive2: require("../../assets/images/tabbar/tabbar4.png"),
        active3: require("../../assets/images/tabbar/tabbar5.png"),
        inactive3: require("../../assets/images/tabbar/tabbar6.png"),
        active4: require("../../assets/images/tabbar/tabbar7.png"),
        inactive4: require("../../assets/images/tabbar/tabbar8.png"),
        active5: require("../../assets/images/tabbar/tabbar9.png"),
        inactive5: require("../../assets/images/tabbar/tabbar10.png"),
      },

      images_one: "",
      images_one_uploading_stop: false,
      images_two: "",
      images_two_uploading_stop: false,
      images_three: "",
      images_three_uploading_stop: false,
      images_four: "",
      images_four_uploading_stop: false,
      images_five: "",
      images_five_uploading_stop: false,
      images_six: "",
      images_six_uploading_stop: false,
      images_seven: "",
      images_seven_uploading_stop: false,
      images_eight: "",
      images_eight_uploading_stop: false,
      images_nine: "",
      images_nine_uploading_stop: false,

      // 普通、大图、推荐发布
      normalPublish: true,
      topPublish: false,
      recommendPublish: false,

      recommendImageOne: "",
      recommendImageOne_uploading_stop: false,
      recommendImageTwo: "",
      recommendImageTwo_uploading_stop: false,
      recommendImageThree: "",
      recommendImageThree_uploading_stop: false,
      largeImage: "",
      largeImage_uploading_stop: false,

      type: [],
    };
  },
  computed: {},
  watch: {},
  created() {
    this.tokenKey = localStorage.getItem("key") ?? "";
    let token = localStorage.getItem("key");
    if (!token) {
      this.$router.push("/login");
    }
    // 我的广告再次编辑传来广告id后获取详情
    let adId = this.$route.query.advertisementId;
    if (adId) {
      apiGetAllList_detail({
        advertisementId: adId,
      }).then((res) => {
        if (res.code == 200) {
          this.images_one = res.data.imagesOne;
          this.images_two = res.data.imagesTwo;
          this.images_three = res.data.imagesThree;
          this.images_four = res.data.imagesFour;
          this.images_five = res.data.imagesFive;
          this.images_six = res.data.imagesSix;
          this.images_seven = res.data.imagesSeven;
          this.images_eight = res.data.imagesEight;
          this.images_nine = res.data.imagesNine;
          this.recommendImageOne = res.data.recommendImageOne;
          this.recommendImageTwo = res.data.recommendImageTwo;
          this.recommendImageThree = res.data.recommendImageThree;
          this.largeImage = res.data.largeImage;
          this.type = res.data.type;
          this.normalPublish = true; //小图默认
          this.topPublish = this.type.indexOf("2") !== -1;
          this.recommendPublish = this.type.indexOf("3") !== -1;
          this.advertisementId = res.data.advertisementId;
        }
      });
    }
    // 新增 end
  },
  methods: {
    stopUploading(name) {
      console.log("stopUploading...");
      if (name == "recommendImageOne_uploading") {
        this.$refs.recommendImageOne_uploading.style.display = "none";
        this.recommendImageOne_uploading_stop = true;
      } else if (name == "recommendImageTwo_uploading") {
        this.$refs.recommendImageTwo_uploading.style.display = "none";
        this.recommendImageTwo_uploading_stop = true;
      } else if (name == "recommendImageThree_uploading") {
        this.$refs.recommendImageThree_uploading.style.display = "none";
        this.recommendImageThree_uploading_stop = true;
      } else if (name == "largeImage_uploading") {
        this.$refs.largeImage_uploading.style.display = "none";
        this.largeImage_uploading_stop = true;
      } else if (name == "images_one_uploading") {
        this.$refs.images_one_uploading.style.display = "none";
        this.images_one_uploading_stop = true;
      } else if (name == "images_two_uploading") {
        this.$refs.images_two_uploading.style.display = "none";
        this.images_two_uploading_stop = true;
      } else if (name == "images_three_uploading") {
        this.$refs.images_three_uploading.style.display = "none";
        this.images_three_uploading_stop = true;
      } else if (name == "images_four_uploading") {
        this.$refs.images_four_uploading.style.display = "none";
        this.images_four_uploading_stop = true;
      } else if (name == "images_five_uploading") {
        this.$refs.images_five_uploading.style.display = "none";
        this.images_five_uploading_stop = true;
      } else if (name == "images_six_uploading") {
        this.$refs.images_six_uploading.style.display = "none";
        this.images_six_uploading_stop = true;
      } else if (name == "images_seven_uploading") {
        this.$refs.images_seven_uploading.style.display = "none";
        this.images_seven_uploading_stop = true;
      } else if (name == "images_eight_uploading") {
        this.$refs.images_eight_uploading.style.display = "none";
        this.images_eight_uploading_stop = true;
      } else if (name == "images_nine_uploading") {
        this.$refs.images_nine_uploading.style.display = "none";
        this.images_nine_uploading_stop = true;
      }
    },
    UpUrl(data) {
      console.log(data);
      if (data.name == "recommendImageOne") {
        this.recommendImageOne = data.url;
      } else if (data.name == "recommendImageTwo") {
        this.recommendImageTwo = data.url;
      } else if (data.name == "recommendImageThree") {
        this.recommendImageThree = data.url;
      } else if (data.name == "largeImage") {
        this.largeImage = data.url;
      } else if (data.name == "images_one") {
        this.images_one = data.url;
      }
    },
    showImagesUploading(data) {
      console.log(data);
      if (data.name == "recommendImageOne") {
        this.$refs.recommendImageOne_uploading.style.display = "block";
      } else if (data.name == "recommendImageTwo") {
        this.$refs.recommendImageTwo_uploading.style.display = "block";
      } else if (data.name == "recommendImageThree") {
        this.$refs.recommendImageThree_uploading.style.display = "block";
      } else if (data.name == "largeImage") {
        this.$refs.largeImage_uploading.style.display = "block";
      } else if (data.name == "images_one") {
        this.$refs.images_one_uploading.style.display = "block";
      } else if (data.name == "images_two") {
        this.$refs.images_two_uploading.style.display = "block";
      } else if (data.name == "images_three") {
        this.$refs.images_three_uploading.style.display = "block";
      }
    },
    showImagesUploadingClose(data) {
      console.log(data);
      if (data.name == "recommendImageOne") {
        this.$refs.recommendImageOne_uploading.style.display = "none";
      } else if (data.name == "recommendImageTwo") {
        this.$refs.recommendImageTwo_uploading.style.display = "none";
      } else if (data.name == "recommendImageThree") {
        this.$refs.recommendImageThree_uploading.style.display = "none";
      } else if (data.name == "largeImage") {
        this.$refs.largeImage_uploading.style.display = "none";
      } else if (data.name == "images_one") {
        this.$refs.images_one_uploading.style.display = "none";
      } else if (data.name == "images_two") {
        this.$refs.images_two_uploading.style.display = "none";
      } else if (data.name == "images_three") {
        this.$refs.images_three_uploading.style.display = "none";
      }
    },

    // 上传图片
    uploadFile1(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_one_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_one_uploading_stop) {
          this.images_one_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_one = res.url;
          this.$refs.images_one_uploading.style.display = "none";
        }
      });
    },
    uploadFile2(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_two_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_two_uploading_stop) {
          this.images_two_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_two = res.url;
          this.$refs.images_two_uploading.style.display = "none";
        }
      });
    },
    uploadFile3(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_three_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_three_uploading_stop) {
          this.images_three_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_three = res.url;
          this.$refs.images_three_uploading.style.display = "none";
        }
      });
    },
    uploadFile4(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_four_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_four_uploading_stop) {
          this.images_four_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_four = res.url;
          this.$refs.images_four_uploading.style.display = "none";
        }
      });
    },
    uploadFile5(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_five_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_five_uploading_stop) {
          this.images_five_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_five = res.url;
          this.$refs.images_five_uploading.style.display = "none";
        }
      });
    },
    uploadFile6(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_six_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_six_uploading_stop) {
          this.images_six_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_six = res.url;
          this.$refs.images_six_uploading.style.display = "none";
        }
      });
    },
    uploadFile7(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_seven_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_seven_uploading_stop) {
          this.images_seven_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_seven = res.url;
          this.$refs.images_seven_uploading.style.display = "none";
        }
      });
    },
    uploadFile8(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_eight_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_eight_uploading_stop) {
          this.images_eight_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_eight = res.url;
          this.$refs.images_eight_uploading.style.display = "none";
        }
      });
    },
    uploadFile9(file) {
      const formData = new FormData();
      formData.append("file", file.file);
      this.$refs.images_nine_uploading.style.display = "block";
      apiUpload(formData).then((res) => {
        if (this.images_nine_uploading_stop) {
          this.images_nine_uploading_stop = false;
          return;
        }
        if (res.code == 200) {
          this.images_nine = res.url;
          this.$refs.images_nine_uploading.style.display = "none";
        }
      });
    },

    postDraft() {
      let imgNum = 0;
      if (this.images_one != "") {
        imgNum++;
      }
      if (this.images_two != "") {
        imgNum++;
      }
      if (this.images_three != "") {
        imgNum++;
      }
      if (this.images_four != "") {
        imgNum++;
      }
      if (this.images_five != "") {
        imgNum++;
      }
      if (this.images_six != "") {
        imgNum++;
      }
      if (this.images_seven != "") {
        imgNum++;
      }
      if (this.images_eight != "") {
        imgNum++;
      }
      if (this.images_nine != "") {
        imgNum++;
      }

      if (this.images_one == '') {
          this.toastDialog("Thumbnail photo is required");
          return;
        }

      if (imgNum < 4) {
        this.toastDialog("At least 4 normal photos are required");
        return;
      }

      if (
        (!this.recommendImageOne ||
          !this.recommendImageTwo ||
          !this.recommendImageThree) &&
        this.type.includes("3")
      ) {
        this.toastDialog("At least 3 Recommended photos are required");
        return;
      }
      if (!this.largeImage && this.type.includes("2")) {
        this.toastDialog("Must upload one large image!");
        return;
      }

      let adId = this.$route.query.advertisementId;
      console.log("adId" + adId);
      if (adId) {
        this.PUT_apiPOSTadvertisement();
        return;
      }
    },
    //发布广告接口  ==编辑
    PUT_apiPOSTadvertisement() {
      apiPOSTadvertisement_put_replace({
        imagesOne: this.images_one,
        imagesTwo: this.images_two,
        imagesThree: this.images_three,
        imagesFour: this.images_four,
        imagesFive: this.images_five,
        imagesSix: this.images_six,
        imagesSeven: this.images_seven,
        imagesEight: this.images_eight,
        imagesNine: this.images_nine,
        recommendImageOne: this.recommendImageOne,
        recommendImageTwo: this.recommendImageTwo,
        recommendImageThree: this.recommendImageThree,
        largeImage: this.largeImage,
        advertisementId: this.advertisementId,
      }).then((res) => {
        if (res.code == 200) {
          Toast.success(res.msg);
          this.advertisementId = res.data;
          setTimeout(() => {
            this.$router.push("/myAD");
          }, 2000);
        } else if (res.code == 205) {
          this.showReleaseBox = true;
        } else {
          Toast.fail(res.msg);
        }
      });
    },
    goBack() {
      this.$router.go(-1);
    },
    toggle(index) {
      this.$refs.checkboxes[index].toggle();
    },
    toastDialog(info) {
      Dialog.alert({
        title: "Toast",
        message: info,
      }).then(() => {
        //on confirm
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.page {
  background: #ebebeb;
  padding-bottom: 240px;
}
.content {
  padding: 0 24px;
  margin-bottom: 120px;
}
.step-box {
  margin: 20px 0;
  background: #ffffff;
  padding: 27px 40px 34px;
  .step-title {
    font-size: 28px;
    font-weight: 400;
    color: #000000;
    text-align: center;
  }
  .step-imgBox {
    margin-top: 39px;
    display: flex;
    align-items: center;
  }
  .step-imgBox-img {
    width: 73px;
    height: 73px;
  }
  .green-line {
    width: 78px;
    height: 0px;
    border: 2px solid #21b66d;
    margin: 0 16px;
  }
  .black-line {
    width: 78px;
    height: 0px;
    margin: 0 16px;
    border: 2px solid #232f3e;
  }
  .step-textBox {
    margin-top: 22px;
    font-size: 28px;
    font-weight: 400;
    color: #000000;
  }
  .step-text1 {
    margin-right: 51px;
  }
  .step-text2 {
    margin-right: 91px;
  }
  .step-text3 {
    margin-right: 88px;
  }
}
.category-box {
  padding: 30px 40px 50px;
  background: #fff;
  .category-header {
    display: flex;
    align-items: center;
  }
  .category-box-img {
    width: 73px;
    height: 73px;
  }
  .category-header-title {
    margin-left: 24px;
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .choose-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 23px;
  }
  .category-item {
    margin-bottom: 20px;
    padding: 24px 0 24px 35px;
    font-size: 24px;
    font-weight: bold;
    background: #f3f3f3;
    color: #000000;
  }
  .activeCategoryBg {
    background: #273458;
    color: #fff;
  }
}
.location-box {
  padding: 30px 40px 50px;
  margin-top: 20px;
  background: #fff;
  .location-header {
    display: flex;
    align-items: center;
  }
  .location-box-img {
    width: 73px;
    height: 73px;
  }
  .location-header-title {
    margin-left: 24px;
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .location-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 23px;
  }
  .confirm-btn {
    height: 90px;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    margin: 45px auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 408px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
  .showRight-box {
    position: relative;
    margin: 20px 0;
    padding: 10px;
    .area-flex-box {
      height: 80px;
      background: #ffffff;
      border: 1px solid rgba(112, 112, 112, 0.34);
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px;
    }
    .area-box-lf {
      font-size: 28px;
      font-weight: 400;
      color: #242424;
      margin-left: 10px;
    }
    .area-box-rg {
      img {
        width: 0.64rem;
        height: 0.64rem;
      }
    }
  }
}
.publish-box {
  .publish-info {
    padding: 30px 40px;
    background: #fff;
  }
  .publish-info-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .info-header-lf {
    width: 72px;
    height: 73px;
    background: #273458;
    border-radius: 50%;
    font-size: 35px;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 24px;
  }
  .info-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .publish-info-text {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
  }
  .upgrade-days {
    margin-top: 20px;
    padding: 28px 40px 16px;
    background: #fff;
  }
  .upgrade-days-header {
    display: flex;
    align-items: center;
    margin-bottom: 47px;
  }
  .days-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .days-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .days-menu {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
  }
  .days-item {
    width: 33.3%;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  .days-text {
    height: 50px;
    border: 1px solid #bab2b2;
    background: #fff;
    font-size: 24px;
    font-weight: bold;
    color: #1f1a17;
    padding: 9px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 14px;
  }
  .activeDaysBg {
    border: 1px solid #273458;
    background: #273458;
    color: #fff;
  }
  .last-item {
    flex: 1;
  }
  .total-box {
    margin: 20px 0;
    display: flex;
    justify-content: flex-end;
  }
  .total-box-text {
    background: #273458;
    color: #fff;
    font-size: 24px;
    font-weight: bold;
    padding: 10px 20px;
    min-width: 140px;
    text-align: center;
  }
  .my-ads-box {
    margin: 20px 0;
    padding: 24px 40px 40px;
    background: #fff;
  }
  .my-ads-header {
    display: flex;
    align-items: center;
    margin-bottom: 40px;
  }
  .my-ads-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .my-ads-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }

  .table-box {
    margin-bottom: 57px;
  }
  .my-table {
    border-collapse: collapse;
    width: 100%;
  }
  .my-table td {
    text-align: center;
    vertical-align: middle;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
  }
  .col1 {
    width: 25%;
  }
  .col2 {
    width: 30%;
  }
  .col3 {
    width: 45%;
  }
  .col1,
  .col2,
  .col3 {
    height: 70px;
    border: 1px solid #707070;
  }
  .fee-text {
    font-size: 34px;
    font-weight: 400;
    color: #000000;
    text-align: center;
    margin-bottom: 55px;
  }
  .fee-num {
    font-size: 34px;
    font-weight: 800;
    color: #000000;
  }
}
// 弹窗
.questionPopup-box {
  width: 567px;
  background: #ffffff;
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}

// 普通店铺详情
.normal-box {
  .normal-city-iptBox {
    background: #fff;
    padding: 40px;
  }
  .city-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin-bottom: 55px;
  }
  .city-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .city-three-img {
    width: 73px;
    height: 73px;
    margin-right: 25px;
  }
  .header-rg-p1 {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .header-rg-p2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .city-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 20px;
  }
  .city-ipt {
    height: 80px;
    align-items: center;

    border: 1px solid #e2e2e2;
  }
  :deep(.van-field__control) {
    font-size: 28px;
  }
  .city-detail-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 20px;
  }
  .ipt-flexBox {
    // display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .flexBox-lf {
    width: 50%;
    margin-right: 8px;
  }
  .flexBox-lf1 {
    height: 80px;
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
  }
  .flexBox-rg {
    width: 50%;
    margin-left: 8px;
  }
  .num-info {
    margin: 30px 0 20px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
}
.normal-person-iptBox1 {
  background: #fff;
  // margin-top: 20px;
}
.normal-person-iptBox {
  background: #fff;
  margin-top: 20px;
  padding: 40px;
  .ipt-flexBox {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 30px;
  }
  .flexBox-lf {
    width: 50%;
    margin-right: 8px;
  }
  .flexBox-rg {
    width: 50%;
    margin-left: 8px;
  }
  .ipt-title {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 10px;
  }
  .lang-box {
    position: relative;
    .area-flex-box {
      height: 80px;
      background: #ffffff;
      border: 1px solid rgba(112, 112, 112, 0.34);
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .area-box-lf {
      font-size: 28px;
      font-weight: 400;
      color: #242424;
      margin-left: 10px;
    }
    .bottom-icon-bl-img {
      width: 48px;
      height: 48px;
    }
    .location-select-box {
      position: absolute;
      z-index: 1;
      background: #fff;
      padding: 20px;
      left: 0;
      right: 0;
      border: 1px solid #f4f4f4;
    }
    .location-ipt {
      height: 81px;
      align-items: center;
    }
    :deep(.van-field__control) {
      font-size: 28px;
    }
    .location-list {
      margin-bottom: 40px;
    }
    .location-list-title {
      font-size: 30px;
      font-weight: bold;
      color: #000000;
    }
    .state-cell {
      box-sizing: border-box;
      padding: 26px 20px;
      overflow: hidden;
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      line-height: 25px;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      font-weight: 700;
    }
    .state-value {
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      text-align: center;
    }
    .city-cell {
      box-sizing: border-box;
      padding: 26px 0;
      overflow: hidden;
      font-size: 24px;
      font-weight: 400;
      color: #989898;
    }
    .city-value {
      font-size: 24px;
      font-weight: 400;
      color: #989898;
      text-align: center;
    }
  }
  .availability-box {
    margin: 20px 0;
  }
  .available-radio {
    margin-right: 30px;
  }
}
.normal-adType-box {
  margin-top: 20px;
  padding: 30px 20px;
  background: #fff;
  .adType-header {
    display: flex;
  }
  .ad-header-lf {
    margin-right: 20px;
  }
  .ad-header-img {
    width: 280px;
    height: 280px;
  }
  .rg {
    flex: 1;
    position: relative;
  }
  .ad-header-rg-1 {
    font-size: 30px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 15px;
  }
  .ad-header-rg-2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    margin-bottom: 60px;
    color: #000000;
  }
  .ad-header-rg-3 {
    font-size: 26px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }
  .adType-line {
    height: 0px;
    margin: 30px 0;
    opacity: 0.23;
    border: 1px solid #707070;
  }
  .type-upgrade-box {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 40px;
  }
  .upgrade-box {
    height: 70px;
    background: #273458;
    width: 449px;
    font-size: 28px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 30px;
  }
  .price-box {
    border: 1px solid #707070;
    height: 70px;
    display: flex;
    align-items: center;
  }
  .price-box-1 {
    width: 26%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .price-box-2 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #707070;
    height: 70px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    border-right: 1px solid #707070;
  }
  .price-box-3 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .price-box-two {
    border-top: none;
  }
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
    text-align: center;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.normal-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.big-line {
  height: 0px;
  opacity: 1;
  border: 1px solid #707070;
  margin: 50px 0;
}

.goBack-box {
  display: flex;
  align-items: center;
  font-size: 24px;
  font-family: PingFang SC-Regular, PingFang SC;
  font-weight: 400;
  color: #000000;
  .goDown-go {
    width: 50%;
    margin-right: 12px;
    justify-content: center;
    display: flex;
    align-items: center;
    height: 80px;
    background: #ffffff;
    border: 1px solid #273458;
  }
}
.goDown-back {
  width: 100%;
  height: 90px;
  margin-top: 24px;
  display: flex;
  align-items: center;
  height: 80px;
  justify-content: center;
  background: #ffffff;
  border: 1px solid #273458;
}
.Review-btn {
  margin: 24px 0;
  width: 50%;
  height: 90px;
  background: #273458;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-family: PingFang SC-Bold, PingFang SC;
  font-weight: bold;
  color: #ffffff;
  box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
}

// 商铺详情
.shop-box {
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  .shop-city-iptBox {
    background: #fff;
    padding: 40px;
  }
  .city-info {
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin-bottom: 55px;
  }
  .city-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .city-three-img {
    width: 73px;
    height: 73px;
    margin-right: 25px;
  }
  .header-rg-p1 {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .header-rg-p2 {
    font-size: 20px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #989898;
    margin-left: 70px;
  }
  .city-title {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 20px;
  }
  .city-ipt {
    height: 80px;
    align-items: center;
    border: 1px solid #e2e2e2;
  }
  :deep(.van-field__control) {
    font-size: 28px;
  }
  .city-detail-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin: 30px 0 20px;
  }
  .ipt-flexBox {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .flexBox-lf {
    width: 50%;
    margin-right: 8px;
  }
  .flexBox-rg {
    width: 50%;
    margin-left: 8px;
  }
  .num-info {
    margin: 30px 0 20px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
}
.shop-person-iptBox {
  background: #fff;
  margin-top: 20px;
  padding: 40px;
  .checkedOut-box {
    display: flex;
    align-items: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 30px;
  }
  .checkedOut-lf {
    width: 60%;
  }
  .checkedOut-rg {
    text-align: right;
  }
  .charging-box {
    display: flex;
    align-items: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 20px;
  }
  .charging-box-lf {
    width: 40%;
  }
  .charging-box-rg {
    border: 1px solid #e2e2e2;
  }
  .charging-ipt {
    align-items: center;
    height: 70px;
    background: #ffffff;
  }
}
.shop-adType-box {
  margin-top: 20px;
  padding: 30px 20px;
  background: #fff;
  .adType-header {
    display: flex;
  }
  .ad-header-lf {
    margin-right: 20px;
  }
  .ad-header-img {
    width: 280px;
    height: 280px;
  }
  .rg {
    flex: 1;
    position: relative;
  }
  .ad-header-rg-1 {
    font-size: 30px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 15px;
  }
  .ad-header-rg-2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    margin-bottom: 60px;
    color: #000000;
  }
  .ad-header-rg-3 {
    font-size: 26px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }
  .adType-line {
    height: 0px;
    margin: 30px 0;
    opacity: 0.23;
    border: 1px solid #707070;
  }
  .type-upgrade-box {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 40px;
  }
  .upgrade-box {
    height: 70px;
    background: #273458;
    width: 449px;
    font-size: 28px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 30px;
  }
  .price-box {
    border: 1px solid #707070;
    height: 70px;
    display: flex;
    align-items: center;
  }
  .price-box-1 {
    width: 26%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .price-box-2 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #707070;
    height: 70px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    border-right: 1px solid #707070;
  }
  .price-box-3 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .price-box-two {
    border-top: none;
  }
}
.shop-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
}
// vip
.vip-box {
  .upload-item-box-vip-one {
    width: 100%;
    height: 964px;
    margin-bottom: 20px;
    overflow: hidden;
    background: #ffffff;
    border: 1px solid #707070;
    display: flex;
    justify-content: center;
    align-items: center;
    .uploader-box {
      width: 250px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      .upload-icon-text {
        margin-top: 10px;
        width: 250px;
        height: 80px;
        font-size: 28px;
        font-family: PingFang SC-Regular, PingFang SC;
        font-weight: 400;
        color: #888888;
        text-align: center;
      }
    }
  }
  .upload-item-box-vip-one-702 {
    width: 100%;
    height: 702px;
  }
  .upload-item-box-vip-one-501 {
    width: 100%;
    height: 501px;
  }
  .upload-item-box-vip-one-702 {
    width: 100%;
    height: 702px;
  }
  .upload-item-box-vip-two {
    width: 100%;
    height: 501px;
    margin-bottom: 20px;
    overflow: hidden;
    // background: #ffffff;
    // border: 1px solid #707070;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .upload-item-box-vip-two-item {
      width: 49%;
      height: 100%;
      box-sizing: border-box;
      background: #ffffff;
      border: 1px solid #707070;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .uploader-box {
      width: 250px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      .upload-icon-text {
        margin-top: 10px;
        width: 250px;
        height: 80px;
        font-size: 28px;
        font-family: PingFang SC-Regular, PingFang SC;
        font-weight: 400;
        color: #888888;
        text-align: center;
      }
    }
  }
  .paragraph {
    width: 100%;
    .paragraph-title {
      width: 100%;
      height: 115px;
      line-height: 115px;
      padding-left: 63px;
      box-sizing: border-box;
      background: #ffffff;
      font-size: 28px;
      font-family: PingFang SC-Regular, PingFang SC;
      font-weight: 400;
      color: #989898;
    }
    .paragraph-title-text {
      .van-cell {
        font-size: 40px;
        font-family: Didot HTF-M06-Medium, Didot HTF-M06;
        font-weight: 500;
        color: #989898;
        padding-left: 65px;
        border: 0px;
        background: #f8f8f8;
      }
    }
    .paragraph-title-text-w {
      .van-cell {
        font-size: 40px;
        font-family: Didot HTF-M06-Medium, Didot HTF-M06;
        font-weight: 500;
        color: #989898;
        padding-left: 65px;
        border: 0px;
        background: #fff;
      }
    }
    .paragraph-context {
      background: #f8f8f8;
    }
  }
  .vip-input-box {
    width: 100%;
    height: 70px;
    margin: 15px 0;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    .vip-input-box-title {
      width: 30%;
      height: 100%;
      background: #273458;
      font-size: 26px;
      font-family: PingFang SC-Medium, PingFang SC;
      font-weight: 500;
      line-height: 70px;
      color: #ffffff;
      text-align: center;
    }
    .vip-input-box-input {
      background: #f3f3f3;
      width: 70%;
      height: 70px;
      .van-cell {
        width: 100%;
        height: 100%;
        background: #f3f3f3;
      }
    }
    .lang-box {
      width: 100%;
      height: 100%;
      position: relative;
      .area-flex-box {
        width: 100%;
        height: 100%;
        // border: 1px solid rgba(112, 112, 112, 0.34);
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .area-box-lf {
        font-size: 28px;
        font-weight: 400;
        color: #242424;
        margin-left: 10px;
      }
      .bottom-icon-bl-img {
        width: 48px;
        height: 48px;
      }
      .location-select-box {
        position: absolute;
        z-index: 1;
        background: #fff;
        padding: 20px;
        left: 0;
        right: 0;
        border: 1px solid #f4f4f4;
      }
      .location-ipt {
        height: 81px;
        align-items: center;
      }
      :deep(.van-field__control) {
        font-size: 28px;
      }
      .location-list {
        margin-bottom: 40px;
      }
      .location-list-title {
        font-size: 30px;
        font-weight: bold;
        color: #000000;
      }
      .state-cell {
        box-sizing: border-box;
        padding: 26px 0;
        overflow: hidden;
        font-size: 28px;
        font-weight: 400;
        background: #fff;
        color: #000000;
        line-height: 25px;
      }
      .state-value {
        font-size: 28px;
        font-weight: 400;
        color: #000000;
        text-align: center;
      }
      .city-cell {
        box-sizing: border-box;
        padding: 26px 0;
        overflow: hidden;
        font-size: 24px;
        font-weight: 400;
        color: #989898;
      }
      .city-value {
        font-size: 24px;
        font-weight: 400;
        color: #989898;
        text-align: center;
      }
    }
  }
}
.uploader-img img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.van-cell_value--alone {
  font-size: 32px;
  height: 50px;
  line-height: 50px;
}
:deep(.van-uploader) {
  width: 100%;
  height: 100%;
}
:deep(.van-uploader__wrapper) {
  width: 100%;
  height: 100%;
}
:deep(.van-uploader__input-wrapper) {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.uploader-img {
  width: 100%;
  height: 100%;
}
.close-img {
  width: 37px;
  height: 37px;
}
.van-cell__title {
  line-height: 40px !important;
  text-align: left;
  margin-left: 10px;
  font-weight: 800;
}
.van-cell {
  line-height: 20px !important;
  font-weight: 800;
}

.sure-btn {
  margin: 0 auto 25px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-weight: bold;
  color: #ffffff;
  width: 408px;
  height: 90px;
  background: #273458;
  box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
}

.delImg {
  position: absolute;
  left: 80%;
  width: 20%;
  font-size: large;
  z-index: 2;
}

.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}

:deep(.van-loading) {
  position: absolute;
  width: 100%;
  height: 100%;
  background: white;
  z-index: 1;
  line-height: 204px;
  display: none;
  text-align: center;
}
</style>
