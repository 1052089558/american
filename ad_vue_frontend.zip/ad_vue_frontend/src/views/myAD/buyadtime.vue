<template>
  <div class="page">
    <div class="header">
      <div class="header-title">buy ads display time</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>    

    <div v-if="((type.indexOf('3')) !== -1 )" class="upgrade-days">
      <div class="upgrade-days-header">
        <div class="days-header-lf"></div>            
        <div class="days-header-rg">Recommended AD time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="recommendchecked = !recommendchecked" style="width: 50%;">
          <div class="days-text" >
            1 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked1 = !recommendchecked1" style="width: 50%;">
          <div class="days-text" >
            5 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked2 = !recommendchecked2" style="width: 50%;">
          <div class="days-text" >
            10 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked3 = !recommendchecked3" style="width: 50%;">
          <div class="days-text" >
            20 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="recommendchecked4 = !recommendchecked4" style="width: 50%;">
          <div class="days-text" >
            30 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div v-if="adAutoRenewRecommendedFromDB!='1'" class="days-item last-item" @click="recommendchecked5 = !recommendchecked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="recommendchecked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
      </div>
    </div>

    <div v-if="((type.indexOf('2')) !== -1 )" class="upgrade-days">
      <div class="upgrade-days-header">
        <div class="days-header-lf"></div>            
        <div class="days-header-rg">TOP AD time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="topchecked = !topchecked" style="width: 50%;">
          <div class="days-text" >
            1 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked1 = !topchecked1" style="width: 50%;">
          <div class="days-text" >
            5 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked2 = !topchecked2" style="width: 50%;">
          <div class="days-text" >
            10 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked3 = !topchecked3" style="width: 50%;">
          <div class="days-text" >
            20 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="topchecked4 = !topchecked4" style="width: 50%;">
          <div class="days-text" >
            30 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div v-if="adAutoRenewTopFromDB!='1'" class="days-item last-item" @click="topchecked5 = !topchecked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="topchecked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
      </div>
    </div>

    <div class="upgrade-days">
      <div class="upgrade-days-header">
        <div class="days-header-lf"></div>            
        <div class="days-header-rg">Normal AD time</div>
      </div>
      <div class="days-menu">
        <div class="days-item" @click="checked = !checked" style="width: 50%;">
          <div class="days-text" >
            1 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="checked1 = !checked1" style="width: 50%;">
          <div class="days-text" >
            5 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked1"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="checked2 = !checked2" style="width: 50%;">
          <div class="days-text" >
            10 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked2"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="checked3 = !checked3" style="width: 50%;">
          <div class="days-text" >
            20 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked3"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div class="days-item" @click="checked4 = !checked4" style="width: 50%;">
          <div class="days-text" >
            30 Days
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked4"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div v-if="adAutoRenewNormalFromDB!='1'" class="days-item last-item" @click="checked5 = !checked5" style="width: 50%;">
          <div class="days-text" >
            Automatic renewal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="checked5"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
      </div>
    </div>

    <!-- 取消自动续费 -->
    <div class="upgrade-days" v-if="adAutoRenewNormalFromDB=='1' || adAutoRenewTopFromDB=='1' || adAutoRenewRecommendedFromDB=='1'">
      <div class="upgrade-days-header">
        <div class="days-header-lf"></div>            
        <div class="days-header-rg">Cancel Autorenew</div>
      </div>
      <div class="days-menu" >
        <div v-if="adAutoRenewNormalFromDB=='1'" class="days-item" @click="autoRenewalNormalCancel = !autoRenewalNormalCancel" style="width: 100%;">
          <div class="days-text" >
            cancel autoRenew Normal
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="autoRenewalNormalCancel"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div v-if="adAutoRenewTopFromDB=='1'" class="days-item" @click="autoRenewalTopCancel = !autoRenewalTopCancel" style="width: 100%;">
          <div class="days-text" >
            cancel autorenew Top
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="autoRenewalTopCancel"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        <div v-if="adAutoRenewRecommendedFromDB=='1'" class="days-item" @click="autoRenewalRecommendCancel = !autoRenewalRecommendCancel" style="width: 100%;">
          <div class="days-text" >
            cancel autorenew Recommended
          </div>
          <div class="days-btn">
            <van-checkbox
              v-model="autoRenewalRecommendCancel"
              checked-color="#273458"
              icon-size="20px"
            ></van-checkbox>
          </div>
        </div>
        
      </div>
    </div>

    <div class="my-ads-box">
      <div class="my-ads-header">
        <div class="my-ads-header-lf"></div>
        <div class="my-ads-header-rg">My AD</div>            
      </div>
      <div class="table-box">
        <table class="my-table">
          <tr >
            <td class="col1" >Ad type</td>
            <td class="col2" >AD Display time</td>
            <td class="col3" >Price</td>
          </tr>

          <tr v-show="needManeyValue>0">
            <td class="col1">Normal AD</td>
            <td class="col2">Exp:{{ formatDate(expireDate) }}</td>
            <td class="col3">
              ${{ needManeyValue }}
            </td>
          </tr>

          <tr >
            <td class="col1">Normal AD</td>

            <td class="col2" v-if="autoRenewalNormalCancel==true" style="color:red;">cancel autorenew</td>
            <td class="col2" v-else>{{ totol_days_normal }} Days</td>

            <td class="col3">
              ${{ (normalShowPreDay*100)*totol_days_normal/100}}
            </td>
          </tr>

          <tr v-show="(type.indexOf('2') != -1)">
            <td class="col1">Top AD</td>

            <td class="col2" v-if="autoRenewalTopCancel==true" style="color:red;">cancel autorenew</td>
            <td class="col2" v-else>{{ totol_days_top }} Days</td>

            <td class="col3">
              ${{ (topShowPreDay*100) * totol_days_top/100 }}
            </td>
          </tr>

          <tr  v-show="(type.indexOf('3') != -1)">
            <td class="col1">Recommended AD</td>
            <td class="col2" v-if="autoRenewalRecommendCancel==true" style="color:red;">cancel autorenew</td>
            <td class="col2" v-else>{{ totol_days_recommend }} Days</td>
            <td class="col3">
              ${{ (recommendShowPreDay*100) * totol_days_recommend/100 }}
            </td>
          </tr>

        </table>
      </div>
    </div>    

    <div class="fee-text">
      Total：$ <span class="fee-num">{{ totolfee }}</span>
    </div>
    <div class="sure-btn" @click="showconfirm" :class="{ none: !paymentisable }">
      payment 
    </div>



  </div>    
</template>

<script>
import {
  apiBuyAdTime,
  apiGetAllList_detail,
  apiNeedManey,
} from '../../request/api'
import Swiper from 'swiper'
import 'swiper/css/swiper.css'
import { Dialog } from 'vant'
import Moment from 'moment'
export default {
  name: 'buyadtime',
  data() {
    return {

      autoRenewalNormalCancel:false,
      autoRenewalTopCancel:false,
      autoRenewalRecommendCancel:false,

      advertisementId:0,
      maney:10,
      type:[],
      totolfee:0,
      totol_days_normal:0,
      totol_days_top:0,
      totol_days_recommend:0,
      checked: false,
      checked1: false,
      checked2: false,
      checked3: false,
      checked4: false,
      checked5: false,  
      recommendchecked: false,
      recommendchecked1: false,
      recommendchecked2: false,
      recommendchecked3: false,
      recommendchecked4: false,
      recommendchecked5: false, 
      topchecked: false,
      topchecked1: false,
      topchecked2: false,
      topchecked3: false,
      topchecked4: false,
      topchecked5: false,    
      paymentisable:false,

      autorenewalnormal:0,
      autorenewaltop:0,
      autorenewalrecommend:0,

      normalShowPreDay:0,
      topShowPreDay:0,
      recommendShowPreDay:0,

      cityName:'',
      category_text:'',

      //有效期
      expireDate:'',
      normalExpireDate:'',
      topExpireDate:'',
      recommendExpireDate:'',

      //是否需要续费小图30天基础时长
      needManeyValue:0,
      expireDateOld:'',

      //数据库查出的自动续费值
      adAutoRenewNormalFromDB:'',
      adAutoRenewTopFromDB:'',
      adAutoRenewRecommendedFromDB:'',

    }
  },
  created() {
    // 获取主页给来的路由参数
    console.log('主页给来的路由参数', this.$route.query)
    let advertisementId = this.$route.query.advertisementId // 实际
    this.advertisementId = Number(advertisementId)
    let typeStr='';
    let latLng=localStorage.getItem("adlatlng")
    apiGetAllList_detail({
        advertisementId:advertisementId,
        latLng:latLng
      }).then(
      (res)=>{
        if(res.code==200){
          let data = res.data
          typeStr = data.type
          this.cityName=data.cityName
          this.category_text=data.categoryStr
          this.normalShowPreDay=data.cityData.normalShowPreDay
          this.topShowPreDay=data.cityData.topShowPreDay
          this.recommendShowPreDay=data.cityData.recommendShowPreDay
          this.maney=data.cityData.maney
          this.type=String(typeStr).split(",")

          this.expireDate=data.expireDate
          this.expireDateOld=data.expireDate
          this.normalExpireDate=data.normalExpireDate
          this.topExpireDate=data.topExpireDate
          this.recommendExpireDate=data.recommendExpireDate

          //null值处理
          if(data.autoRenewalNormal==null){
            data.autoRenewalNormal='0'
          }
          if(data.autoRenewalTop==null){
            data.autoRenewalTop='0'
          }
          if(data.autoRenewalRecommend==null){
            data.autoRenewalRecommend='0'
          }
          //展示条件用
          this.adAutoRenewNormalFromDB=data.autoRenewalNormal
          this.adAutoRenewTopFromDB=data.autoRenewalTop
          this.adAutoRenewRecommendedFromDB=data.autoRenewalRecommend

          //记录数据库用
          this.autorenewalnormal=Number(data.autoRenewalNormal)
          this.autorenewaltop=Number(data.autoRenewalTop)
          this.autorenewalrecommend=Number(data.autoRenewalRecommend)
        }
      }
    )    
    console.log('this.advertisementId' + advertisementId)
  },
  mounted() {    
  },
  computed:{
  },
  watch: {   
    totolfee(e){
      if(e){
        this.paymentisable=true
      }else{
        this.paymentisable=false
      }
    }, 
    autoRenewalNormalCancel(e){
      if(e){
        this.autorenewalnormal=0
        this.paymentisable=true
      }else{
        this.autorenewalnormal=1
        this.paymentisable=false
      }
    },
    autoRenewalTopCancel(e){
      if(e){
        this.autorenewaltop=0
        this.paymentisable=true
      }else{
        this.autorenewaltop=1
        this.paymentisable=false
      }
    },
    autoRenewalRecommendCancel(e){
      if(e){
        this.autorenewalrecommend=0
        this.paymentisable=true
      }else{
        this.autorenewalrecommend=1
        this.paymentisable=false
      }
    },
    checked(e) {
      if (e) {        
        this.totol_days_normal=1
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.checked == false &&
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.apiNeedManeyMethod()
        }        
      }
    },
    checked1(e) {
      if (e) {        
        this.totol_days_normal=5
        this.checked =false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.checked == false &&
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.apiNeedManeyMethod()
        }        
      }
    },
    checked2(e) {
      if (e) {
        this.totol_days_normal=10
        this.checked =false
        this.checked1 = false
        this.checked3 = false
        this.checked4 = false
        this.checked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.checked == false &&
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.apiNeedManeyMethod()
        }    
      }
    },
    checked3(e) {
      if (e) {
        this.totol_days_normal=20
        this.checked =false
        this.checked1 = false
        this.checked2 = false
        this.checked4 = false
        this.checked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.checked == false &&
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.apiNeedManeyMethod()
        }    
      }
    },
    checked4(e) {
      if (e) {
        this.totol_days_normal=30
        this.checked =false
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.checked == false &&
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.apiNeedManeyMethod()
        }    
      }
    },
    checked5(e) {
      if (e) {
        this.autorenewalnormal=1
        this.totol_days_normal=1
        this.checked =false
        this.checked1 = false
        this.checked2 = false
        this.checked3 = false
        this.checked4 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.checked == false &&
        this.checked1 == false &&
        this.checked2 == false &&
        this.checked3 == false &&
        this.checked4 == false &&
        this.checked5 == false){
          this.totol_days_normal=0
          this.autorenewalnormal=0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked(e) {
      if (e) {
        this.totol_days_top=1
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.topchecked == false && 
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked1(e) {
      if (e) {
        this.totol_days_top=5
        this.topchecked = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.topchecked == false && 
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked2(e) {
      if (e) {
        this.totol_days_top=10
        this.topchecked  = false
        this.topchecked1 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.topchecked == false && 
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked3(e) {
      if (e) {
        this.totol_days_top=20
        this.topchecked  = false
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.topchecked == false && 
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked4(e) {
      if (e) {
        this.totol_days_top=30
        this.topchecked  = false
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.topchecked == false && 
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked5(e) {
      if (e) {
        this.autorenewaltop=1
        this.totol_days_top=1
        this.topchecked  = false
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.topchecked == false && 
        this.topchecked1 == false && 
        this.topchecked2 == false &&
        this.topchecked3 == false &&
        this.topchecked4 == false &&
        this.topchecked5 == false
        ){
          this.totol_days_top=0
          this.autorenewaltop=0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked(e) {
      if (e) {
        this.totol_days_recommend=1
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.recommendchecked == false &&
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked1(e) {
      if (e) {
        this.totol_days_recommend=5
        this.recommendchecked = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.recommendchecked == false &&
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked2(e) {
      if (e) {
        this.totol_days_recommend=10
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.recommendchecked == false &&
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked3(e) {
      if (e) {
        this.totol_days_recommend=20
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.recommendchecked == false &&
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked4(e) {
      if (e) {
        this.totol_days_recommend=30
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.recommendchecked == false &&
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked5(e) {
      if (e) {
        this.autorenewalrecommend=1
        this.totol_days_recommend=1
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.apiNeedManeyMethod()
      }else{
        if(
        this.recommendchecked == false &&
        this.recommendchecked1 == false &&
        this.recommendchecked2 == false &&
        this.recommendchecked3 == false &&
        this.recommendchecked4 == false &&
        this.recommendchecked5 == false
        ){
          this.totol_days_recommend=0
          this.autorenewalrecommend=0
          this.apiNeedManeyMethod()
                  
        }
      }
    },
  },
  methods: {
    goBack() {
      this.$router.go(-1)
      //window.open('http://app.abcd69.com/', '_self')
    },
    showconfirm(){
      Dialog.confirm({
        title:"confirm payment",
        message:"$"+(this.totolfee)
      }).then(()=>{
        //on confirm
        console.log("payment confirm ")    
        apiBuyAdTime({
          advertisementId:this.advertisementId,
          autorenewalnormal:this.autorenewalnormal,
          autorenewaltop:this.autorenewaltop,
          autorenewalrecommend:this.autorenewalrecommend,
          totol_days_normal:this.totol_days_normal,
          totol_days_top:this.totol_days_top,
          totol_days_recommend:this.totol_days_recommend
        }).then((res)=>{
          if(res.code==200){
            this.$toast.success();
            // this.$toast.success({
            //   duration:2000,
            //   message:res.data.message,
            //   type:'success'
            // });
            this.$router.push({
              path: '/myAD',              
            })           
          }else{
            this.$toast.success("购买失败，请联系管理员！");            
          }
        }) 
      }).catch(()=>{
        //on cancle
        console.log("payment confirm cancle ")
      });
    },
    
    //当广告价格变动时，去后台计算是否需要计算小图广告基础时间30天，是否展示
    apiNeedManeyMethod(){
      apiNeedManey({
          advertisementId:this.advertisementId,
          totol_days_normal:this.totol_days_normal,
          totol_days_top:this.totol_days_top,
          totol_days_recommend:this.totol_days_recommend}).then(
            (res)=>{
              if(res.code==200){
                var needManey=res.data.needManey30
                if(needManey=='1'){
                  this.needManeyValue=this.maney
                  this.expireDate=Moment(this.expireDateOld).add(30,"days")
                }else{
                  this.needManeyValue=0
                  this.expireDate=this.expireDateOld
                }
              }else{
                this.needManeyValue=0
                this.expireDate=this.expireDateOld
              }
            }
          ).then(
            ()=>{
              this.totolfee=((this.totol_days_normal*(this.normalShowPreDay*100))
                      +(this.totol_days_top*(this.topShowPreDay*100))
                      +(this.totol_days_recommend*(this.recommendShowPreDay*100))
                      +this.needManeyValue*100)/100
            }
          )
    },
    formatDate(value){
      return Moment(value).format('DD/MM')
    },
    
  }
}
</script>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}
// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}
.msg-box {
  position: fixed;
  right: 30px;
  bottom: 30%;
  z-index: 2;

  .msg-img {
    width: 81px;
    height: 81px;
    position: relative;
  }
  .msg-pop {
    position: absolute;
    top: -700px;
    right: 30px;
    width: 645px;
    height: 694px;
    border-radius: 40px;
    background-color: #f7f7f7;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  }
  .msg-contentBox {
    position: relative;
  }
  .contentBox-header {
    font-size: 29px;
    font-weight: bold;
    color: #000000;
    height: 94px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #fff;
    border-radius: 40px 40px 0 0;
  }
  .close-icon {
    position: absolute;
    width: 26px;
    height: 26px;
    right: 40px;
  }
  .msg-body {
    background: #f7f7f7;
    padding: 20px 20px;
  }
  .avatar-img {
    width: 92px;
    height: 92px;
  }
  .msg-text {
    background: #000;
    width: 446px;
    background: #ffffff;
    box-shadow: 0px 3px 6px 1px rgba(0, 0, 0, 0.16);
    border-radius: 20px 20px 20px 20px;
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    left: 100px;
    top: 200px;
    padding: 24px;
  }
}
.swiper-img-box {
  height: 902px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
}


.upgrade-days {
    margin-top: 20px;
    padding: 28px 40px 16px;
    background: rgb(244, 244, 244);
  }
  .upgrade-days-header {
    display: flex;
    align-items: center;
    margin-bottom: 47px;
  }
  .days-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .days-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }
  .days-menu {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
  }
  .days-item {
    width: 33.3%;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  .days-text {
    height: 50px;
    // border: 1px solid #bab2b2;
    // background: #fff;
    font-size: 24px;
    font-weight: bold;
    color: #1f1a17;
    padding: 9px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 14px;
  }

  .activeDaysBg {
    border: 1px solid #273458;
    background: #273458;
    color: #fff;
  }

  .fee-text {
    font-size: 34px;
    font-weight: 400;
    color: #000000;
    text-align: center;
    margin-bottom: 55px;
    margin-top:20px;
  }
  .fee-num {
    font-size: 34px;
    font-weight: 800;
    color: #000000;
  }
  .sure-btn {
    margin: 0 auto 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    width: 408px;
    height: 90px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }

  .none{
    pointer-events:none;
    background-color: gray;
  }

  .my-table {
    border-collapse: collapse;
    width: 100%;
    text-align:center;
    border: 1px solid #273458;
  }

  .table-box {
    margin-bottom: 57px;
  }

  .my-ads-box {
    margin: 20px 0;
    padding: 24px 40px 40px;
    background: #fff;
  }
  .my-ads-header {
    display: flex;
    align-items: center;
    margin-bottom: 40px;
  }
  .my-ads-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .my-ads-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
  }

  .col1 {
    width: 25%;
    border: 1px solid #273458
  }
  .col2 {
    width: 30%;
    border: 1px solid #273458
  }
  .col3 {
    width: 45%;
    border: 1px solid #273458
  }
  .col3 {
    height: 70px;
  }
</style>
