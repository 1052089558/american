<template>
  <div class="page" >
    <div class="header">
      <van-nav-bar title="My AD" />
    </div>
    <div class="content">
      <div class="type-box">
        <div
          class="type-box-item"
          :class="{ activeTypeBg: mode == 1 }"
          @click="handleClickAD"
        >
          Actived ADs {{ releaseList.length }}
        </div>
        <div
          class="type-box-item"
          :class="{ activeTypeBg: mode == 2 }"
          @click="handleClickDF"
        >
          draft box {{ draftList.length }}
        </div>
      </div>
      <!-- Actived ADs -->
      <div v-if="mode == 1" class="active-adBox">
        <!-- <div>筛选TODO</div> -->
        <div
          class="active-item"
          v-for="(item, index) in releaseList"
          :key="index"
        >
          <div class="item-head">
            <div
              :style="{
                'font-size': 'xx-large',
                color: item.toastToday == 'Y' ? 'red' : 'black',
              }"
            >
              {{ index + 1 }}
            </div>
            <div style="padding-top: 5px; width: 55%">
              <div style="font-weight: 1000; font-size: 15px">
                {{ item.cityData.cityName }}
              </div>
              <div>{{ translateDict(item.category) }}</div>
            </div>
            <div
              style="
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                width: 30%;
              "
            >
              <img
                style="width: 120px"
                v-if="
                  item.type.indexOf('3') !== -1 &&
                  new Date(Date.parse(item.recommendExpireDate)) >
                    new Date(Date.parse(nowDate))
                "
                src="../../assets/images/myAds/recommendedAD.png"
              />
              <img
                style="width: 100px"
                v-if="
                  item.type.indexOf('2') !== -1 &&
                  new Date(Date.parse(item.topExpireDate)) >
                    new Date(Date.parse(nowDate))
                "
                src="../../assets/images/myAds/topAD.png"
              />
              <img
                style="width: 80px"
                src="../../assets/images/myAds/normalAD.png"
              />
            </div>
          </div>
          <div class="expire-time">
            <div>EXP:{{ formatDate(item.expireDate) }}</div>
            <div
              v-if="
                (item.type.indexOf('1') == -1 &&
                  item.type.indexOf('2') == -1 &&
                  item.type.indexOf('3') == -1) ||
                (item.type.indexOf('1') != -1 &&
                  new Date(Date.parse(item.normalExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('2') != -1 &&
                  new Date(Date.parse(item.topExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('3') != -1 &&
                  new Date(Date.parse(item.recommendExpireDate)) <
                    new Date(Date.parse(nowDate))) ||
                (item.type.indexOf('1') != -1 &&
                  new Date(Date.parse(item.normalExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('2') == -1 &&
                  item.type.indexOf('3') != -1 &&
                  new Date(Date.parse(item.recommendExpireDate)) <
                    new Date(Date.parse(nowDate))) ||
                (item.type.indexOf('1') != -1 &&
                  new Date(Date.parse(item.normalExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('2') == -1 &&
                  item.type.indexOf('3') == -1) ||
                (item.type.indexOf('1') != -1 &&
                  new Date(Date.parse(item.normalExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('2') != -1 &&
                  new Date(Date.parse(item.topExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('3') == -1) ||
                (item.type.indexOf('1') == -1 &&
                  item.type.indexOf('2') == -1 &&
                  item.type.indexOf('3') != -1 &&
                  new Date(Date.parse(item.recommendExpireDate)) <
                    new Date(Date.parse(nowDate))) ||
                (item.type.indexOf('1') == -1 &&
                  item.type.indexOf('2') != -1 &&
                  new Date(Date.parse(item.topExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('3') == -1) ||
                (item.type.indexOf('1') == -1 &&
                  item.type.indexOf('2') != -1 &&
                  new Date(Date.parse(item.topExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('3') != -1 &&
                  new Date(Date.parse(item.recommendExpireDate)) <
                    new Date(Date.parse(nowDate)))
              "
            >
              <p style="color: red">Show for 30 minutes every day</p>
            </div>
          </div>
          <div class="show-box">
            <div class="show-box-item1" style="position: relative">
              <img
                v-if="item.verify == 'success'"
                style="width: 70%; height: auto; position: absolute"
                src="../../assets/images/myAds/verified.png"
              />

              <img :src="item.imagesOne" alt="" />
            </div>
            <div class="show-box-item1">
              <img :src="item.imagesTwo" alt="" />
            </div>
            <div class="show-box-item1">
              <img :src="item.imagesThree" alt="" />
            </div>

            <div class="show-box-item2">
              <div class="rg-item2" @click="gotoVerify(item, index, 'release')">
                <div class="rg-item2-lf">verify</div>
                <img
                  class="rg-img2"
                  src="../../assets/images/myAds/realpersonverify.png"
                  alt=""
                />
              </div>

              <div class="rg-item2" @click="Goto_detail(item)">
                <div class="rg-item2-lf">preview</div>
                <img
                  class="rg-img2"
                  src="../../assets/images/myAds/see.png"
                  alt=""
                />
              </div>

              <div class="rg-item2" @click="Goto_replace(item)">
                <div class="rg-item2-lf">Thumbnail</div>
                <img
                  class="rg-img2"
                  style="height: auto"
                  src="../../assets/images/myAds/file-image.png"
                  alt=""
                />
              </div>
              <div
                class="rg-item2"
                @click.stop="setOptionShow($event,index)"
                style="position: relative"
              >
                <!-- @click.stop="stopOptionShow($event,index)" -->
                <div
                  ref="optionOver"
                  style="
                    position: absolute;
                    width: 100%;
                    height: 100%;
                    z-index: -1;
                    background: black;
                  "
                ></div>
                <div class="rg-item2-lf">Other</div>
                <img
                  class="rg-img2"
                  style="height: auto"
                  src="../../assets/images/home/bottom-icon-bl.png"
                  alt=""
                />
              </div>

              <van-popover
                v-model="optionShow[index]"
                placement="bottom-start"
                :offset="popoverOffSize"
              >
                <!-- trigger="click" -->
                <template>
                  <div
                    style="
                      height: 25px;
                      background: lightgrey;
                      display: flex;
                      align-items: center;
                      justify-content: space-between;
                      padding: 4px 7px;
                      box-sizing: border-box;
                      border: 1px solid #c1c1c1;
                      margin-bottom: 5px;
                    "
                    @click="goEdit(item.advertisementId, 'release')"
                  >
                    <div
                      style="font-size: 12px; font-weight: 400; color: #273458"
                    >
                      edit
                    </div>
                    <img
                      style="width: 12px; height: 8px"
                      src="../../assets/images/myAds/edit_black.png"
                      alt=""
                    />
                  </div>
                  <div
                    style="
                      height: 25px;
                      background: lightgrey;
                      display: flex;
                      align-items: center;
                      justify-content: space-between;
                      padding: 4px 8px;
                      box-sizing: border-box;
                      border: 1px solid #c1c1c1;
                      position: relative;
                    "
                    @click="deleteAd(item, index, 'release')"
                  >
                    <div
                      style="font-size: 12px; font-weight: 400; color: #273458"
                    >
                      delete
                    </div>
                    <img
                      style="width: 14px; height: auto"
                      src="../../assets/images/myAds/delete.png"
                      alt=""
                    />
                  </div>
                </template>
              </van-popover>

              <!-- <div class="rg-item3" @click="showMsgPopup(item.advertisementId)">
                <div class="rg-item3-lf">New message</div>
                <img
                  class="rg-img3"
                  src="../../assets/images/myAds/msg.png"
                  alt=""
                />
                <div class="qes-box">
                  <img
                    @click.stop="showMsgQuestionPopup"
                    class="ques-img"
                    src="../../assets/images/myAds/ques-icon.png"
                    alt=""
                  />
                </div>
              </div> -->
            </div>
          </div>
          <div class="upgrade-box">
            <!-- <div class="upgrade-lf">
              <div class="upgrade-lf-item">
                <div>Top AD</div>
                <div>
                  Expire date: <br />
                  {{ item.topExpireDate }}
                </div>
              </div>
              <div class="upgrade-lf-item">
                <div>Recommended ad</div>
                <div>
                  Expire date: <br />
                  {{ item.recommendExpireDate }}
                </div>
              </div>
            </div> -->
            <div>
              <div class="upgrade-small-box">
                <div
                  class="rg-box1"
                  :class="{
                    disabled:
                      item.category == '6' ||
                      (item.type.indexOf('2') != -1 &&
                        item.type.indexOf('3') != -1)
                        ? true
                        : '',
                  }"
                >
                  <!-- modify by xuejin test -->
                  <!-- <div
                    class="rg-box1-flex"
                    @click="handleUpgradeSelect(item, index)"
                  ></div> -->
                  <div class="rg-box1-flex" @click="Goto_upgradead(item)">
                    <div>upgrade</div>
                    <img
                      class="bottom-img"
                      src="../../assets/images/myAds/upgrade.png"
                      alt=""
                    />
                  </div>
                  <div class="rg-box-select" v-if="upgradeChecked === index">
                    <template v-if="item.type != 3">
                      <div class="upgrade-title">Top AD</div>
                      <van-radio-group v-model="topRadio">
                        <van-cell-group>
                          <van-cell
                            class="state-cell"
                            v-for="item in gainCustomersList"
                            clickable
                            :key="item.dictValue"
                            :title="item.dictLabel"
                            @click="topRadio = item.dictValue"
                          >
                            <template #right-icon>
                              <van-radio
                                icon-size="20px"
                                checked-color="#273458"
                                :name="item.dictValue"
                              />
                            </template>
                          </van-cell>
                        </van-cell-group>
                      </van-radio-group>
                    </template>
                    <template v-if="item.type != 2">
                      <div class="upgrade-title">Recommended AD</div>
                      <van-radio-group v-model="recommendedRadio">
                        <van-cell-group>
                          <van-cell
                            class="state-cell"
                            v-for="item in gainCustomersList"
                            clickable
                            :key="item.dictValue"
                            :title="item.dictLabel"
                            @click="recommendedRadio = item.dictValue"
                          >
                            <template #right-icon>
                              <van-radio
                                icon-size="20px"
                                checked-color="#273458"
                                :name="item.dictValue"
                              />
                            </template>
                          </van-cell>
                        </van-cell-group>
                      </van-radio-group>
                    </template>
                    <div class="price-box">价格{{ draftMoney }}</div>
                    -->
                    <div class="ok-btn" @click="handleUpgrade">OK</div>
                  </div>
                  <!-- <div class="qes-box">
                    <img
                      @click.stop="showUpgradeQuestionPopup"
                      class="ques-img"
                      src="../../assets/images/myAds/ques-icon.png"
                      alt=""
                    />
                  </div> -->
                </div>
                <div class="rg-box2">
                  <div class="rg-box1-flex" @click="Goto_buyadtime(item)">
                    <div>buy ads dispaly time</div>
                    <img
                      class="bottom-img"
                      src="../../assets/images/myAds/add_work_time.png"
                      alt=""
                    />
                    <!-- <img
                      @click.stop="showCustomersQuestionPopup"
                      class="bottom-img"
                      src="../../assets/images/myAds/bottom-icon.png"
                      alt=""
                    /> -->
                  </div>
                  <!-- <div
                    class="rg-box1-flex"
                    @click="handleCustomersSelect(item, index)"
                  >
                    <div>buy ads dispaly time</div>
                    <img
                      @click.stop="showCustomersQuestionPopup"
                      class="bottom-img"
                      src="../../assets/images/myAds/bottom-icon.png"
                      alt=""
                    />
                  </div> -->
                  <div class="rg-box-select" v-if="customersChecked === index">
                    <van-radio-group v-model="customersRadio">
                      <van-cell-group>
                        <van-cell
                          class="state-cell"
                          v-for="item in gainCustomersList"
                          clickable
                          :key="item.dictValue"
                          :title="item.dictLabel"
                          @click="customersRadio = item.dictValue"
                        >
                          <template #right-icon>
                            <van-radio
                              icon-size="20px"
                              checked-color="#273458"
                              :name="item.dictValue"
                            />
                          </template>
                        </van-cell>
                      </van-cell-group>
                    </van-radio-group>
                    <div class="ok-btn" @click="handleCustomers">OK</div>
                  </div>
                  <!-- <div class="qes-box">
                    <img
                      class="ques-img"
                      src="../../assets/images/myAds/ques-icon.png"
                      alt=""
                    />
                  </div> -->
                </div>
              </div>
              <!-- <div class="upgrade-text">
                  Expire date: <br />
                  {{ item.expireDate }}
                </div> -->
            </div>

            <div
              class="expire-time"
              v-if="
                item.type.indexOf('1') !== -1 &&
                new Date(Date.parse(item.normalExpireDate)) >
                  new Date(Date.parse(nowDate))
              "
            >
              <div class="expire-time-left-div">Normal AD:</div>
              <div>
                Exp:{{ formatDate(item.normalExpireDate) }} 24h show
                <span
                  :style="{
                    display: item.autoRenewalNormal == '1' ? '' : 'none',
                    color: 'red',
                  }"
                  >{{ '\u3000' }}Auto renew</span
                >
              </div>
            </div>

            <div
              class="expire-time"
              v-if="
                (item.type.indexOf('1') == -1 &&
                  item.type.indexOf('3') !== -1 &&
                  new Date(Date.parse(item.recommendExpireDate)) >
                    new Date(Date.parse(nowDate))) ||
                (item.type.indexOf('1') == -1 &&
                  item.type.indexOf('2') !== -1 &&
                  new Date(Date.parse(item.topExpireDate)) >
                    new Date(Date.parse(nowDate))) ||
                (item.type.indexOf('1') != -1 &&
                  new Date(Date.parse(item.normalExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('2') !== -1 &&
                  new Date(Date.parse(item.topExpireDate)) >
                    new Date(Date.parse(nowDate))) ||
                (item.type.indexOf('1') != -1 &&
                  new Date(Date.parse(item.normalExpireDate)) <
                    new Date(Date.parse(nowDate)) &&
                  item.type.indexOf('3') !== -1 &&
                  new Date(Date.parse(item.recommendExpireDate)) >
                    new Date(Date.parse(nowDate)))
              "
            >
              <div class="expire-time-left-div">Normal AD:</div>
              <div>
                Exp:{{ formatDate(item.expireDate)
                }}<span style="color: red"> 30 minutes every day</span>
              </div>
            </div>

            <div
              class="expire-time"
              v-if="
                item.type.indexOf('2') !== -1 &&
                new Date(Date.parse(item.topExpireDate)) >
                  new Date(Date.parse(nowDate))
              "
            >
              <div class="expire-time-left-div">Top AD :</div>
              <div>
                Exp:{{ formatDate(item.topExpireDate) }} 24h show
                <span
                  :style="{
                    display: item.autoRenewalTop == '1' ? '' : 'none',
                    color: 'red',
                  }"
                  >{{ '\u3000' }}Auto renew</span
                >
              </div>
            </div>

            <div
              class="expire-time"
              v-if="
                item.type.indexOf('3') !== -1 &&
                new Date(Date.parse(item.recommendExpireDate)) >
                  new Date(Date.parse(nowDate))
              "
            >
              <div class="expire-time-left-div">Recommended AD:</div>
              <div>
                Exp:{{ formatDate(item.recommendExpireDate) }} 24h show
                <span
                  :style="{
                    display: item.autoRenewalRecommend == '1' ? '' : 'none',
                    color: 'red',
                  }"
                  >{{ '\u3000' }}Auto renew</span
                >
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- draft box -->
      <div v-if="mode == 2" class="draft-adBox">
        <div class="draft-item" v-for="(item, index) in draftList" :key="index">
          <div class="item-head">
            <div style="font-size: xx-large">{{ index + 1 }}</div>
            <div style="width: 55%; padding-top: 5px">
              <div style="font-weight: 1000; font-size: 15px">
                {{ item.cityData.cityName }}
              </div>
              <div style="display: flex">
                <div style="width: 130px">
                  {{ translateDict(item.category) }}
                </div>
                <div>
                  <span class="ad-fee" style="padding-top: 5px"
                    >$:{{ item.advertisementMoney }}</span
                  >
                </div>
              </div>
            </div>

            <div
              style="
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                width: 30%;
              "
            >
              <img
                style="width: 120px"
                v-if="item.type.indexOf('3') !== -1"
                src="../../assets/images/myAds/recommendedAD.png"
              />
              <img
                style="width: 100px"
                v-if="item.type.indexOf('2') !== -1"
                src="../../assets/images/myAds/topAD.png"
              />
              <img
                style="width: 80px"
                src="../../assets/images/myAds/normalAD.png"
              />
            </div>
          </div>
          <div class="show-box">
            <div class="show-box-item1">
              <img :src="item.imagesOne" alt="" />
            </div>
            <div class="show-box-item1">
              <img :src="item.imagesTwo" alt="" />
            </div>
            <div class="show-box-item1">
              <img :src="item.imagesThree" alt="" />
            </div>
            <div class="show-box-item2">
              <div
                class="rg-item2"
                @click="goEdit(item.advertisementId, 'draft')"
              >
                <div class="rg-item2-lf">edit</div>
                <img
                  class="rg-img2"
                  src="../../assets/images/myAds/edit_black.png"
                  alt=""
                />
              </div>
              <div class="rg-item2" @click="Goto_detail(item)">
                <div class="rg-item2-lf">preview</div>
                <img
                  class="rg-img2"
                  src="../../assets/images/myAds/see.png"
                  alt=""
                />
              </div>
              <div class="rg-item2" @click="Goto_replace(item)">
                <div class="rg-item2-lf">Thumbnail</div>
                <img
                  class="rg-img2"
                  style="height: auto"
                  src="../../assets/images/myAds/file-image.png"
                  alt=""
                />
              </div>
              <div class="rg-item3" @click="deleteAd(item, index, 'draft')">
                <div class="rg-item3-lf">delete</div>
                <img
                  class="delete-img"
                  src="../../assets/images/myAds/delete.png"
                  alt=""
                />
              </div>
              <!-- <div class="rg-item3" @click="showMsgPopup(item.advertisementId)">
                <div class="rg-item3-lf">New message</div>
                <img
                  class="rg-img3"
                  src="../../assets/images/myAds/msg.png"
                  alt=""
                />
                <div class="qes-box">
                  <img
                    @click.stop="showMsgQuestionPopup"
                    class="ques-img"
                    src="../../assets/images/myAds/ques-icon.png"
                    alt=""
                  />
                </div>
              </div> -->
            </div>
          </div>
          <div class="upgrade-small-box1" style="justify-content: center">
            <!-- <div class="rg-box1">
              <div
                class="rg-box1-flex"
                @click="handleUpgradeSelect(item, index)"
                >
                <div>upgrade</div>
                <img
                  class="bottom-img"
                  src="../../assets/images/myAds/bottom-icon.png"
                  alt=""
                />
              </div>
              <div class="rg-box-select" v-if="upgradeChecked === index">
                <template v-if="item.type != 3">
                  <div class="upgrade-title">Top AD</div>
                  <van-radio-group v-model="topRadio">
                    <van-cell-group>
                      <van-cell
                        class="state-cell"
                        v-for="item in gainCustomersList"
                        clickable
                        :key="item.dictValue"
                        :title="item.dictLabel"
                        @click="topRadio = item.dictValue"
                      >
                        <template #right-icon>
                          <van-radio
                            icon-size="20px"
                            checked-color="#273458"
                            :name="item.dictValue"
                          />
                        </template>
                      </van-cell>
                    </van-cell-group>
                  </van-radio-group>
                </template>
                <template v-if="item.type != 2">
                  <div class="upgrade-title">Recommended AD</div>
                  <van-radio-group v-model="recommendedRadio">
                    <van-cell-group>
                      <van-cell
                        class="state-cell"
                        v-for="item in gainCustomersList"
                        clickable
                        :key="item.dictValue"
                        :title="item.dictLabel"
                        @click="recommendedRadio = item.dictValue"
                      >
                        <template #right-icon>
                          <van-radio
                            icon-size="20px"
                            checked-color="#273458"
                            :name="item.dictValue"
                          />
                        </template>
                      </van-cell>
                    </van-cell-group>
                  </van-radio-group>
                </template>
                <div class="price-box">价格{{ draftMoney }}</div>
                <div class="ok-btn" @click="handleUpgrade">OK</div>
              </div>
              <div class="qes-box">
                <img
                  @click.stop="showUpgradeQuestionPopup"
                  class="ques-img"
                  src="../../assets/images/myAds/ques-icon.png"
                  alt=""
                />
              </div>
            </div> -->

            <div class="release-box">
              <div
                class="release-btn"
                @click="
                  showReleasePopup(
                    item.advertisementId,
                    item.advertisementMoney
                  )
                "
              >
                <!-- 发布广告 -->
                Post AD
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 编辑信息弹窗 -->
    <van-popup v-model="showMsg">
      <div class="msgPopup-box">
        <div class="popup-head">New message</div>
        <img
          @click="showMsg = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">
          <van-field
            class="textareaIpt"
            v-model="remark"
            rows="7"
            type="textarea"
            placeholder="This message will pop up when the user views the advertisement
                  details."
          />
        </div>
        <div class="confirm-btn" @click="handleEditMsg">confirm</div>
      </div>
    </van-popup>

    <!-- 信息疑问号弹窗 -->
    <van-popup v-model="showMsgQuestion">
      <div class="questionPopup-box">
        <img
          @click="showMsgQuestion = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">
          {{ messagePrompt }}
        </div>
        <div class="confirm-btn" @click="showMsgQuestion = false">confirm</div>
      </div>
    </van-popup>

    <!-- 升级疑问号弹窗 -->
    <van-popup v-model="showUpgradeQuestion">
      <div class="questionPopup-box">
        <img
          @click="showUpgradeQuestion = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">
          {{ upgradePrompt }}
        </div>
        <div class="confirm-btn" @click="showUpgradeQuestion = false">
          confirm
        </div>
      </div>
    </van-popup>

    <!-- Customers疑问号弹窗 -->
    <van-popup v-model="showCustomersQuestion">
      <div class="questionPopup-box">
        <img
          @click="showCustomersQuestion = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">
          {{ customerPrompt }}
        </div>
        <div class="confirm-btn" @click="showCustomersQuestion = false">
          confirm
        </div>
      </div>
    </van-popup>

    <van-popup v-model="showReleaseBox">
      <div class="questionPopup-box">
        <img
          @click="showReleaseBox = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">${{ itemAdMoney }}</div>
        <div class="confirm-btn" @click="handleRelease">confirm</div>
      </div>
    </van-popup>

    <van-popup v-model="showToastTodayBox">
      <div class="questionPopup-box">
        <img
          @click="showToastTodayBox = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content">Red number AD expire soon!</div>
        <div class="confirm-btn" @click="showToastTodayBox = false">
          confirm
        </div>
      </div>
    </van-popup>

    <router-view />
    <van-tabbar route active-color="#027AFC" inactive-color="#666666">
      <van-tabbar-item replace to="/vip">
        <span> {{ $t('vip') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active1 : icon.inactive1" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/">
        <span> {{ $t('home') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active2 : icon.inactive2" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/postAd">
        <span> {{ $t('post AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active3 : icon.inactive3" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/myAD">
        <span> {{ $t('my AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active4 : icon.inactive4" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/personal">
        <span> {{ $t('Profile') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active5 : icon.inactive5" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
import {
  apiUpdateRemark,
  apiGetAdvertisingDraft,
  apiGetAdvertisingReleaseList,
  apiGetMessagePrompt,
  apiGetUpgradePrompt,
  apiGetCustomerPrompt,
  apiGetUpgradeSelect,
  apiAdvertisingRelease,
  apiGainCustomers,
  apiUpdateDraft,
  apiGetAdvertisementMoney,
  apiAdvertisingClassification,
  apiAdvertisingDelete,
  getStateData,
  getStataCity,
  apiGetNowDate,
} from '../../request/api'
import Moment from 'moment'
import { Toast } from 'vant'
import { Dialog } from 'vant'
import index from '@/components/vue-country-intl/schema-input/SchemaInput.vue'
export default {
  name: 'myAD',
  components: { [Dialog.name]: Dialog },
  mounted() {},
  computed: {},
  data() {
    return {
      popoverOffSize:[1],

      optionShow: [],

      active: 0,
      icon: {
        active1: require('../../assets/images/tabbar/tabbar1.png'),
        inactive1: require('../../assets/images/tabbar/tabbar2.png'),
        active2: require('../../assets/images/tabbar/tabbar3.png'),
        inactive2: require('../../assets/images/tabbar/tabbar4.png'),
        active3: require('../../assets/images/tabbar/tabbar5.png'),
        inactive3: require('../../assets/images/tabbar/tabbar6.png'),
        active4: require('../../assets/images/tabbar/tabbar7.png'),
        inactive4: require('../../assets/images/tabbar/tabbar8.png'),
        active5: require('../../assets/images/tabbar/tabbar9.png'),
        inactive5: require('../../assets/images/tabbar/tabbar10.png'),
      },
      mode: 1,
      showMsg: false,
      showMsgQuestion: false,
      showUpgradeQuestion: false,
      showCustomersQuestion: false,
      showReleaseBox: false,
      // 疑问号弹窗信息
      messagePrompt: '',
      upgradePrompt: '',
      customerPrompt: '',
      // 信息编辑数据
      remark: '',
      // 草稿列表
      draftList: [],
      // 发布列表
      releaseList: [],
      // 广告id
      advertisementId: '',
      // 升级下拉列表
      upgradeList: [],
      // 升级客户数下拉框分类
      gainCustomersList: [],
      customersChecked: -1,
      upgradeChecked: -1,
      customersRadio: '',
      type: '',
      topRadio: '',
      recommendedRadio: '',
      // 升级价钱计算
      draftMoney: '',
      classificationList: [],

      //当前选中待发布的草稿AD的广告金额
      itemAdMoney: 0,

      //显示即将到期提示框
      showToastTodayBox: false,

      nowDate: '',
    }
  },
  created() {
    let token = localStorage.getItem('key')
    if (!token) {
      this.$router.replace('/login')
    }

    //获取服务器时间
    apiGetNowDate().then((res) => {
      if (res.code == 200) {
        this.nowDate = res.msg
      }
    })

    // 获取发布列表 和 草稿列表
    this.getReleaseList()
    this.getDraftList()

    // 升级下拉列表
    apiGetUpgradeSelect().then((res) => {
      if (res.code == 200) {
        this.upgradeList = res.data
      }
    })
    apiGainCustomers().then((res) => {
      if (res.code == 200) {
        this.gainCustomersList = res.data
      }
    })
    apiAdvertisingClassification().then((res) => {
      if (res.code == 200) {
        this.classificationList = res.data
        // console.log(this.classificationList);
      }
    })
  },
  watch: {
    optionShow(oldVal, newVal) {
      this.optionShow = newVal

      // var optionOver = this.$refs.optionOver
      // console.log('this.optionShow changed:' + this.optionShow)
      // this.optionShow.forEach((item, index) => {
      //   if (item == false) {
      //     if (optionOver == undefined) {
      //       return
      //     }
      //     optionOver.forEach((item, index1) => {
      //       if (index1 == index) {
      //         setTimeout(() => {
      //           this.$refs.optionOver[index1].style.zIndex = '-1';
      //         }, 100);
      //       }
      //     })
      //   }
      // })
    },
  },
  methods: {
    // clickTag(event){
      // console.log(event.currentTarget);
	    // console.log(event.target);
    // },
    // stopOptionShow(event,index){
    //   console.log('child element click')
    //   setTimeout(() => {
    //       this.$refs.optionOver[index].style.zIndex = '-1';
    //   }, 100);
    // },
    setOptionShow(event,index) {
      // this.optionShow.forEach((item,index1)=>{
          // if(index1==index){
            this.$set(this.optionShow, index, true)
          // }else{
            // this.$set(this.optionShow, index, false)
          // }
        // }
      // )
      // this.$refs.optionOver[index].style.zIndex = '1'
    },
    gotoVerify(item) {
      this.$router.push({
        path: '/realpersonverify',
        query: {
          advertisementId: item.advertisementId,
        },
      })
    },
    formatDate(value) {
      return Moment(value).format('DD/MM HH:mm')
    },
    // 点击广告 \ 草稿
    handleClickAD() {
      this.mode = 1
      this.upgradeChecked = -1
      this.topRadio = ''
      this.recommendedRadio = ''
      this.draftMoney = ''
      this.type = ''
    },
    handleClickDF() {
      this.mode = 2
      this.upgradeChecked = -1
      this.topRadio = ''
      this.recommendedRadio = ''
      this.draftMoney = ''
      this.type = ''
    },

    // 获取发布列表
    getReleaseList() {
      apiGetAdvertisingReleaseList().then((res) => {
        if (res.code == 200) {
          this.releaseList = res.data.data
          //添加popover显示
          this.releaseList.forEach((item, index) => {
            this.optionShow.push(false)
          })

          if (res.data.toastToday == 'Y') {
            this.showToastTodayBox = true

            // this.$toast({
            //   duration: 1500,
            //   message:res.data.toastInf
            // })
          }
        }
      })
    },
    // 获取草稿列表
    getDraftList() {
      apiGetAdvertisingDraft().then((res) => {
        if (res.code == 200) {
          this.draftList = res.data
        }
      })
    },
    showMsgPopup(id) {
      this.advertisementId = id
      this.showMsg = true
    },
    showMsgQuestionPopup() {
      this.showMsgQuestion = true
    },
    showUpgradeQuestionPopup() {
      this.showUpgradeQuestion = true
    },
    showCustomersQuestionPopup() {
      this.showCustomersQuestion = true
    },
    showReleasePopup(id, itemAdMoney) {
      this.advertisementId = id
      this.itemAdMoney = itemAdMoney

      //更改弹窗效果与步骤4一致
      // this.showReleaseBox = true
      Dialog.confirm({
        title: 'confirm payment',
        message: '$' + itemAdMoney,
      })
        .then(() => {
          //on confirm
          this.handleRelease()
        })
        .catch(() => {
          //on cancle
          console.log('payment confirm cancle ')
        })
    },
    // 编辑信息
    handleEditMsg() {
      apiUpdateRemark({
        advertisementId: this.advertisementId,
        remark: this.remark,
      }).then((res) => {
        if (res.code == 200) {
          this.$toast.success(res.msg)
          this.showMsg = false
        }
      })
    },

    // Goto_detail
    Goto_detail(item) {
      this.$router.push({
        path: '/detail',
        query: {
          advertisementId: item.advertisementId,
          category: item.category,
          from: 'myad',
        },
      })
    },

    Goto_replace(item) {
      this.$router.push({
        path: '/replace',
        query: {
          advertisementId: item.advertisementId,
        },
      })
    },

    Goto_buyadtime(item) {
      this.$router.push({
        path: '/buyadtime',
        query: {
          advertisementId: item.advertisementId,
        },
      })
    },
    Goto_upgradead(item) {
      this.$router.push({
        path: '/upgrade',
        query: {
          advertisementId: item.advertisementId,
        },
      })
    },

    // 草稿发布
    handleRelease() {
      apiAdvertisingRelease({
        advertisementId: this.advertisementId,
      }).then((res) => {
        if (res.code == 200) {
          this.$toast.success(res.msg)
          this.showReleaseBox = false

          //location.reload();
          //不需要刷新页面，仅进行页面数据处理即可
          var adTmp = res.data
          var indexD = 0
          this.draftList.forEach((item, index) => {
            if (adTmp.advertisementId == item.advertisementId) {
              indexD = index
            }
          })
          this.draftList.splice(indexD, 1)
          this.releaseList.push(adTmp)
        } else {
          this.$toast.fail(res.msg)
        }
      })
    },

    // 控制CustomersSelect是否显示
    handleCustomersSelect(item, index) {
      this.advertisementId = item.advertisementId
      this.type = item.type
      if (this.customersChecked === index) {
        this.customersChecked = -1
      } else {
        this.customersChecked = index
      }
    },
    // 处理获取更多客户数
    handleCustomers() {
      apiUpdateDraft({
        advertisementId: this.advertisementId,
        type: this.type,
        perday: this.customersRadio,
      }).then((res) => {
        if (res.code == 200) {
          this.customersChecked = -1
          this.$toast.success(res.msg)
        } else {
          this.$toast.fail(res.msg)
        }
        this.getReleaseList()
      })
    },

    // 控制UpgradeSelect是否显示
    handleUpgradeSelect(item, index) {
      this.advertisementId = item.advertisementId
      this.type = item.type
      apiGetAdvertisementMoney({
        advertisementId: this.advertisementId,
      }).then((res) => {
        if (res.code == 200) {
          this.draftMoney = res.data.advertisementMoney
        }
      })
      if (this.upgradeChecked === index) {
        this.upgradeChecked = -1
      } else {
        this.upgradeChecked = index
      }
    },

    // 处理升级
    handleUpgrade() {
      apiUpdateDraft({
        advertisementId: this.advertisementId,
        type: this.type,
        perday: `${this.topRadio},${this.recommendedRadio}`,
        draftMoney: this.draftMoney,
      }).then((res) => {
        console.log(res)
        if (res.code == 200) {
          this.upgradeChecked = -1
          this.$toast.success(res.msg)
        } else {
          this.$toast.fail(res.msg)
        }
        this.getReleaseList()
        this.getDraftList()
      })
    },
    // 再次编辑
    goEdit(advertisementId, status) {
      this.$router.push({
        path: '/postAd',
        query: {
          advertisementId: advertisementId,
          status: status,
        },
      })
    },
    translateDict(item) {
      // console.log(item, "item");
      // console.log(this.classificationList, "classificationList");
      let data = ''

      this.classificationList.forEach((x) => {
        if (x.dictValue === item) {
          data = x.dictLabel
        }
      })
      // let data =
      //   this.classificationList.filter((x) => x.dictValue === item)[0]
      //     .dictLabel ?? ''
      return data
    },
    deleteAd(item, index, adStatus) {
      apiAdvertisingDelete(item.advertisementId).then((res) => {
        if (res.code === 200) {
          this.$toast.success()
          //不要刷新页面，仅操作页面list对象，去除一个对象即可
          // this.refresh();
          if (adStatus == 'release') {
            this.releaseList.splice(index, 1)
          } else {
            this.draftList.splice(index, 1)
          }
        } else {
          this.$toast.fail(res.msg)
        }
      })
      // Dialog.confirm({
      //   title: "prompt",
      //   message: "Do you want to delete?"
      // }).then(async () => {
      //   apiAdvertisingDelete(item.advertisementId).then((res) => {
      //   if (res.code === 200) {
      //     this.$toast.success(res.msg)
      //     //不要刷新页面，仅操作页面list对象，去除一个对象即可
      //     // this.refresh();
      //     if(adStatus=='release'){
      //       this.releaseList.splice(index, 1)
      //     }else{
      //       this.draftList.splice(index, 1)
      //     }

      //   } else {
      //     this.$toast.fail(res.msg)
      //   }
      // })
      // }).catch(() => {
      //   this.$toast.fail("Cancelled deletion")
      // });
    },
    refresh() {
      location.reload()
    },
  },
}
</script>

<style lang="scss" scoped>
.page {
  background: #ebebeb;
}

.content {
  margin-bottom: 120px;
}

.type-box {
  margin: 20px 0;
  display: flex;
  align-items: center;

  .type-box-item {
    width: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 84px;
    font-size: 28px;
    font-weight: 400;
    color: #273458;
    background: #fff;
  }

  .activeTypeBg {
    font-weight: bold;
    color: #ffffff;
    background: #273458;
  }
}

//
.active-adBox {
  padding-bottom: 1000px;

  .active-item {
    margin: 20px 0;
    background: #fff;
    padding: 18px 24px;
  }

  .item-head {
    margin-bottom: 13px;
    font-size: 24px;
    font-weight: 400;
    color: #232f3e;
    display: flex;
    justify-content: space-between;
  }

  .location-title {
    margin-right: 31px;
  }

  .show-box {
    margin-bottom: 23px;
    display: flex;
    align-items: center;
  }

  .show-box-item1 {
    width: 145px;
    height: 170px;
    margin-right: 12px;
  }

  .show-box-item1 img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  .show-box-item2 {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  .rg-item1 {
    height: 50px;
    background: #273458;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 15px;
    box-sizing: border-box;
    margin-bottom: 10px;
  }

  .rg-item1-lf {
    font-size: 24px;
    font-weight: 400;
    color: #ffffff;
  }

  .rg-img1 {
    width: 19px;
    height: 19px;
  }

  .rg-item2 {
    height: 50px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 15px;
    box-sizing: border-box;
    border: 1px solid #c1c1c1;
    margin-bottom: 10px;
  }

  .rg-item2-lf {
    font-size: 24px;
    font-weight: 400;
    color: #273458;
  }

  .rg-img2 {
    width: 25px;
    height: 15px;
  }

  .rg-item3 {
    height: 50px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 15px;
    box-sizing: border-box;
    border: 1px solid #c1c1c1;
    position: relative;
  }

  .qes-box {
    position: absolute;
    right: -15px;
    top: -15px;
  }

  .ques-img {
    height: 33px;
    width: 33px;
  }

  .rg-item3-lf {
    font-size: 24px;
    font-weight: 400;
    color: #273458;
  }

  .rg-img3 {
    width: 21.33px;
    height: 18.67px;
  }

  // .upgrade-box {
  // display: flex;
  // }

  .upgrade-lf-item {
    width: 351px;
    height: 120px;
    border: 1px solid #c1c1c1;
    padding: 10px;
    box-sizing: border-box;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin-bottom: 10px;
  }

  .upgrade-rg {
    flex: 1;
  }

  .upgrade-small-box {
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: center;
    /* 可选 */
  }

  .rg-box1 {
    width: 180px;
    height: 50px;
    border: 1px solid #c1c1c1;
    padding: 8px 16px;
    box-sizing: border-box;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin-bottom: 22px;
    position: relative;
  }

  .rg-box2 {
    width: 320px;
    height: 50px;
    border: 1px solid #c1c1c1;
    padding: 8px 16px;
    box-sizing: border-box;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    margin: 0px 15px;
    margin-bottom: 22px;
    position: relative;
  }

  .delete-img {
    width: 28px;
    height: auto;
  }

  .expire-time {
    display: flex;
    flex-direction: row;
    // justify-content: space-between;
    align-items: center;

    div {
      margin: 5px;
    }
  }

  .expire-time-left-div {
    width: 31%;
    text-align: end;
  }

  .rg-box1-flex {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .upgrade-title {
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin: 10px;
  }

  .rg-box-select {
    position: absolute;
    background: #fff;
    top: 50px;
    width: 257px;
    left: 0;
    right: 0;
    z-index: 1;
    box-shadow: 0px 3px 4px 1px rgba(41, 41, 41, 0.16);
  }

  .state-cell {
    box-sizing: border-box;
    padding: 20px 10px;
    overflow: hidden;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    align-items: center;
    width: 257px;
    justify-content: space-between;
  }

  .ok-btn {
    width: 227px;
    height: 40px;
    background: #273458;
    font-size: 14px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 20px auto;
  }

  .bottom-img {
    width: 28px;
    height: auto;
  }
}

//
.draft-adBox {
  padding-bottom: 1000px;

  .draft-item {
    margin: 20px 0;
    background: #fff;
    padding: 18px 24px;
  }

  .item-head {
    margin-bottom: 13px;
    font-size: 24px;
    font-weight: 400;
    color: #232f3e;
    display: flex;
    justify-content: space-between;
  }

  .location-title {
    margin-right: 31px;
  }

  .ad-fee {
    font-size: 24px;
    font-weight: bold;
    color: #000000;
  }

  .show-box {
    margin-bottom: 23px;
    display: flex;
    align-items: center;
  }

  .show-box-item1 {
    width: 145px;
    height: 170px;
    margin-right: 12px;
  }

  .show-box-item1 img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  .show-box-item2 {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  .rg-item1 {
    height: 50px;
    background: #273458;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 15px;
    box-sizing: border-box;
    margin-bottom: 10px;
  }

  .rg-item1-lf {
    font-size: 24px;
    font-weight: 400;
    color: #ffffff;
  }

  .rg-img1 {
    width: 19px;
    height: 19px;
  }

  .rg-item2 {
    height: 50px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 15px;
    box-sizing: border-box;
    border: 1px solid #c1c1c1;
    margin-bottom: 10px;
  }

  .rg-item2-lf {
    font-size: 24px;
    font-weight: 400;
    color: #273458;
  }

  .rg-img2 {
    width: 25px;
    height: 15px;
  }

  .rg-item3 {
    height: 50px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 15px;
    box-sizing: border-box;
    border: 1px solid #c1c1c1;
    position: relative;
  }

  .qes-box {
    position: absolute;
    right: -15px;
    top: -15px;
  }

  .ques-img {
    height: 33px;
    width: 33px;
  }

  .rg-item3-lf {
    font-size: 24px;
    font-weight: 400;
    color: #273458;
  }

  .rg-img3 {
    width: 21.33px;
    height: 18.67px;
  }

  .release-box {
    // margin: 30px 0 0;
    display: flex;
    align-items: center;
    justify-content: flex-end;
  }

  .release-btn {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 24px;
    font-weight: 400;
    color: #fff;
    width: 257px;
    height: 50px;
    border: 1px solid #273458;
    padding: 8px 16px;
    box-sizing: border-box;
    margin-right: 20px;
    background: #273458;
  }

  .rg-box1 {
    width: 200px;
    height: 50px;
    border: 1px solid #c1c1c1;
    padding: 8px 16px;
    box-sizing: border-box;

    font-size: 24px;
    font-weight: 400;
    color: #000000;
    position: relative;
  }

  .rg-box1-flex {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .upgrade-title {
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin: 10px;
  }

  .rg-box-select {
    position: absolute;
    background: #fff;
    top: 50px;
    width: 257px;
    left: 0;
    right: 0;
    z-index: 1;
    box-shadow: 0px 3px 4px 1px rgba(41, 41, 41, 0.16);
  }

  .state-cell {
    box-sizing: border-box;
    padding: 20px 10px;
    overflow: hidden;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    align-items: center;
    width: 257px;
    justify-content: space-between;
  }

  .ok-btn {
    width: 227px;
    height: 40px;
    background: #273458;
    font-size: 14px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 20px auto;
  }

  .bottom-img {
    width: 18px;
    height: 9.77px;
  }
  .upgrade-small-box1 {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: centerS;
  }
  .delete-img {
    width: 28px;
    height: auto;
  }
}

// 编辑消息样式
.msgPopup-box {
  width: 567px;
  background: #ffffff;

  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
  }

  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }

  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    border: 1px solid #c0c0c0;
    font-size: 22px;
    font-weight: 400;
    color: #000000;
  }

  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}

// 问号弹窗
.questionPopup-box {
  width: 567px;
  background: #ffffff;

  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }

  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .textareaIpt {
    height: 110px !important;
  }

  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}

.price-box {
  text-align: center;
  margin: 15px 0;
  font-weight: bold;
}

/* CSS代码 */
.disabled {
  pointer-events: none; /* 禁止鼠标事件 */
  opacity: 0.5; /* 设置透明度 */
}
</style>
<style lang="scss">
.van-popover {
  width: 30% !important;
}
</style>
