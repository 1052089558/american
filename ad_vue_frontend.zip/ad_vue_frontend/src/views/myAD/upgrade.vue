<template>
  <div class="page">
    <div class="header">
      <div class="header-title">Upgrade</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>

    <!-- <div class="normal-adType-box">
      <div class="type-upgrade-box" v-if="((type.indexOf('3')) == -1 )">
          <div class="upgrade-box"  @click="showRecommendSection = !showRecommendSection">Upgrade to Recommended ad</div>
          <van-checkbox
            v-model="showRecommendSection"
            icon-size="20px"
            checked-color="#273458"
          ></van-checkbox>
      </div>

      <div class="type-upgrade-box"  v-if="((type.indexOf('2')) == -1 )">
          <div class="upgrade-box" @click="showTopSection = !showTopSection">Upgrade to Top ad</div>
          <van-checkbox
            icon-size="20px"
            v-model="showTopSection"
            checked-color="#273458"
          ></van-checkbox>
      </div>
    </div> -->

    <div class="normal-adType-box">
      <div
        style="
          padding-bottom: 15px;
          font-size: larger;
          padding-left: 10px;
          font-weight: 600;
        "
        v-show="showChooseTitle == true"
      >
        Choose upgrade Ad Type
      </div>
      <div style="display: flex; justify-content: space-around">
        <div
          class="type-upgrade-box"
          v-if="type.indexOf('3') == -1"
          :style="{
            'border-color': showRecommendSection == true ? 'red' : 'black',
            'border-width': showRecommendSection == true ? 'medium' : 'thin',
          }"
        >
          <div @click="showRecommendSection = !showRecommendSection">
            <img
              style="width: 130px; height: 22px"
              src="../../assets/images/myAds/recommendedAD.png"
            />
          </div>
          <div
            class="upgradeIsCheck"
            :style="{
              display: showRecommendSection == true ? '' : 'none',
              color: 'red',
            }"
          >
            <span>√</span>
          </div>

          <van-checkbox
            style="display: none"
            v-model="showRecommendSection"
            icon-size="20px"
            checked-color="#273458"
          ></van-checkbox>
        </div>

        <div
          class="type-upgrade-box"
          v-if="type.indexOf('2') == -1"
          :style="{
            'border-color': showTopSection == true ? 'blue' : 'black',
            'border-width': showTopSection == true ? 'medium' : 'thin',
          }"
        >
          <div @click="showTopSection = !showTopSection">
            <img
              style="width: 130px; height: 22px"
              src="../../assets/images/myAds/topAD.png"
            />
          </div>

          <div
            class="upgradeIsCheck"
            :style="{
              display: showTopSection == true ? '' : 'none',
              color: 'blue',
            }"
          >
            <span>√</span>
          </div>

          <van-checkbox
            style="display: none"
            icon-size="20px"
            v-model="showTopSection"
            checked-color="#273458"
          ></van-checkbox>
        </div>
      </div>
    </div>

    <div
      class="normal-adType-box"
      :style="{ display: showRecommendSection == true ? '' : 'none' }"
    >
      <div class="rec-box" v-if="true">
        <div class="adType-header">
          <div class="ad-header-lf">
            <img
              class="ad-header-img"
              src="../../assets/images/postAd/recommendedAdShow.png"
              alt=""
            />
          </div>
          <div class="ad-header-rg">
            <div class="ad-header-rg-1">Recommended ad</div>
            <div class="ad-header-rg-2">
              Your ad will be on the homepage of the your area.All viewers will
              see it first. Highly recommended.
            </div>
          </div>
        </div>
        <div class="adType-line"></div>

        <div v-if="true">
          <div class="upload-title">Advertising cover image</div>
          <div class="upload-img-box">
            <div class="upload-container">
              <div class="upload-item-box">
                <van-loading ref="recommendImageOne_uploading" size="24px"
                  >uploading...<template>
                    <div
                      style="
                        font-size: large;
                        position: relative;
                        display: inline;
                        bottom: 20px;
                      "
                      @click="stopUploading('recommendImageOne_uploading')"
                    >
                      <span>X</span>
                    </div>
                  </template></van-loading
                >
                <CUT
                  :size_w="176"
                  :size_h="236"
                  :name="'recommendImageOne'"
                  :uploadingStop="recommendImageOne_uploading_stop"
                  @UpUrl="UpUrl"
                  @showImagesUploading="showImagesUploading"
                  @showImagesUploadingClose="showImagesUploadingClose"
                ></CUT>
                <div class="uploader-box" v-if="recommendImageOne == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="recommendImageOne = ''">
                    <span>X</span>
                  </div>
                  <img :src="recommendImageOne" alt="" />
                </div>
              </div>
              <div class="upload-item-box">
                <van-loading ref="recommendImageTwo_uploading" size="24px"
                  >uploading...<template>
                    <div
                      style="
                        font-size: large;
                        position: relative;
                        display: inline;
                        bottom: 20px;
                      "
                      @click="stopUploading('recommendImageTwo_uploading')"
                    >
                      <span>X</span>
                    </div>
                  </template></van-loading
                >
                <CUT
                  :size_w="153"
                  :size_h="112"
                  :name="'recommendImageTwo'"
                  :uploadingStop="recommendImageTwo_uploading_stop"
                  @UpUrl="UpUrl"
                  @showImagesUploading="showImagesUploading"
                  @showImagesUploadingClose="showImagesUploadingClose"
                ></CUT>
                <div class="uploader-box" v-if="recommendImageTwo == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="recommendImageTwo = ''">
                    <span>X</span>
                  </div>
                  <img :src="recommendImageTwo" alt="" />
                </div>
              </div>
              <div class="upload-item-box">
                <van-loading ref="recommendImageThree_uploading" size="24px"
                  >uploading...<template>
                    <div
                      style="
                        font-size: large;
                        position: relative;
                        display: inline;
                        bottom: 20px;
                      "
                      @click="stopUploading('recommendImageThree_uploading')"
                    >
                      <span>X</span>
                    </div>
                  </template></van-loading
                >
                <CUT
                  :size_w="153"
                  :size_h="112"
                  :name="'recommendImageThree'"
                  :uploadingStop="recommendImageThree_uploading_stop"
                  @UpUrl="UpUrl"
                  @showImagesUploading="showImagesUploading"
                  @showImagesUploadingClose="showImagesUploadingClose"
                ></CUT>
                <div class="uploader-box" v-if="recommendImageThree == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="recommendImageThree = ''">
                    <span>X</span>
                  </div>
                  <img :src="recommendImageThree" alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="big-line"></div>

      <div
        class="upgrade-days"
        :style="{ display: showRecommendSection == true ? '' : 'none' }"
      >
        <div class="upgrade-days-header">
          <div class="days-header-rg">Recommended AD time</div>
        </div>
        <div class="days-menu">
          <div
            class="days-item"
            @click="recommendchecked = !recommendchecked"
            style="width: 50%"
          >
            <div class="days-text">1 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="recommendchecked"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="recommendchecked1 = !recommendchecked1"
            style="width: 50%"
          >
            <div class="days-text">5 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="recommendchecked1"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="recommendchecked2 = !recommendchecked2"
            style="width: 50%"
          >
            <div class="days-text">10 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="recommendchecked2"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="recommendchecked3 = !recommendchecked3"
            style="width: 50%"
          >
            <div class="days-text">20 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="recommendchecked3"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="recommendchecked4 = !recommendchecked4"
            style="width: 50%"
          >
            <div class="days-text">30 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="recommendchecked4"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item last-item"
            @click="recommendchecked5 = !recommendchecked5"
            style="width: 50%"
          >
            <div class="days-text">Automatic renewal</div>
            <div class="days-btn">
              <van-checkbox
                v-model="recommendchecked5"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
        </div>
      </div>

      <div class="big-line"></div>

      <div class="total-box">
        <div class="total-box-text">
          Recommended AD {{ total_days_recommend }}Days Total $
          {{ (recommendShowPreDay * 100 * total_days_recommend) / 100 }}
        </div>
      </div>
    </div>

    <div
      class="normal-adType-box"
      :style="{ display: showTopSection == true ? '' : 'none' }"
    >
      <div class="rec-box" v-if="true">
        <div class="adType-header">
          <div class="ad-header-lf">
            <img
              class="ad-header-img"
              src="../../assets/images/postAd/topAdShow.png"
              alt=""
            />
          </div>
          <div class="ad-header-rg">
            <div class="ad-header-rg-1">Top ad</div>
            <div class="ad-header-rg-2">
              Your ad will be on the top of other normal ads,and 4 times bigger
              than normal ad.It's easy to get viewer's attention.
            </div>
            <div v-if="false" class="ad-header-rg-3">${{ maney }} per day</div>
          </div>
        </div>
        <div class="adType-line"></div>

        <div>
          <div class="upload-title">Advertising cover image</div>
          <div class="upload-img-box">
            <div
              class="upload-container"
              style="
                display: flex;
                justify-content: center;
                align-items: center;
              "
            >
              <div class="upload-item-box">
                <van-loading ref="largeImage_uploading" size="24px"
                  >uploading...<template>
                    <div
                      style="
                        font-size: large;
                        position: relative;
                        display: inline;
                        bottom: 20px;
                      "
                      @click="stopUploading('largeImage_uploading')"
                    >
                      <span>X</span>
                    </div>
                  </template></van-loading
                >
                <CUT
                  :size_w="337"
                  :size_h="266"
                  :name="'largeImage'"
                  :uploadingStop="largeImage_uploading_stop"
                  @UpUrl="UpUrl"
                  @showImagesUploading="showImagesUploading"
                  @showImagesUploadingClose="showImagesUploadingClose"
                ></CUT>
                <div class="uploader-box" v-if="largeImage == ''">
                  <img
                    class="upload-icon"
                    src="../../assets/images/postAd/upload.png"
                    alt=""
                  />
                  <div class="upload-icon-text">Click to upload pictures</div>
                </div>
                <div class="uploader-img" v-else>
                  <div class="delImg" @click="largeImage = ''">
                    <span>X</span>
                  </div>
                  <img :src="largeImage" alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="big-line"></div>

      <div
        class="upgrade-days"
        :style="{ display: showTopSection == true ? '' : 'none' }"
      >
        <div class="upgrade-days-header">
          <div class="days-header-rg">Buy ads display time</div>
        </div>
        <div class="days-menu">
          <div
            class="days-item"
            @click="topchecked = !topchecked"
            style="width: 50%"
          >
            <div class="days-text">1 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="topchecked"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="topchecked1 = !topchecked1"
            style="width: 50%"
          >
            <div class="days-text">5 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="topchecked1"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="topchecked2 = !topchecked2"
            style="width: 50%"
          >
            <div class="days-text">10 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="topchecked2"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="topchecked3 = !topchecked3"
            style="width: 50%"
          >
            <div class="days-text">20 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="topchecked3"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item"
            @click="topchecked4 = !topchecked4"
            style="width: 50%"
          >
            <div class="days-text">30 Days</div>
            <div class="days-btn">
              <van-checkbox
                v-model="topchecked4"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
          <div
            class="days-item last-item"
            @click="topchecked5 = !topchecked5"
            style="width: 50%"
          >
            <div class="days-text">Automatic renewal</div>
            <div class="days-btn">
              <van-checkbox
                v-model="topchecked5"
                checked-color="#273458"
                icon-size="20px"
              ></van-checkbox>
            </div>
          </div>
        </div>
      </div>

      <div class="big-line"></div>

      <div class="total-box">
        <div class="total-box-text">
          Top AD {{ total_days_top }}Days Total $
          {{ (topShowPreDay * 100 * total_days_top) / 100 }}
        </div>
      </div>
    </div>

    <!-- <div class="my-ads-box">
      <div class="my-ads-header">
        <div class="my-ads-header-lf"></div>
        <div class="my-ads-header-rg">我的广告</div>
      </div>
      <div class="table-box">
        <table class="my-table">
          <tr >
            <td class="col1">{{ category_text }}</td>
            <td class="col2">{{ cityName }}</td>
            <td class="col3">
              普通广告{{ needManeyValue }}/月
            </td>
          </tr>         
          <tr
            v-show="(type.indexOf('2') == -1)"
           >
            <td class="col1">{{ category_text }}</td>
            <td class="col2">{{ cityName }}</td>
            <td class="col3">
              大图广告{{ topShowPreDay * total_days_top }}/{{
                total_days_top
              }}天
            </td>
          </tr>

          <tr
            v-show="(type.indexOf('3') == -1)"
          >
            <td class="col1">{{ category_text }}</td>
            <td class="col2">{{ cityName }}</td>
            <td class="col3">
              推荐广告{{ recommendShowPreDay * total_days_recommend }}/{{
                total_days_recommend
              }}天
            </td>
          </tr>
          
        </table>
      </div>
    </div> -->

    <div class="my-ads-box">
      <div class="my-ads-header">
        <div class="my-ads-header-lf"></div>
        <div class="my-ads-header-rg">My AD</div>
      </div>
      <div class="table-box">
        <table class="my-table">
          <tr>
            <td class="col1">Ad type</td>
            <td class="col2">AD Display time</td>
            <td class="col3">Price</td>
          </tr>

          <tr v-show="needManeyValue > 0">
            <td class="col1">Normal AD</td>
            <td class="col2">Exp:{{ formatDate(expireDate) }}</td>
            <td class="col3">${{ needManeyValue }}</td>
          </tr>

          <tr v-show="showTopSection == true">
            <td class="col1">Top AD</td>
            <td class="col2">{{ total_days_top }} Days</td>
            <td class="col3">
              ${{ (topShowPreDay * 100 * total_days_top) / 100 }}
            </td>
          </tr>

          <tr v-show="showRecommendSection == true">
            <td class="col1">Recommended AD</td>
            <td class="col2">{{ total_days_recommend }} Days</td>
            <td class="col3">
              ${{ (recommendShowPreDay * 100 * total_days_recommend) / 100 }}
            </td>
          </tr>
        </table>
      </div>
    </div>

    <div class="fee-text">
      Total：$ <span class="fee-num">{{ totalfee }}</span>
    </div>
    <div
      class="sure-btn"
      @click="showconfirm"
      :class="{ none: !paymentisable }"
    >
      payment
    </div>
  </div>
</template>

<script>
import {
  getCityDetails,
  apiUpgradeAd,
  apiGetAllList_detail,
  apiNeedManey,
} from '../../request/api'
import { Toast } from 'vant'
import Moment from 'moment'
// 富文本
import Editor from '@tinymce/tinymce-vue'
import CUT from '../postAd/Cut.vue'
import { Dialog } from 'vant'
export default {
  name: 'upgrade',
  components: { 'tinymce-editor': Editor, CUT },
  data() {
    return {
      advertisementId: 0,

      largeImage: '',
      largeImage_uploading_stop: false,
      recommendImageOne: '',
      recommendImageOne_uploading_stop: false,
      recommendImageTwo: '',
      recommendImageTwo_uploading_stop: false,
      recommendImageThree: '',
      recommendImageThree_uploading_stop: false,

      city_list_select_ad: [],
      showRecommendSection: false,
      showTopSection: false,

      showChooseTitle: false,

      dept_list_select_total_days: 0,
      cityid: 0,
      recommendchecked: false,
      recommendchecked1: false,
      recommendchecked2: false,
      recommendchecked3: false,
      recommendchecked4: false,
      recommendchecked5: false,
      topchecked: false,
      topchecked1: false,
      topchecked2: false,
      topchecked3: false,
      topchecked4: false,
      topchecked5: false,
      autorenewaltop: 0,
      autorenewalrecommend: 0,
      totalfee: 0,

      total_days_top: 0,
      total_days_recommend: 0,
      paymentisable: false,

      topShowPreDay: 0,
      recommendShowPreDay: 0,

      type: [],
      maney: 0,
      needManeyValue: 0,

      cityName: '',
      category_text: '',
      expireDate: '',
      expireDateOld: '',
    }
  },
  created() {
    // 获取主页给来的路由参数
    console.log('主页给来的路由参数', this.$route.query)
    let advertisementId = this.$route.query.advertisementId // 实际
    this.advertisementId = Number(advertisementId)
    let typeStr = ''
    let latLng = localStorage.getItem('adlatlng')
    apiGetAllList_detail({
      advertisementId: advertisementId,
      latLng: latLng,
    }).then((res) => {
      if (res.code == 200) {
        let data = res.data
        typeStr = data.type
        this.normalShowPreDay = data.cityData.normalShowPreDay
        this.topShowPreDay = data.cityData.topShowPreDay
        this.recommendShowPreDay = data.cityData.recommendShowPreDay
        this.type = String(typeStr).split(',')

        if (this.type.indexOf('3') == -1) {
          this.showRecommendSection = true
        }
        if (this.type.indexOf('2') == -1) {
          this.showTopSection = true
        }

        if (this.type.indexOf('2') == -1 && this.type.indexOf('3') == -1) {
          this.showChooseTitle = true
        }

        this.maney = data.cityData.maney

        this.cityName = data.cityName
        this.category_text = data.categoryStr

        this.expireDate = data.expireDate
        this.expireDateOld = data.expireDate
      }
    })

    getCityDetails({
      cityId: this.cityid,
    }).then((res) => {
      if (res.code == 200) {
        this.city_list_select_ad.push(res.data)
      }
    })
  },
  mounted() {},
  watch: {
    showTopSection(e) {
      if (e) {
        this.showTopSection = true
      } else {
        if (this.showRecommendSection == false) {
          this.$toast.fail('至少选择一项')
          this.showTopSection = true
        }
        //清除topAD天数设置
        this.topchecked = false
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.total_days_top = 0
        this.autorenewaltop = 0
      }
    },
    showRecommendSection(e) {
      if (e) {
        this.showRecommendSection = true
      } else {
        if (this.showTopSection == false) {
          this.$toast.fail('至少选择一项')
          this.showRecommendSection = true
        }
        //清除recommendAD天数设置
        this.total_days_recommend = 0
        this.autorenewalrecommend = 0
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
      }
    },
    totalfee(e) {
      if (e) {
        this.paymentisable = true
      } else {
        this.paymentisable = false
      }
    },
    topchecked(e) {
      if (e) {
        this.total_days_top = 1
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.topchecked == false &&
          this.topchecked1 == false &&
          this.topchecked2 == false &&
          this.topchecked3 == false &&
          this.topchecked4 == false &&
          this.topchecked5 == false
        ) {
          this.total_days_top = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked1(e) {
      if (e) {
        this.total_days_top = 5
        this.topchecked = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.topchecked == false &&
          this.topchecked1 == false &&
          this.topchecked2 == false &&
          this.topchecked3 == false &&
          this.topchecked4 == false &&
          this.topchecked5 == false
        ) {
          this.total_days_top = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked2(e) {
      if (e) {
        this.total_days_top = 10
        this.topchecked = false
        this.topchecked1 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.topchecked == false &&
          this.topchecked1 == false &&
          this.topchecked2 == false &&
          this.topchecked3 == false &&
          this.topchecked4 == false &&
          this.topchecked5 == false
        ) {
          this.total_days_top = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked3(e) {
      if (e) {
        this.total_days_top = 20
        this.topchecked = false
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked4 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.topchecked == false &&
          this.topchecked1 == false &&
          this.topchecked2 == false &&
          this.topchecked3 == false &&
          this.topchecked4 == false &&
          this.topchecked5 == false
        ) {
          this.total_days_top = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked4(e) {
      if (e) {
        this.total_days_top = 30
        this.topchecked = false
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.topchecked == false &&
          this.topchecked1 == false &&
          this.topchecked2 == false &&
          this.topchecked3 == false &&
          this.topchecked4 == false &&
          this.topchecked5 == false
        ) {
          this.total_days_top = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    topchecked5(e) {
      if (e) {
        this.autorenewaltop = 1
        this.total_days_top = 1
        this.topchecked = false
        this.topchecked1 = false
        this.topchecked2 = false
        this.topchecked3 = false
        this.topchecked4 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.topchecked == false &&
          this.topchecked1 == false &&
          this.topchecked2 == false &&
          this.topchecked3 == false &&
          this.topchecked4 == false &&
          this.topchecked5 == false
        ) {
          this.total_days_top = 0
          this.autorenewaltop = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked(e) {
      if (e) {
        this.total_days_recommend = 1
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.recommendchecked == false &&
          this.recommendchecked1 == false &&
          this.recommendchecked2 == false &&
          this.recommendchecked3 == false &&
          this.recommendchecked4 == false &&
          this.recommendchecked5 == false
        ) {
          this.total_days_recommend = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked1(e) {
      if (e) {
        this.total_days_recommend = 5
        this.recommendchecked = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.recommendchecked == false &&
          this.recommendchecked1 == false &&
          this.recommendchecked2 == false &&
          this.recommendchecked3 == false &&
          this.recommendchecked4 == false &&
          this.recommendchecked5 == false
        ) {
          this.total_days_recommend = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked2(e) {
      if (e) {
        this.total_days_recommend = 10
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.recommendchecked == false &&
          this.recommendchecked1 == false &&
          this.recommendchecked2 == false &&
          this.recommendchecked3 == false &&
          this.recommendchecked4 == false &&
          this.recommendchecked5 == false
        ) {
          this.total_days_recommend = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked3(e) {
      if (e) {
        this.total_days_recommend = 20
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked4 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.recommendchecked == false &&
          this.recommendchecked1 == false &&
          this.recommendchecked2 == false &&
          this.recommendchecked3 == false &&
          this.recommendchecked4 == false &&
          this.recommendchecked5 == false
        ) {
          this.total_days_recommend = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked4(e) {
      if (e) {
        this.total_days_recommend = 30
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked5 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.recommendchecked == false &&
          this.recommendchecked1 == false &&
          this.recommendchecked2 == false &&
          this.recommendchecked3 == false &&
          this.recommendchecked4 == false &&
          this.recommendchecked5 == false
        ) {
          this.total_days_recommend = 0
          this.apiNeedManeyMethod()
        }
      }
    },
    recommendchecked5(e) {
      if (e) {
        this.autorenewalrecommend = 1
        this.total_days_recommend = 1
        this.recommendchecked = false
        this.recommendchecked1 = false
        this.recommendchecked2 = false
        this.recommendchecked3 = false
        this.recommendchecked4 = false
        this.apiNeedManeyMethod()
      } else {
        if (
          this.recommendchecked == false &&
          this.recommendchecked1 == false &&
          this.recommendchecked2 == false &&
          this.recommendchecked3 == false &&
          this.recommendchecked4 == false &&
          this.recommendchecked5 == false
        ) {
          this.total_days_recommend = 0
          this.autorenewalrecommend = 0
          this.apiNeedManeyMethod()
        }
      }
    },
  },
  methods: {
    stopUploading(name) {
      console.log('stopUploading...')
      if (name == 'recommendImageOne_uploading') {
        this.$refs.recommendImageOne_uploading.style.display = 'none'
        this.recommendImageOne_uploading_stop = true
      } else if (name == 'recommendImageTwo_uploading') {
        this.$refs.recommendImageTwo_uploading.style.display = 'none'
        this.recommendImageTwo_uploading_stop = true
      } else if (name == 'recommendImageThree_uploading') {
        this.$refs.recommendImageThree_uploading.style.display = 'none'
        this.recommendImageThree_uploading_stop = true
      } else if (name == 'largeImage_uploading') {
        this.$refs.largeImage_uploading.style.display = 'none'
        this.largeImage_uploading_stop = true
      } else if (name == 'images_one_uploading') {
        this.$refs.images_one_uploading.style.display = 'none'
        this.images_one_uploading_stop = true
      } else if (name == 'images_two_uploading') {
        this.$refs.images_two_uploading.style.display = 'none'
        this.images_two_uploading_stop = true
      } else if (name == 'images_three_uploading') {
        this.$refs.images_three_uploading.style.display = 'none'
        this.images_three_uploading_stop = true
      } else if (name == 'images_four_uploading') {
        this.$refs.images_four_uploading.style.display = 'none'
        this.images_four_uploading_stop = true
      } else if (name == 'images_five_uploading') {
        this.$refs.images_five_uploading.style.display = 'none'
        this.images_five_uploading_stop = true
      } else if (name == 'images_six_uploading') {
        this.$refs.images_six_uploading.style.display = 'none'
        this.images_six_uploading_stop = true
      } else if (name == 'images_seven_uploading') {
        this.$refs.images_seven_uploading.style.display = 'none'
        this.images_seven_uploading_stop = true
      } else if (name == 'images_eight_uploading') {
        this.$refs.images_eight_uploading.style.display = 'none'
        this.images_eight_uploading_stop = true
      } else if (name == 'images_nine_uploading') {
        this.$refs.images_nine_uploading.style.display = 'none'
        this.images_nine_uploading_stop = true
      }
    },
    showconfirm() {
      Dialog.confirm({
        title: 'confirm payment',
        message: '$' + this.totalfee,
      })
        .then(() => {
          if (this.showRecommendSection) {
            if (
              !this.recommendImageOne ||
              !this.recommendImageTwo ||
              !this.recommendImageThree ||
              this.total_days_recommend == 0
            ) {
              Toast('Must upload three images and choose one!')
              return
            }
          }

          if (this.showTopSection) {
            if (!this.largeImage || this.total_days_top == 0) {
              Toast('Must upload large images and choose one!')
              return
            }
          }

          //on confirm
          console.log('payment confirm ')
          apiUpgradeAd({
            advertisementId: this.advertisementId,
            autorenewaltop: this.autorenewaltop,
            autorenewalrecommend: this.autorenewalrecommend,
            total_days_top: this.total_days_top,
            total_days_recommend: this.total_days_recommend,
            upRecommend:
              this.showRecommendSection && this.total_days_recommend > 0,
            upTop: this.showTopSection && this.total_days_top > 0,
            largeImage: this.largeImage,
            recommendImageOne: this.recommendImageOne,
            recommendImageTwo: this.recommendImageTwo,
            recommendImageThree: this.recommendImageThree,
          }).then((res) => {
            if (res.code == 200) {
              this.$toast.success()
              // this.$toast.success({
              //   duration: 2000,
              //   message: res.data.message,
              //   type: "success",
              // });
              this.$router.push({
                path: '/myAD',
              })
            } else {
              this.$toast.success('购买失败，请联系管理员！')
            }
          })
        })
        .catch(() => {
          //on cancle
          console.log('payment confirm cancle ')
        })
    },
    goBack() {
      this.$router.go(-1)
    },
    UpUrl(data) {
      console.log(data)
      if (data.name == 'recommendImageOne') {
        this.recommendImageOne = data.url
      } else if (data.name == 'recommendImageTwo') {
        this.recommendImageTwo = data.url
      } else if (data.name == 'recommendImageThree') {
        this.recommendImageThree = data.url
      } else if (data.name == 'largeImage') {
        this.largeImage = data.url
      } else if (data.name == 'images_one') {
        this.images_one = data.url
      }
    },
    showImagesUploading(data) {
      console.log(data)
      if (data.name == 'recommendImageOne') {
        this.$refs.recommendImageOne_uploading.style.display = 'block'
      } else if (data.name == 'recommendImageTwo') {
        this.$refs.recommendImageTwo_uploading.style.display = 'block'
      } else if (data.name == 'recommendImageThree') {
        this.$refs.recommendImageThree_uploading.style.display = 'block'
      } else if (data.name == 'largeImage') {
        this.$refs.largeImage_uploading.style.display = 'block'
      } else if (data.name == 'images_one') {
        this.$refs.images_one_uploading.style.display = 'block'
      } else if (data.name == 'images_two') {
        this.$refs.images_two_uploading.style.display = 'block'
      } else if (data.name == 'images_three') {
        this.$refs.images_three_uploading.style.display = 'block'
      }
    },
    showImagesUploadingClose(data) {
      console.log(data)
      if (data.name == 'recommendImageOne') {
        this.$refs.recommendImageOne_uploading.style.display = 'none'
      } else if (data.name == 'recommendImageTwo') {
        this.$refs.recommendImageTwo_uploading.style.display = 'none'
      } else if (data.name == 'recommendImageThree') {
        this.$refs.recommendImageThree_uploading.style.display = 'none'
      } else if (data.name == 'largeImage') {
        this.$refs.largeImage_uploading.style.display = 'none'
      } else if (data.name == 'images_one') {
        this.$refs.images_one_uploading.style.display = 'none'
      } else if (data.name == 'images_two') {
        this.$refs.images_two_uploading.style.display = 'none'
      } else if (data.name == 'images_three') {
        this.$refs.images_three_uploading.style.display = 'none'
      }
    },
    //当广告价格变动时，去后台计算是否需要计算小图广告基础时间30天，是否展示
    apiNeedManeyMethod() {
      apiNeedManey({
        advertisementId: this.advertisementId,
        totol_days_normal: 0,
        totol_days_top: this.total_days_top,
        totol_days_recommend: this.total_days_recommend,
      })
        .then((res) => {
          if (res.code == 200) {
            var needManey = res.data.needManey30
            if (needManey == '1') {
              this.needManeyValue = this.maney
              this.expireDate = Moment(this.expireDateOld).add(30, 'days')
            } else {
              this.needManeyValue = 0
              this.expireDate = this.expireDateOld
            }
          } else {
            this.needManeyValue = 0
            this.expireDate = this.expireDateOld
          }
        })
        .then(() => {
          this.totalfee =
            (this.total_days_top * (this.topShowPreDay * 100) +
              this.total_days_recommend * (this.recommendShowPreDay * 100) +
              this.needManeyValue * 100) /
            100
        })
    },
    formatDate(value) {
      return Moment(value).format('DD/MM')
    },
  },
}
</script>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}

.normal-adType-box {
  margin-top: 20px;
  padding: 30px 20px;
  background: #fff;
  .adType-header {
    display: flex;
  }
  .ad-header-lf {
    margin-right: 20px;
  }
  .ad-header-img {
    width: 220px;
    height: 406px;
  }
  .rg {
    flex: 1;
    position: relative;
  }
  .ad-header-rg-1 {
    font-size: 30px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 15px;
  }
  .ad-header-rg-2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    margin-bottom: 60px;
    color: #000000;
  }
  .ad-header-rg-3 {
    font-size: 26px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }
  .adType-line {
    height: 0px;
    margin: 30px 0;
    opacity: 0.23;
    border: 1px solid #707070;
  }
  .type-upgrade-box {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 40px;
    width: 40%;
    border: 1px solid #000;
    border-radius: 10px;
    padding: 10px;
  }
  .upgrade-box {
    height: 70px;
    background: #273458;
    width: 90%;
    font-size: 28px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 30px;
  }
  .price-box {
    border: 1px solid #707070;
    height: 70px;
    display: flex;
    align-items: center;
  }
  .price-box-1 {
    width: 26%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .price-box-2 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #707070;
    height: 70px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    border-right: 1px solid #707070;
  }
  .price-box-3 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .price-box-two {
    border-top: none;
  }
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
    text-align: center;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.normal-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.big-line {
  height: 0px;
  opacity: 1;
  border: 1px solid #707070;
  // margin: 50px 0;
  width: 100%;
}

.upgrade-days {
  margin-top: 20px;
  padding: 28px 40px 16px;
  background: white;
}
.upgrade-days-header {
  display: flex;
  align-items: center;
  margin-bottom: 47px;
}
.days-header-lf {
  width: 4px;
  height: 34px;
  background: #273458;
  margin-right: 20px;
}
.days-header-rg {
  font-size: 28px;
  font-weight: bold;
  color: #000000;
  width: 100%;
  text-align: center;
}
.days-menu {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}
.days-item {
  width: 33.3%;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
}
.days-text {
  height: 50px;
  // border: 1px solid #bab2b2;
  // background: #fff;
  font-size: 24px;
  font-weight: bold;
  color: #1f1a17;
  padding: 9px 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 14px;
}

.activeDaysBg {
  border: 1px solid #273458;
  background: #273458;
  color: #fff;
}

.fee-text {
  font-size: 34px;
  font-weight: 400;
  color: #000000;
  text-align: center;
  margin-bottom: 55px;
  margin-top: 20px;
}
.fee-num {
  font-size: 34px;
  font-weight: 800;
  color: #000000;
}
.sure-btn {
  margin: 0 auto 25px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-weight: bold;
  color: #ffffff;
  width: 408px;
  height: 90px;
  background: #273458;
  box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
}

.none {
  pointer-events: none;
  background-color: gray;
}

.total-box {
  margin: 20px 0;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}
.total-box-text {
  // background: #273458;
  // color: #fff;
  font-size: 24px;
  font-weight: bold;
  padding: 10px 20px;
  min-width: 140px;
  text-align: center;
}

.my-table {
  border-collapse: collapse;
  width: 100%;
  text-align: center;
  border: 1px solid #273458;
}

.table-box {
  margin-bottom: 57px;
}

.my-ads-box {
  margin: 20px 0;
  padding: 24px 40px 40px;
  background: #fff;
}
.my-ads-header {
  display: flex;
  align-items: center;
  margin-bottom: 40px;
}
.my-ads-header-lf {
  width: 4px;
  height: 34px;
  background: #273458;
  margin-right: 20px;
}
.my-ads-header-rg {
  font-size: 28px;
  font-weight: bold;
  color: #000000;
}

.col1 {
  width: 35%;
  border: 1px solid #273458;
}
.col2 {
  width: 30%;
  border: 1px solid #273458;
}
.col3 {
  width: 45%;
  border: 1px solid #273458;
}
.col3 {
  height: 70px;
}

.page {
  background: #ebebeb;
  padding-bottom: 240px;
}

.delImg {
  position: absolute;
  left: 80%;
  width: 20%;
  font-size: large;
  z-index: 2;
}

.uploader-img {
  width: 100%;
  height: 100%;
}

.upgradeIsCheck {
  position: relative;
  top: 10px;
  left: 7px;
  font-size: large;
  font-weight: 900;
}

:deep(.van-loading) {
  position: absolute;
  width: 100%;
  height: 100%;
  background: white;
  z-index: 1;
  line-height: 204px;
  display: none;
  text-align: center;
}
</style>
