<template>
  <div class="page mask" v-if="show">
    <div class="header">
      <div class="header-title">Upgrade</div>
      <div class="close-box" v-on:click="close">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>
    
    <div class="normal-adType-box">
      <div class="type-upgrade-box">
        <div class="upgrade-box"  @click="showRecommendSection = !showRecommendSection">Upgrade to Recommended ad</div>
          <van-checkbox
            v-model="showRecommendSection"
            icon-size="20px"
            checked-color="#273458"
          ></van-checkbox>
      </div>

      <div class="type-upgrade-box">
        <div class="upgrade-box" @click="showTopSection = !showTopSection">Upgrade to Top ad</div>
          <van-checkbox
            icon-size="20px"
            v-model="showTopSection"
            checked-color="#273458"
          ></van-checkbox>
      </div>
    </div>

    <div class="sure-btn" @click="showconfirm" :class="{ none: !paymentisable }">
      confirm 
    </div>

  </div>
</template>

<script>
import {
} from '../../request/api'
export default {
  name: 'upgradedialog',
  props:{
    upgradeadid:{},
    show:{},
  },
  data() {
    return {
      advertisementId:upgradeadid,      
      showRecommendSection:true,
      showTopSection:true,
      paymentisable:false,
    }
  },
  created() {
// 获取主页给来的路由参数
console.log('主页给来的路由参数', this.$route.query)
    let category = this.$route.query.category
    let maney = this.$route.query.maney
    // let type = this.$route.query.type
    let city = this.$route.query.city
    let advertisementId = this.$route.query.advertisementId // 实际
    this.advertisementId = Number(advertisementId)
    this.maney = Number(maney)
    this.cityid=Number(city)
    // this.type=String(type).split(",")
    console.log('this.advertisementId' + advertisementId)
    // let advertisementId = 1;
    if (category == '5' || category == '8') {
      this.homepageDetail = false
      this.storeDetail = true
    }    

    
  },
  mounted() {    
  },
  watch: {   
    showTopSection(e){
      if(e){
        this.showTopSection=true
        this.paymentisable=true
      }else{
        if(this.showRecommendSection==false){
          this.$toast.fail("至少选择一项");
          this.showTopSection=true
        }
      }
    },
    showRecommendSection(e){      
      if(e){
        this.showRecommendSection=true
        this.paymentisable=true
      }else{
        if(this.showTopSection==false){
          this.$toast.fail("至少选择一项");
          this.showRecommendSection=true
        }
      }
    },    
  },
  methods: {      
    close() {
        this.$emit('close');
    },
    confirmClick() {
        this.$emit('close');
    }
    
  }
}
</script>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}

.normal-adType-box {
  margin-top: 20px;
  padding: 30px 20px;
  background: #fff;
  .adType-header {
    display: flex;
  }
  .ad-header-lf {
    margin-right: 20px;
  }
  .ad-header-img {
    width: 280px;
    height: 280px;
  }
  .rg {
    flex: 1;
    position: relative;
  }
  .ad-header-rg-1 {
    font-size: 30px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 15px;
  }
  .ad-header-rg-2 {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    margin-bottom: 60px;
    color: #000000;
  }
  .ad-header-rg-3 {
    font-size: 26px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }
  .adType-line {
    height: 0px;
    margin: 30px 0;
    opacity: 0.23;
    border: 1px solid #707070;
  }
  .type-upgrade-box {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 40px;
  }
  .upgrade-box {
    height: 70px;
    background: #273458;
    width: 90%;
    font-size: 28px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 30px;
  }
  .price-box {
    border: 1px solid #707070;
    height: 70px;
    display: flex;
    align-items: center;
  }
  .price-box-1 {
    width: 26%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
  }
  .price-box-2 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 1px solid #707070;
    height: 70px;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    border-right: 1px solid #707070;
  }
  .price-box-3 {
    width: 37%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
  }
  .price-box-two {
    border-top: none;
  }
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
    text-align: center;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.normal-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 359px;
    border: 1px solid #e2e2e2;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.big-line {
  height: 0px;
  opacity: 1;
  border: 1px solid #707070;
  // margin: 50px 0;
  width: 100%;
}


.upgrade-days {
    margin-top: 20px;
    padding: 28px 40px 16px;
    background: rgb(244, 244, 244);
  }
  .upgrade-days-header {
    display: flex;
    align-items: center;
    margin-bottom: 47px;
  }
  .days-header-lf {
    width: 4px;
    height: 34px;
    background: #273458;
    margin-right: 20px;
  }
  .days-header-rg {
    font-size: 28px;
    font-weight: bold;
    color: #000000;
    width: 100%;
    text-align: center;
  }
  .days-menu {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
  }
  .days-item {
    width: 33.3%;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  .days-text {
    height: 50px;
    // border: 1px solid #bab2b2;
    // background: #fff;
    font-size: 24px;
    font-weight: bold;
    color: #1f1a17;
    padding: 9px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 14px;
  }

  .activeDaysBg {
    border: 1px solid #273458;
    background: #273458;
    color: #fff;
  }

  .fee-text {
    font-size: 34px;
    font-weight: 400;
    color: #000000;
    text-align: center;
    margin-bottom: 55px;
    margin-top:20px;
  }
  .fee-num {
    font-size: 34px;
    font-weight: 800;
    color: #000000;
  }
  .sure-btn {
    margin: 0 auto 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    width: 408px;
    height: 90px;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }

  .none{
    pointer-events:none;
    background-color: gray;
  }

  .total-box {
    margin: 20px 0;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
  }
  .total-box-text {
    // background: #273458;
    // color: #fff;
    font-size: 24px;
    font-weight: bold;
    padding: 10px 20px;
    min-width: 140px;
    text-align: center;
  }

  /* 遮罩层*/
.mask {
    background-color: rgba(0,0,0,0.4);
    /* 使用固定定位让元素撑满全屏 */
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 9999;
}
</style>
