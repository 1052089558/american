<template>
  <div class="page">
    <div class="header">
      <div class="header-title">real preson verify</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>
    <div class="content" v-if="verifyStatus == '' || verifyStatus == 'fail'">
      <div class="normal-upload-box">
        <div class="text-area-box" style="height:200px;">
          Shoot the specified video content and upload it to abcd69. The person
          appearing in the video must have the same facial features as the
          uploaded advertising picture to complete the real-person
          authentication of the advertisement, otherwise the real-person
          authentication will fail.
          <br /><br />
          Require
          <br /><br />
          <span
            >Narration in the video: I am verified by the real escort at
            ABCD69.com.
          </span>
        </div>
      </div>
      <!-- 增加视频上传 -->
      <div class="normal-upload-box">
        <div class="upload-title">video</div>
        <!-- <div class="upload-info">
              Naked videos& genitalia are NOT ALLOWED. This includes topless
              video. <br />
              Max.video length is 20 sec or 10MB. This only uploads video files.
            </div> -->
        <div class="text-area-box">
          <van-loading ref="videos_one_uploading" size="24px" text-size="large"
            >uploading...
            <template>
              <div
                style="
                  font-size: large;
                  position: relative;
                  display: inline;
                  bottom: 20px;
                "
                @click="stopUploading('videos_one_uploading')"
              >
                <span>X</span>
              </div>
            </template>
          </van-loading>
          <van-uploader
            :after-read="uploadVideoFunc"
            accept="video/*"
            :max-size="50 * 1024 * 1024"
            @oversize="onOversize"
          >
            <div class="uploader-box" v-if="videos_one == ''">
              <img
                class="upload-icon"
                src="../../assets/images/postAd/upload.png"
                alt=""
              />
              <div class="upload-icon-text">Click to upload video</div>
            </div>
            <div class="uploader-img" v-else>
              <div
                class="delImg"
                style="
                  left: 85%;
                  z-index: 3;
                  text-align: center;
                  font-size: xx-large;
                "
                @click="videos_one = ''"
              >
                <span>X</span>
              </div>
              <video :src="videos_one" controls>
                <source src="movie.mp4" type="video/mp4" />
                <source src="movie.ogg" type="video/ogg" />
                <source src="movie.webm" type="video/webm" />
                <object data="movie.mp4">
                  <embed src="movie.swf" />
                </object>
              </video>
            </div>
          </van-uploader>
        </div>
      </div>

      <div class="confirm-btn" @click="gotoverify">Confirm</div>
    </div>

    <div
      class="content"
      v-if="verifyStatus == 'success' || verifyStatus == 'verifying'"
    >
      <div class="normal-upload-box">
        <div class="text-area-box" v-if="verifyStatus == 'success'">
          Verification successful.
        </div>

        <div class="text-area-box" v-if="verifyStatus == 'verifying'">
          Verifying...
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { apiUpload, apigotoverify, apigetverifyDetail } from '../../request/api'
import Swiper from 'swiper'
import 'swiper/css/swiper.css'
import { Dialog } from 'vant'
import { Toast } from 'vant'
import Moment from 'moment'
export default {
  name: 'realpersonverify',
  data() {
    return {
      videos_one: '',
      videos_one_uploading_stop: false,
      adId: '',
      verifyStatus: '',
    }
  },
  created() {
    this.adId = this.$route.query.advertisementId
    //获取当前AD最新认证状态
    apigetverifyDetail({
      adId: this.adId,
    }).then((res) => {
      if (res.code == 200) {
        this.verifyStatus = res.data.status
        if (this.verifyStatus == 'fail') {
          Toast.fail('Verification failed, please verify again')
        }
      }
    })
  },
  mounted() {},
  computed: {},
  watch: {},
  methods: {
    stopUploading(name) {
      console.log('stopUploading...')
      if (name == 'videos_one_uploading') {
        this.$refs.videos_one_uploading.style.display = 'none'
        this.videos_one_uploading_stop = true
      }
    },
    gotoverify() {
      apigotoverify({
        adId: this.adId,
        videoUrl: this.videos_one,
      }).then((res) => {
        if (res.code == 200) {
          Toast.success()
          Dialog.alert({
            title: 'Toast',
            message:
              'Certification information has been submitted, please wait for review',
          }).then(() => {
            // on close
            this.$router.push({ path: '/myAD' })
          })
        } else {
          Toast.fail(res.msg)
        }
      })
    },
    onOversize(file) {
      console.log(file)
      Toast('文件大小不能超过 50MB')
    },
    uploadVideoFunc(file) {
      const formData = new FormData()
      formData.append('file', file.file)
      this.$refs.videos_one_uploading.style.display = 'block'
      apiUpload(formData).then((res) => {
        if (this.videos_one_uploading_stop) {
          this.videos_one_uploading_stop = false
          return
        }

        if (res.code == 200) {
          this.videos_one = res.url
          this.$refs.videos_one_uploading.style.display = 'none'
        }
      })
    },
    goBack() {
      this.$router.go(-1)
    },
  },
}
</script>

<style lang="scss" scoped>
.header {
  height: 100px;
  background: #273458;
  position: relative;
  .header-title {
    font-size: 36px;
    font-weight: 800;
    color: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100px;
  }
  .close-box {
    position: absolute;
    height: 100px;
    right: 30px;
    top: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .close-img {
    height: 40px;
    width: 40px;
  }
}
:deep(.van-loading) {
  position: absolute;
  width: 100%;
  height: 100%;
  background: white;
  z-index: 1;
  line-height: 204px;
  display: none;
  text-align: center;
}

.page {
  background: #ebebeb;
  padding-bottom: 240px;
}
.content {
  padding: 0 24px;
  margin-bottom: 120px;

  position: relative;
  align-items: center;
  display: flex;
  flex-direction: column;
}

.normal-upload-box {
  margin-top: 30px;
  padding: 30px 20px;
  background: #fff;
  width: -webkit-fill-available;
  .upload-title {
    font-size: 28px;
    font-family: PingFang SC-Bold, PingFang SC;
    font-weight: bold;
    color: #000000;
    margin-bottom: 22px;
  }
  .upload-info {
    font-size: 24px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #000000;
    margin-bottom: 8px;
  }
  .upload-img-box {
    margin: 40px 0;
  }
  .upload-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .upload-item-box {
    border: 1px solid #707070;
    width: calc(33.3% - 22px);
    height: 204px;
    margin-bottom: 22px;
    position: relative;
  }
  .text-area-box {
    margin: 20px 0;
    height: 600px;
    border: 1px solid #e2e2e2;
    position: relative;
  }
  .uploader-box {
    text-align: center;
  }
  .upload-icon {
    width: 35.58px;
    height: 30px;
    margin: 40px 0 20px;
  }
  .upload-icon-text {
    font-size: 22px;
    font-family: PingFang SC-Regular, PingFang SC;
    font-weight: 400;
    color: #888888;
  }
  .uploader-img video {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
:deep(.van-uploader) {
  width: 100%;
  height: 100%;
}
:deep(.van-uploader__wrapper) {
  width: 100%;
  height: 100%;
}
:deep(.van-uploader__input-wrapper) {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.confirm-btn {
  margin: 21px 35px 35px;
  height: 70px;
  width: 50%;
  font-size: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  color: #ffffff;
  background: #273458;
  box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
}

.delImg {
  position: absolute;
  left: 80%;
  width: 20%;
  font-size: large;
  z-index: 2;
}

video {
  max-width: 100%;
  position: relative;
  max-height: 500px;
  z-index: 2;
}
</style>
