<template>
  <div class="page">
    <div class="header">
      <div class="header-title">Personal introduction</div>
      <div class="close-box" @click="goBack">
        <img
          class="close-img"
          src="../../assets/images//home/close.png"
          alt=""
        />
      </div>
    </div>
    <v-touch
      @swipeleft="onSwipeLeft()"
      @swiperight="onSwipeRight()"
      :swipe-options="{ direction: 'horizontal' }"
      style="touch-action: pan-y !important"
    >
      <div class="content">
        <div class="headerImgBox" v-if="videosOneShow" v-cloak>
          <video :src="vipDetail.videosOne" controls>
            <source src="movie.mp4" type="video/mp4" />
            <!--兼容IE9 、Chrome和Safari-->
            <source src="movie.ogg" type="video/ogg" />
            <!--兼容Firefox、Opera和Chrome-->
            <source src="movie.webm" type="video/webm" />
            <!--兼容Firefox、Opera和Chrome-->
            <object data="movie.mp4">
              <embed src="movie.swf" />
            </object>
          </video>
        </div>

        <div class="headerImgBox">
          <img class="my-swipe-img" :src="vipDetail.imagesOne" alt="" />
          <!-- <div class="header-img-text">{{ vipDetail.advertisementName }}</div> -->
        </div>

        <div class="box2" v-if="vipDetail.advertisementRemarkOne != ''">
          <div class="text-header">{{ vipDetail.advertisementTitleOne }}</div>
          <div class="text-p2" v-html="vipDetail.advertisementRemarkOne"></div>
        </div>

        <div class="layout">
          <div class="layout-1" v-if="vipDetail.imagesTwo">
            <img :src="vipDetail.imagesTwo" alt="" />
          </div>
          <div class="layout-1" v-if="vipDetail.imagesThree">
            <img :src="vipDetail.imagesThree" alt="" />
          </div>
          <div class="layout-2">
            <div class="layout-lf" v-if="vipDetail.imagesFour">
              <img :src="vipDetail.imagesFour" alt="" />
            </div>
            <div class="layout-rg" v-if="vipDetail.imagesFive">
              <img :src="vipDetail.imagesFive" alt="" />
            </div>
          </div>
          <div class="layout-1" v-if="vipDetail.imagesSix">
            <img :src="vipDetail.imagesSix" alt="" />
          </div>
          <div class="layout-3" v-if="vipDetail.imagesSeven">
            <img :src="vipDetail.imagesSeven" alt="" />
          </div>
        </div>

        <div class="box2" v-if="vipDetail.advertisementRemarkTwo != ''">
          <div class="text-header">{{ vipDetail.advertisementTitleTwo }}</div>
          <div class="text-p2" v-html="vipDetail.advertisementRemarkTwo"></div>
        </div>

        <div class="layout-1 pad-20" v-if="vipDetail.imagesEight">
          <img :src="vipDetail.imagesEight" alt="" />
        </div>
        <div class="layout-1 pad-20" v-if="vipDetail.imagesNine">
          <img :src="vipDetail.imagesNine" alt="" />
        </div>

        <div class="box2" v-if="vipDetail.advertisementRemarkThree != ''">
          <div class="text-header">{{ vipDetail.advertisementTitleThree }}</div>
          <div
            class="text-p2"
            v-html="vipDetail.advertisementRemarkThree"
          ></div>
        </div>
      </div>

      <div
        @click="showReport = true"
        style="
          text-align: right;
          padding-right: 20px;
          position: relative;
          top: -10px;
          height: 20px;
          display: flex;
          align-items: center;
          flex-direction: row-reverse;
        "
      >
        <img style="height: 20px" src="../../assets/images/vip/report.png" />
        <div>report</div>
      </div>
      <van-popup v-model="showReport">
        <div style="border: 1px solid #707070; margin: 10px; padding: 8px">
          <div class="popup-box">
            <div
              @click="showReport = false"
              style="position: absolute; right: 15px; top: 20px; z-index: 1"
            >
              <img
                style="height: 20px"
                src="../../assets/images/home/close-bl.png"
              />
            </div>
            <div
              class="popup-head"
              style="border-bottom: 0px; font-size: x-large"
            >
              report
            </div>
            <div
              style="
                margin-bottom: 10px;
                margin-top: 10px;
                font-size: initial;
                margin-left: 10px;
                font-weight: 600;
              "
            >
              <span style="color: red"> * </span>choose one report type:
            </div>
            <van-checkbox-group v-model="report_type" :max="1" icon-size="20px">
              <van-checkbox name="deceptive">deceptive</van-checkbox>
              <van-checkbox name="underage">underage</van-checkbox>
              <van-checkbox name="bloody">bloody</van-checkbox>
            </van-checkbox-group>

            <div
              style="
                margin-bottom: 10px;
                margin-top: 10px;
                font-size: initial;
                margin-left: 10px;
                font-weight: 600;
              "
            >
              Your email
            </div>
            <van-field
              v-model="contactEmail"
              label="contact email"
              placeholder="contact_email"
            >
            </van-field>
            <div
              style="
                margin-bottom: 10px;
                margin-top: 10px;
                font-size: initial;
                margin-left: 10px;
                font-weight: 600;
              "
            >
              Event history
            </div>
            <van-field
              v-model="reportContent"
              rows="6"
              autosize
              label="report content"
              type="textarea"
              placeholder="please input content"
            />

            <div
              style="
                display: flex;
                align-items: center;
                justify-content: center;
              "
            >
              <div
                class="confirm-btn"
                style="width: 50%; border-radius: 10px"
                @click="reportSubmit"
              >
                Confirm Reporting
              </div>
            </div>
          </div>
        </div>
      </van-popup>

      <!-- 姓名 电话 邮箱 -->
      <div class="detail-info">
        <div class="detail-info-head" style="padding-bottom: 20px">
          <div class="info-head-lf">
            <span class="info-head-name">{{
              vipDetail.advertisementName
            }}</span>
            <!-- <span class="info-head-kli" v-if="vipDetail.miles!=0">{{ vipDetail.miles }}mi </span> -->
          </div>
          <div
            class="info-head-rg"
            v-if="vipDetail.phoneAreaCode != undefined"
            v-cloak
          >
            <div class="info-head-pho" v-if="vipDetail.phoneNumber != ''">
              {{ '+' + vipDetail.phoneAreaCode + vipDetail.phoneNumber }}
            </div>
            <img
              v-if="vipDetail.phoneNumber != ''"
              @click="showContactPopup"
              class="phone-img"
              src="../../assets/images/home/phone.png"
              alt=""
            />
            <img
              @click="showShare = true"
              class="phone-img"
              src="../../assets/images/share.png"
              alt=""
            />
          </div>
        </div>

        <div class="detail-info-content">
          <div
            class="info-content-item"
            v-if="vipDetail.cityData != null && vipDetail.cityData != ''"
          >
            <div class="info-content-item-lf">Location</div>
            <div class="info-content-item-rg">
              {{ vipDetail.cityData.cityName }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.gender != null && vipDetail.gender != ''"
          >
            <div class="info-content-item-lf">Gender</div>
            <div class="info-content-item-rg">
              {{ vipDetail.gender }}
            </div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.age != null && vipDetail.age != ''"
          >
            <div class="info-content-item-lf">Age</div>
            <div class="info-content-item-rg">{{ vipDetail.age }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.race != null && vipDetail.race != ''"
          >
            <div class="info-content-item-lf">Ethnicity</div>
            <div class="info-content-item-rg">{{ vipDetail.race }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.breastSize != null && vipDetail.breastSize != ''"
          >
            <div class="info-content-item-lf">Breast size</div>
            <div class="info-content-item-rg">{{ vipDetail.breastSize }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.weight != null && vipDetail.weight != ''"
          >
            <div class="info-content-item-lf">Weight</div>
            <div class="info-content-item-rg">{{ vipDetail.weight }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.height != null && vipDetail.height != ''"
          >
            <div class="info-content-item-lf">Height</div>
            <div class="info-content-item-rg">{{ vipDetail.height }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.hairLength != null && vipDetail.hairLength != ''"
          >
            <div class="info-content-item-lf">Hair lengh</div>
            <div class="info-content-item-rg">{{ vipDetail.hairLength }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.hairColor != null && vipDetail.hairColor != ''"
          >
            <div class="info-content-item-lf">Hair color</div>
            <div class="info-content-item-rg">{{ vipDetail.hairColor }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.eyeColor != null && vipDetail.eyeColor != ''"
          >
            <div class="info-content-item-lf">Eye color</div>
            <div class="info-content-item-rg">{{ vipDetail.eyeColor }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.travel != null && vipDetail.travel != ''"
          >
            <div class="info-content-item-lf">Travel</div>
            <div class="info-content-item-rg">{{ vipDetail.travel }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.provide != null && vipDetail.provide != ''"
          >
            <div class="info-content-item-lf">Provide</div>
            <div class="info-content-item-rg">{{ vipDetail.provide }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.available != null && vipDetail.available != ''"
          >
            <div class="info-content-item-lf">Available TO</div>
            <div class="info-content-item-rg">{{ vipDetail.available }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.independent != null && vipDetail.independent != ''"
          >
            <div class="info-content-item-lf">Independent</div>
            <div class="info-content-item-rg">{{ vipDetail.independent }}</div>
          </div>
          <div
            class="info-content-item"
            v-if="vipDetail.email != null && vipDetail.email != ''"
          >
            <div class="info-content-item-lf">Email</div>
            <div class="info-content-item-rg">
              <div>{{ vipDetail.email }}</div>
              <div>
                <img
                  @click="copyEmail(vipDetail.email)"
                  class="phone-img"
                  src="../../assets/images/home/email.png"
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </v-touch>

    <van-popup v-model="showContact">
      <div class="popup-box">
        <div class="popup-head">phone number</div>
        <img
          @click="showContact = false"
          class="close-icon"
          src="../../assets/images/close-icon.png"
          alt=""
        />
        <div class="content" style="height: auto">
          {{ '+' + vipDetail.phoneAreaCode + vipDetail.phoneNumber }}
        </div>
        <div style="display: flex">
          <div class="confirm-btn" style="margin-right: 10px">
            <a :href="'tel:+' + vipDetail.phoneAreaCode + vipDetail.phoneNumber"
              >Call phone
            </a>
          </div>
          <div class="confirm-btn">
            <a
              :href="'sms:+' + vipDetail.phoneAreaCode + vipDetail.phoneNumber"
              @click="infoClick($event)"
              >text
            </a>
          </div>
        </div>
      </div>
    </van-popup>

    <van-share-sheet
      v-model="showShare"
      title="Share with friends now"
      :options="shareOptions"
      @select="onShareSelect"
    />
  </div>
</template>

<script>
import { Toast } from 'vant'
import {
  apiVipDetail,
  apiGetAllList_detail,
  apiVipList,
  apiSysReportAdd,
  getInvitationAddress,
  apiRecodeShareNum
} from '../../request/api'
export default {
  name: 'vipDetails',
  components: {},
  data() {
    return {
      invitationCode: '',
      //分享标志位
      showShare: false,
      shareOptions: [{ id: 1, name: 'copy link', icon: 'link' }],

      //举报弹窗
      reportType: '',
      reportContent: '',
      contactEmail: '',
      validcontactEmail: false,
      report_type: [],
      showReport: false,

      videosOneShow: false,
      videosOne: '',
      advertisementId: null,
      vipDetail: {},
      email: '',
      phoneNumber: '',
      city: 25,
      pageNum: '',
      pageSize: '',
      langeuage: '',
      adVipList: [],
      advertisementIds: [],
      currentIndex: null,
      showContact: false,
      vipPageNum: 1,
      vipPageSize: 40,
    }
  },
  created() {
    this.advertisementId = Number(this.$route.query.adid)
    this.vipPageNum = this.$route.query.vipPageNum
    this.vipPageSize = this.$route.query.vipPageSize
    this.city = Number(this.$route.query.city)

    this.invitationCode = this.$route.query.invitationCode
    if (this.invitationCode != undefined) {
      getInvitationAddress({ invitationCode: this.invitationCode }).then(
        (res) => {
          if (res.code == 200) {
            console.log('invitation code get success')
          }
        }
      )
    }

    this.getVipDetail()

    apiVipList({
      city: this.city,
      pageNumAd: this.vipPageNum,
      pageSizeAd: this.vipPageSize,
      langeuage: this.langeuage,
    }).then((res) => {
      if (res.code == 200) {
        this.adVipList = res.rows
        this.adVipList.forEach((ad) => {
          this.advertisementIds.push(ad.advertisementId)
        })
        // this.advertisementId = this.advertisementIds[0];
      }
    })
  },
  watch: {
    report_type(e) {
      if (e.length == 1) {
        this.reportType = this.report_type[0]
      } else {
        this.reportType = ''
      }
    },
    contactEmail(value) {
      if (!this.emailRegex.test(value)) {
        this.validcontactEmail = false
      } else {
        this.validcontactEmail = true
      }
    },
  },
  computed: {
    emailRegex() {
      return /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/
    },
  },
  mounted() {},
  methods: {
    onShareSelect(shareOption) {
      if (shareOption.id == 1) {
        var url =
          'American professional escort platform, enter to view escorts near you: https://www.abcd69.com/vipDetails?adid=' +
          this.advertisementId
        var codeTmp = localStorage.getItem('invitationCode')
        if (codeTmp != 'undefined') {
          url = url + '&invitationCode=' + codeTmp
        }
        this.$copyText(url).then(
          (e) => {
            //记录分享次数
            if(codeTmp!="undefined"){
              apiRecodeShareNum({invitationCode:codeTmp}).then(res=>{
                if(res.code==200){
                  console.log("RecodeShareNum ok")
                }
              })
            }
            this.$toast.success('ok')
          },
          (err) => {
            this.$toast.fail('fail')
          }
        )
      }
    },
    reportSubmit() {
      // 参数校验
      if (this.reportType == '') {
        Toast.fail('please select report type.')
        return
      }

      if (this.reportType == 'deceptive') {
        if (this.contactEmail == '' || this.reportContent == '') {
          Toast.fail('if you choose deceptive type,please input report info.')
          return
        }
        // if(!this.validcontactEmail){
        //   Toast.fail("please input correct email.")
        //   this.showReport=true
        //   return;
        // }
      }

      apiSysReportAdd({
        type: this.reportType,
        contactEmail: this.contactEmail,
        content: this.reportContent,
        adId: this.advertisementId,
      }).then((res) => {
        if (res.code == 200) {
          Toast.success()
          this.showReport = false
        } else {
          Toast.fail('report fail,Please contact administrator')
        }
      })
    },
    infoClick(e) {
      // 触发手机自带发短信,上面的代码只适用于Android，当为ios时需要将上面的?改为&
      var u = navigator.userAgent
      var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1 //android终端
      var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) //ios终端
      if (isiOS) {
        var hr = e.target.getAttribute('href')
        hr = hr.replace('?', '&')
        e.target.setAttribute('href', hr)
      }
    },

    showContactPopup() {
      this.showContact = true
    },
    goBack() {
      this.$router.push({
        path: '/vip',
        query: {
          vipPageNum: this.vipPageNum,
          city: this.city,
        },
      })
    },
    copyEmail(email) {
      this.$copyText(email).then(
        (e) => {
          this.$toast.success('copy email success')
        },
        (err) => {
          this.$toast.fail('copy email fail')
        }
      )
    },
    copyPhoneNumber(data) {
      this.$copyText(data).then(
        (e) => {
          this.$toast.success('ok')
        },
        (err) => {
          this.$toast.fail('fail')
        }
      )
    },
    getVipDetail() {
      apiGetAllList_detail({
        advertisementId: this.advertisementId,
      }).then((res) => {
        if (res.code == 200) {
          console.log(res)
          this.vipDetail = res.data

          //控制是否显示视频区域
          if (this.vipDetail.videosOne != '') {
            this.videosOneShow = true
          }

          this.email = res.data.email
          this.phoneNumber = res.data.phoneNumber
        }
      })
    },
    onSwipeLeft() {
      console.log('左滑')
      const index = this.advertisementIds.indexOf(this.advertisementId)
      console.log(index)
      if (index < this.advertisementIds.length - 1) {
        this.currentIndex = index + 1
        this.advertisementId = this.advertisementIds[this.currentIndex]
        this.getVipDetail()
      } else {
        console.log('没有更多的广告了')
      }
    },
    onSwipeRight() {
      console.log('右滑')
      const index = this.advertisementIds.indexOf(this.advertisementId)
      console.log(index)
      if (index > 0) {
        this.currentIndex = index - 1
        this.advertisementId = this.advertisementIds[this.currentIndex]
        this.getVipDetail()
      } else {
        console.log('没有更多的广告了')
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.page {
  background: #f0f0f0;
  .header {
    height: 100px;
    background: #273458;
    position: relative;
    .header-title {
      font-size: 36px;
      font-weight: 800;
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100px;
    }
    .close-box {
      position: absolute;
      height: 100px;
      right: 30px;
      top: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .close-img {
      height: 40px;
      width: 40px;
    }
  }
}
.content {
  .headerImgBox {
    // padding: 0 24px;
    position: relative;
  }
  .header-img {
    width: 100%;
    height: auto;
  }
  .header-img-text {
    position: absolute;
    left: 63px;
    bottom: 60px;
    font-size: 90px;
    font-weight: 500;
    color: #ffffff;
  }
  .box1 {
    padding: 40px 60px;
  }
  .text-p1 {
    font-size: 28px;
    font-weight: 400;
    color: #000000;
  }
  .box2 {
    background: #f8f8f8;
    padding: 20px;
    margin-top: 15px;
    margin-bottom: 15px;
  }
  .text-header {
    font-size: 40px;
    font-weight: 500;
    color: #0e0e0e;
    margin-bottom: 36px;
    margin-top: 16px;
  }
  .text-p2 {
    font-size: 33px;
    font-weight: 400;
    margin-bottom: 36px;
    color: #000000;
  }
  .box3 {
    padding: 40px 60px;
  }
  .box4 {
    padding: 40px 20px;
  }
}

.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    margin: 21px 35px 35px;
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}

.detail-info-content {
  padding: 0 24px;
  margin: 0 0 40px;
  .info-content-item {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .info-content-item-lf {
    width: 200px;
    height: 70px;
    background: #273458;
    font-size: 26px;
    font-weight: 500;
    color: #ffffff;
    padding-left: 20px;
    display: flex;
    align-items: center;
  }
  .info-content-item-rg {
    flex: 1;
    height: 70px;
    background: #f3f3f3;
    font-size: 24px;
    font-weight: 500;
    color: #232f3e;
    padding-left: 30px;
    display: flex;
    align-items: center;
    position: relative;
    justify-content:space-between;
  }
  .copy-btn {
    position: absolute;
    right: 0;
    height: 70px;
    width: 104px;
    font-size: 24px;
    font-weight: 400;
    color: #000000;
    background: #e5e5e5;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
.layout-1 {
  margin-bottom: 20px;
}
.layout-1 img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.pad-20 {
  padding: 0 24px;
}
.layout {
  padding: 0 24px;
  .layout-1 {
    margin-bottom: 20px;
  }
  .layout-1 img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  .layout-2 {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  .layout-lf {
    width: 50%;
    margin-right: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .layout-rg {
    width: 50%;
    margin-left: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .layout-lf img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  .layout-rg img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  .layout-3 img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}
.my-swipe-img {
  width: 100%;
  height: auto;
}

// 弹窗样式
.popup-box {
  width: 567px;
  background: #ffffff;
  .popup-head {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    font-weight: 400;
    color: #232f3e;
    border-bottom: 1px solid #707070;
  }
  .close-icon {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 35px;
    height: 35px;
  }
  .content {
    margin: 21px 35px;
    padding: 15px;
    height: 247px;
    background: #ffffff;
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .confirm-btn {
    height: 70px;
    width: 498px;
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: #ffffff;
    background: #273458;
    box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
  }
}

.detail-info {
  padding: 24px;
  .detail-info-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .info-head-name {
    font-size: 40px;
    font-weight: bold;
    color: #232f3e;
    margin-right: 6px;
  }
  .info-head-rg {
    display: flex;
    align-items: center;
  }
  .info-head-pho {
    font-size: large;
    font-weight: 600;
    margin-right: 30px;
    color: #273458;
  }

  .phone-img {
    width: 54px;
    margin-right: 30px;
    height: 54px;
  }

  .info-head-kli {
    font-size: 24px;
    font-weight: 500;
    color: #232f3e;
  }
  .info-head-rg {
    display: flex;
    align-items: center;
  }
}

video {
  width: 100%;
  position: relative;
  height: auto;
  z-index: 2;
}
</style>
<style scoped>
[v-cloak] {
  display: none !important;
}

:deep(.van-field__label) {
  width: auto;
  display: none;
}

:deep(.van-cell) {
  font-size: initial;
  border: 1px solid #707070;
}

:deep(.van-checkbox__label) {
  font-size: initial;
}

:deep(.van-checkbox-group) {
  margin-bottom: 10px;
  margin-top: 10px;
  display: flex;
}

:deep(.van-checkbox) {
  padding-left: 10px;
  height: 45px;
}

.big-line {
  height: 0px;
  opacity: 1;
  border: 3px solid #d5d1d1;
  margin: 25px 0;
}

:deep(.van-share-sheet__icon) {
  width: 100px;
  height: 100px;
}

:deep(.van-share-sheet__name) {
  font-size: large;
}

:deep(.van-share-sheet__title) {
  font-size: large;
}
</style>
