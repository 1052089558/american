<template>
  <div class="page">
    <titleBar></titleBar>
    <div class="content">
      <div class="swiper-img-box">
        <van-swipe
          class="my-swipe"
          :autoplay="3000"
          indicator-color="#232f3e"
          :loop="false"
        >
          <van-swipe-item>
            <img
              class="swipe-item-img"
              src="../../assets/images/vip/vip.png"
              alt=""
            />
          </van-swipe-item>
          <!-- <van-swipe-item v-for="item in rotationList" :key="item.id">
            <img class="swipe-item-img" :src="item.images" alt="" />
          </van-swipe-item> -->
        </van-swipe>
      </div>
      <div class="location-box">
        <div class="area-flex-box" @click="showLocationBox = !showLocationBox">
          <div class="area-box-lf">
            {{ country }}{{ cityName ? '/' + cityName : '' }}
          </div>
          <div class="area-box-rg">
            <img
              class="bottom-icon-bl-img"
              src="../../assets/images/home/bottom-icon-bl.png"
              alt=""
            />
          </div>
        </div>
        <van-popup
          v-model="showLocationBox"
          style="height: 80%"
          round
          position="bottom"
          :lock-scroll="false"
        >
          <div
            style="
              text-align: center;
              margin-bottom: 5px;
              margin-top: 5px;
              font-size: large;
              background-color: #273458;
              color: #fff;
              height: 5%;
              line-height: initial;
              font-weight: 600;
            "
            @click="reset()"
          >
            Reset
          </div>

          <van-cascader
            :closeable="false"
            v-model="cityName"
            class="cascaderClass"
            title="Please select your region"
            active-color="#0000FF"
            swipeable="true"
            placeholder="Please select"
            @finish="onFinish"
            :options="stateList"
            @close="closeCascader"
            :field-names="fieldNames"
          />
        </van-popup>
        <!-- 下拉选择框 -->
        <!-- <div class="location-select-box" v-if="showLocationBox">
          <div class="search-box">
            <van-field
              class="location-ipt"
              v-model="searchWord"
              right-icon="warning-o"
              placeholder="State of California"
            >
              <template #right-icon>
                <img
                  class="search-icon"
                  src="../../assets/images/home/search-icon.png"
                  @click="searchClick"
                  alt=""
                />
              </template>
            </van-field>
          </div>
          <div class="location-list">
            <div class="location-state" v-if="showStateBox">
              <div class="location-list-box">
                <van-radio-group v-model="city">
                  <van-cell-group>
                    <van-cell
                      class="state-cell"
                      v-for="item in stateList"
                      clickable
                      :key="item.cityId"
                      :title="item.cityName"
                    >
                      <template #right-icon>
                        <span style="margin-right: 30px;">{{item.advertisementNumber}}</span>
                        <van-radio
                          icon-size="20px"
                          shape="square"
                          checked-color="#273458"
                          :name="item.cityId"
                          @click="handleCity(item)"
                        />
                      </template>
                    </van-cell>
                  </van-cell-group>
                </van-radio-group>
              </div>
            </div>
          </div>
        </div> -->
      </div>
      <div class="title" v-if="advertisementCountData.advertisementNumber > 0">
        {{ advertisementCountData.advertisementNumber }} ads in
        {{ advertisementCountData.cityName }}
      </div>
      <div class="img-box">
        <div
          class="img-box-item"
          :class="{ activeBg: isActive === index }"
          @click="goDetails(item.advertisementId)"
          v-for="(item, index) in adVipList"
          :key="index"
        >
          <div class="img-bigBox">
            <img
              v-if="item.verify == 'success'"
              style="
                width: 60%;
                height: auto;
                position: absolute;
                top: 1px;
                left: 1px;
              "
              src="../../assets/images/myAds/verified.png"
            />
            <img class="img-box-img" :src="item.imagesOne" alt="" />
          </div>

          <div class="img-text">
            <span class="img-text-p">{{ item.advertisementName }}</span>
            <span>{{ item.age }}</span>
          </div>
        </div>
      </div>
      <div class="pagination" style="text-align: center">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="vipTablePage.pageNum"
          :page-size="vipTablePage.pageSize"
          :page-sizes="pageSizes"
          :total="vipTablePage.total"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
          :key="vipCurrentPage"
        />
      </div>
    </div>

    <!-- <div id="recaptchaDiv"  :style="{ display: showRecaptcha == true ? '' : 'none' }">  
        <div class="g-recaptcha" data-size="compact" :data-sitekey="recaptchaSiteKey" data-callback="onRecaptchaCallback"></div>
        <br/>    
    </div> -->

    <div
      id="recaptchaDiv"
      :style="{ display: showRecaptcha == true ? 'flex' : 'none' }"
      style="flex-direction: column"
    >
      <img :src="codeUrl" @click="getCode" class="login-code-img" />
      <br />
      <div style="display: flex; flex-direction: column; align-items: center">
        <van-field
          label="verify code :"
          clearable
          v-model="code"
          placeholder="Please enter the result"
        ></van-field>
        <br />

        <div class="confirm-btn" @click="verifyCode">Confirm</div>
      </div>
    </div>

    <router-view />
    <van-tabbar route active-color="#027AFC" inactive-color="#666666">
      <van-tabbar-item replace to="/vip">
        <span> {{ $t('vip') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active1 : icon.inactive1" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/">
        <span> {{ $t('home') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active2 : icon.inactive2" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/postAd">
        <span> {{ $t('post AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active3 : icon.inactive3" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/myAD" v-if="tokenKey">
        <span> {{ $t('my AD') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active4 : icon.inactive4" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item replace to="/personal" v-if="tokenKey">
        <span> {{ $t('Profile') }} </span>
        <template #icon="props">
          <img :src="props.active ? icon.active5 : icon.inactive5" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
import { Col, Toast } from 'vant'
import titleBar from '../../components/titleBar.vue'

import {
  apiVipList,
  // apiRotationList,
  apiGetAdvertisementCount,
  getCityDetails,
  getStateData,
  listCity,
  apiGetUserCityByIp,
  apiRecaptchaed,
  getCodeImg,
  apiVerifyCode,
} from '../../request/api'
export default {
  name: 'vip',
  components: { titleBar },
  data() {
    return {
      recaptchaSize: 'normal', // Replace with your preferred size
      recaptchaTheme: 'light', // Replace with your preferred theme
      recaptchaLanguage: 'en', // Replace with your preferred language
      showRecaptcha: false,
      recaptchaSiteKey: '6LcAO0ooAAAAANLDgssJDvE_auLZG1ao9xm7cJne', // Replace with your site key
      recaptchaResponse: null,

      active: 0,
      icon: {
        active1: require('../../assets/images/tabbar/tabbar1.png'),
        inactive1: require('../../assets/images/tabbar/tabbar2.png'),
        active2: require('../../assets/images/tabbar/tabbar3.png'),
        inactive2: require('../../assets/images/tabbar/tabbar4.png'),
        active3: require('../../assets/images/tabbar/tabbar5.png'),
        inactive3: require('../../assets/images/tabbar/tabbar6.png'),
        active4: require('../../assets/images/tabbar/tabbar7.png'),
        inactive4: require('../../assets/images/tabbar/tabbar8.png'),
        active5: require('../../assets/images/tabbar/tabbar9.png'),
        inactive5: require('../../assets/images/tabbar/tabbar10.png'),
      },
      // lang: "EN",
      country: 'USA',
      fieldValue: '',
      showLocationBox: false,
      searchWord: '',
      state: '',
      // 州列表
      stateList: [],
      showStateBox: true,
      showCityBox: true,
      isActive: null,
      adVipList: [],
      city: '',
      cityName: '',

      langeuage: '',
      fieldNames: {
        text: 'cityAdNumStr',
        value: 'cityName',
        children: 'children',
      },
      // 轮播列表
      rotationList: [],
      // 获取当前城市名称与广告总数
      advertisementCountData: {},
      tokenKey: localStorage.getItem('key'),
      latLng: '',
      vipTablePage: {
        pageNum: 1, // 第几页
        pageSize: 40, // 每页多少条
        total: 0, // 总记录数
      },
      pageSizes: [40],
      vipCurrentPage: 1,

      code: '',
      codeUrl: '',
      uuid: '',
    }
  },
  created() {
    //根据IP获取用户位置
    apiGetUserCityByIp()
      .then((res) => {
        if (res.code == 200) {
          this.city = res.data.cityId
          console.log('cityInfo', res.data.cityName)
        } else {
          //默认洛杉矶
          this.city = 1733
        }
      })
      .then(() => {
        let latLngKey = 'adlatlng'
        let latLngVal = localStorage.getItem(latLngKey)
        this.latLng = latLngVal

        //判断是否从详情页跳转过来的
        let vipPageNumStr = this.$route.query.vipPageNum
        if (vipPageNumStr != undefined) {
          this.city = Number(this.$route.query.city)
          this.vipCurrentPage = Number(vipPageNumStr)
          this.handlePageChange(this.vipCurrentPage)
        } else {
          this.getApiVipList()
        }
      })

    // apiRotationList().then((res) => {
    //   if (res.code == 200) {
    //     this.rotationList = res.rows;
    //     console.log(res);
    //   }
    // });
    listCity({ webpage: 'vip' }).then((res) => {
      if (res.code == 200) {
        this.stateList = res.data
      }
    })
  },
  mounted() {
    window['onRecaptchaCallback'] = (response) => {
      this.onRecaptchaCallback(response)
    }
  },
  methods: {
    verifyCode() {
      apiVerifyCode({
        code: this.code,
        uuid: this.uuid,
      }).then((res) => {
        if (res.code == 200) {
          console.log('recaptcha ok')
          location.reload()
        } else {
          Toast.fail('verify error,please try again')
          this.getCode()
        }
      })
    },
    getCode() {
      getCodeImg().then((res) => {
        this.captchaEnabled =
          res.captchaEnabled === undefined ? true : res.captchaEnabled
        if (this.captchaEnabled) {
          this.codeUrl = 'data:image/gif;base64,' + res.img
          this.uuid = res.uuid
        }
      })
    },
    onRecaptchaCallback(response) {
      this.recaptchaResponse = response
      this.showRecaptcha = false

      apiRecaptchaed().then(() => {
        console.log('recaptcha ok')
        location.reload()
      })
    },
    reset() {
      this.cityName = ''
      //默认城市为用户当前城市，并查询数据
      apiGetUserCityByIp()
        .then((res) => {
          if (res.code == 200) {
            this.city = res.data.cityId
            console.log('cityInfo', res.data.cityName)
          } else {
            //默认洛杉矶
            this.city = 1733
          }
        })
        .then(() => {
          let latLngKey = 'adlatlng'
          let latLngVal = localStorage.getItem(latLngKey)
          this.latLng = latLngVal

          this.getApiVipList()
        })
        .then(() => {
          this.showLocationBox = false
        })
    },
    getApiVipList() {
      apiVipList({
        city: this.city,
        langeuage: this.langeuage,
        latLng: this.latLng,
        pageNumAd: this.vipTablePage.pageNum,
        pageSizeAd: this.vipTablePage.pageSize,
      }).then((res) => {
        if (res.code == 200) {
          this.adVipList = res.rows
          this.vipTablePage.total = res.total
        } else if (res.code == 204) {
          //需要进行人机验证
          this.showRecaptcha = true
          this.getCode()

          this.adVipList = res.rows
          this.vipTablePage.total = res.total

          //添加recaptcha JS文件
          // var recaptchaDiv = document.getElementById("recaptchaDiv");
          // const scriptDom = document.createElement("script");
          // scriptDom.src ="https://www.google.com/recaptcha/api.js";
          // recaptchaDiv.appendChild(scriptDom);
        }
      })
    },
    closeCascader() {
      this.showLocationBox = false
    },
    onFinish(selectedOptions) {
      console.log('selectedOptions', selectedOptions)
      this.showLocationBox = false
      this.cityName =
        selectedOptions.selectedOptions[1].parentName +
        '/' +
        selectedOptions.selectedOptions[1].cityName

      //设置城市信息，并查询AD
      this.city = selectedOptions.selectedOptions[1].cityId
      this.vipTablePage.pageNum = 1
      this.vipTablePage.pageSize = 40
      this.getApiVipList()

      //获取城市AD信息
      getCityDetails({
        cityId: this.city,
      }).then((res) => {
        if (res.code == 200) {
          this.advertisementCountData = res.data
        }
      })
    },
    goDetails(id) {
      this.$router.push({
        path: '/vipDetails',
        query: {
          adid: id,
          city: this.city,
          vipPageNum: this.vipTablePage.pageNum,
          vipPageSize: this.vipTablePage.pageSize,
        },
      })
    },
    handleCity(item) {
      this.cityName = item.cityName
      apiVipList({
        city: this.city,
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        langeuage: this.langeuage,
      }).then((res) => {
        if (res.code == 200) {
          this.adVipList = res.rows
        }
      })
      getCityDetails({
        cityId: item.cityId,
      }).then((res) => {
        if (res.code == 200) {
          this.advertisementCountData = res.data
        }
      })
      this.showLocationBox = false
    },
    searchClick() {
      getStateData({ cityName: this.searchWord }).then((res) => {
        if (res.code == 200) {
          this.stateList = res.data
        }
      })
    },
    handlePageChange(currentPage) {
      this.vipTablePage.pageNum = currentPage
      // 在此刷新数据
      this.getApiVipList()
    },
    handleSizeChange(pageSize) {
      this.vipTablePage.pageSize = pageSize
      // 在此刷新数据
      this.getApiVipList()
    },
  },
}
</script>

<style lang="scss" scoped>
.page {
  background: #f0f0f0;
}

.content {
  margin: 14px 17px 120px;
  font-size: 16px;
  line-height: 36px;
  .swiper-img-box {
    :deep(.van-swipe__indicator) {
      width: 14px;
      height: 14px;
      margin-right: 10px !important;
    }

    .swipe-item-img {
      width: 100%;
      height: 260px;
    }
  }

  // 地区下拉框
  .location-box {
    position: relative;
    margin: 20px 0;

    .area-flex-box {
      height: 80px;
      background: #ffffff;
      border: 1px solid rgba(112, 112, 112, 0.34);
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px;
    }

    .area-box-lf {
      font-size: 28px;
      font-weight: 400;
      color: #242424;
    }

    .bottom-icon-bl-img {
      width: 48px;
      height: 48px;
    }

    .location-select-box {
      z-index: 1;
      background: #fff;
      padding: 20px;
    }

    .search-box {
      height: 81px;
      background: #ffffff;
      border: 1px solid #b2b2b2;
      margin-bottom: 30px;
    }

    .location-ipt {
      height: 81px;
      align-items: center;
    }

    :deep(.van-field__control) {
      font-size: 28px;
    }

    .search-icon {
      width: 29px;
      height: 29px;
    }

    .location-list {
      margin-bottom: 40px;
    }

    .location-list-title {
      font-size: 30px;
      font-weight: bold;
      color: #000000;
    }

    .state-cell {
      box-sizing: border-box;
      padding: 26px 0;
      overflow: hidden;
      font-size: 28px;
      font-weight: 400;
      color: #000000;
    }

    .state-value {
      font-size: 28px;
      font-weight: 400;
      color: #000000;
      text-align: center;
    }

    .city-cell {
      box-sizing: border-box;
      padding: 26px 0;
      overflow: hidden;
      font-size: 24px;
      font-weight: 400;
      color: #989898;
    }

    .city-value {
      font-size: 24px;
      font-weight: 400;
      color: #989898;
      text-align: center;
    }
  }

  .title {
    font-size: 24px;
    font-weight: 400;
    color: #5d5d5d;
    margin: 20px 0;
  }

  .img-box {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;

    .img-box-item {
      width: calc(50% - 10px);
      height: 520px;
      margin-bottom: 20px;
      background-color: #fff;
      padding: 20px;
      color: #000000;
      box-sizing: border-box;
    }

    .activeBg {
      background-color: #273458;
      color: #fff;
    }

    .img-box-item:nth-child(odd) {
      margin-right: 10px;
    }

    .img-box-item:nth-child(even) {
      margin-left: 10px;
    }

    .img-bigBox {
      position: relative;
      /*相对定位*/
      height: 420px;
      margin-bottom: 20px;
      display: flex;
      /*弹性盒，用于居中*/
      justify-content: center;
      /*水平中心*/
      align-items: center;
      /*垂直中心*/
    }

    .img-box-img {
      max-width: 100%;
      /*最大宽度不超过父元素宽度*/
      max-height: 100%;
      /*最大高度不超过父元素高度*/
      object-fit: contain;
      /*调整比例,居中*/
    }

    .img-text {
      font-size: 26px;
      font-weight: bold;
    }

    .img-text-p {
      margin-right: 30px;
    }
  }
}
</style>

<style lang="scss">
.van-cascader__header {
  font-size: 0.3rem;
}

.van-cascader__options {
  height: auto !important;
  .van-cascader__option {
    line-height: 0.6rem;
    font-size: 0.4rem;
    white-space: pre;
    font-family: monospace;
  }
}
</style>
<style scoped>
:deep(.el-pagination__sizes) {
  width: 20%;
}
:deep(.el-pagination .el-select .el-input) {
  width: 100% !important;
}

:deep(.van-field__label) {
  width: auto !important;
  font-size: large;
  margin-right: 20px;
  color: black;
}

.confirm-btn {
  margin: 21px 35px 35px;
  height: 70px;
  width: 498px;
  font-size: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  color: #ffffff;
  background: #273458;
  box-shadow: 0px 3px 12px 1px rgba(71, 71, 71, 0.16);
}
</style>
