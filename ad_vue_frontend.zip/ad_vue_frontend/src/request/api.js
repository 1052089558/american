import { get, post, put ,postAddConfig} from "./http.js";
//注册接口
export const apiRegister = (p) => post("/api/registerApp", p);
// 获取验证码
export const apiGetVerificationCode = (g) => get(`/api/verificationCode`,g);
// 验证邮箱接口
export const apiForgotEmail = (p) => post("/api/forgotEmail", p);
// app端登录接口
export const apiLoginApp = (p) => post("/api/loginApp", p);
// 重置密码接口
export const apiChangePassword = (p) => post("/api/changePassword", p);
// 个人中心-获取隐私说明接口
export const apiGetPrivacyStatement = () => get("/person/getPrivacyStatement");
// 个人中心-联系我们接口
export const apiGetContactUs = () => get("/person/contactUs");
// 个人中心-退出登录接口
export const apiGetLogout = () => get("/person/logout");
// 个人中心-更改密码-邮箱发送验证码接口
export const apiGetPersonVerificationCode = (g) => get(`/person/verificationCode`,g);
// 个人中心-重置密码接口
export const apiPersonChangePassword = (p) => post("person/changePassword", p);
// 个人中心-更改电子邮件接口
export const apiChangeUsername = (p) => post("person/changeUsername", p);
// 个人信息-查询用户信息接口
export const apiGetInfo = () => get("system/user/getDetail");
// 个人中心-个人信息修改接口
export const apiUpdateUser = (p) => put("person/updateUser", p);
// 文件上传
export const apiUpload = (p) => postAddConfig("/common/upload", p,{timeout:300000});
// 获取服务器时间
export const apiGetNowDate = () => get("/common/getNowDate");
// 轮播接口 
export const apiRotationList = () => get("/rotation/list");
// vip列表查询
export const apiVipList = (p) => get("/advertisement/getVipList", p);
// vip广告详情接口
export const apiVipDetail = (p) => get(`/advertisement/vipDetail/${p}`);
// 首页类型分类/分类字典数据获取
export const apiAdvertisingClassification = () => get("/system/dict/data/type/advertisingClassification");
// 职业类型查询
export const apiOccupation = () => get("/system/dict/data/type/occupation");
// 种族类型查询
export const apiRace = () => get("/system/dict/data/type/race");
// 语言类型查询
export const apiLanguage = () => get("/system/dict/data/type/language");
// available类型查询
export const apiAvailable = () => get("/system/dict/data/type/available");
// 推荐广告列表
export const apiGetRecommendList = (p) => get("/advertisement/getRecommendList", p);
// 全部广告列表
export const apiGetAllList = (p) => get("/advertisement/getAllList", p);
// 没参数全部列表
export const apiAllList = (p) => get("/advertisement/list", p);
// 主页广告详情
export const apiGetAllList_detail = (p) => get(`/advertisement/adDetailForShow`,p);
// 发布广告页的广告详情
export const apiGetAdDetailForEdit = (p) => get(`/advertisement/adDetailForEdit`,p);
// 金额数据及系统配置获取接口
export const apiConfigurationList = () => get("/configuration/list");
// 消息提示获取接口
export const apiGetRemark = (p) => get(`/advertisement/getRemark/${p}`);
// 获取当前城市名称与广告总数
export const apiGetAdvertisementCount = () => get("/advertisement/getAdvertisementCount");
// 我的广告-广告弹窗数据
export const apiUpdateRemark = (p) => put("/advertisement/updateRemark", p);
// 广告草稿列表获取接口
export const apiGetAdvertisingDraft = () => get("/advertisement/getAdvertisingDraft");
// 地址数据获取
export const apiGetDeptList = () => get("/system/dept/list");
// 地址数据获取===>带参数
export const apiGetDeptList_p = (p) => get("/system/dept/list", p);
// 地址树形数据获取
export const apiGetUserDeptTree = () => get("/system/user/deptTree");

//发布广告接口
export const apiPOSTadvertisement = (p) => post("/advertisement", p);
//修改广告接口
export const apiPOSTadvertisement_put = (p) => put("/advertisement", p);
//修改广告基础信息接口
export const apiPOSTadvertisementEditBase = (p) => post("/advertisement/editBaseInfo", p);
//修改广告草稿箱信息接口，步骤3-4-3切换时使用
export const apiPOSTAdUpdateDraftInfo = (p) => post("/advertisement/updateDraftInfo", p);
//修改广告封面图
export const apiPOSTadvertisement_put_replace = (p) => put("/advertisement/editThumbnail", p);



// 广告发布列表获取接口
export const apiGetAdvertisingReleaseList = () => get("/advertisement/getAdvertisingReleaseList");
// newmessage 的问号提示
export const apiGetMessagePrompt = () => get("/system/dict/data/type/message_prompt");
// upgrade的问号提示
export const apiGetUpgradePrompt = () => get("/system/dict/data/type/upgrade_prompt ");
// gaincustomer的问号提示
export const apiGetCustomerPrompt = () => get("/system/dict/data/type/customer_prompt ");
// upgrde的下拉框分类
export const apiGetUpgradeSelect = () => get("/system/dict/data/type/upgrade_select");
// 广告草稿发布接口
export const apiAdvertisingRelease = (p) => post("/advertisement/getAdvertisingRelease", p);
// 升级客户数下拉框分类key
export const apiGainCustomers = () => get("/system/dict/data/type/gaincustomers");
// 修改广告草稿接口
export const apiUpdateDraft = (p) => put("/advertisement/updateAdvertisingDraft", p);
// 金额类型查询
export const apiBalance = () => get("/system/dict/data/type/balance");
// 充值接口
export const apiRecharge = (p) => put("/advertisement/recharge", p);
// 获取当前广告金额
export const apiGetAdvertisementMoney = () => get("/advertisement/getAdvertisementMoney");
// 我的广告 - 签到接口
export const apiSignDays = (p) => put(`/system/user/signDays`,p)
// 我的广告 - 删除接口
export const apiAdvertisingDelete = (p)=> get(`/advertisement/deleteAd/${p}`)
// 我的广告 - 购买广告时长
export const apiBuyAdTime = (p)=> get("/advertisement/buyadtime",p)
// 我的广告 - 升级广告
export const apiUpgradeAd = (p)=> get("/advertisement/upgradeAd",p)
//我的位置 - 查询当前用户位置街道信息
export const getUserLoc= (p) => get("/system/user/getUserLoc",p);
//我的签到金额 - 查询系统设置的签到金额
export const getSignMoney= () => get("/system/user/getSignMoney");
//我的优惠券信息 - 查询优惠券
export const getTaskRewards= () => get("/system/user/getTaskRewards");
//获取优惠券
export const getCoupon = (p) => get("/system/user/getCoupon",p);
//获取城市
export const getCityName= (p) => get("/system/city/list",p);

export const getCityDetails = (p) => get("/system/city/details",p);
//获取所有州
export const getStateData = (p) => get("/system/city/state",p);
export const listCity = (p) => get("/system/city/list-tree",p);

//获取州下的所有城市
export const getStataCity= (p) => get("/system/city/state-city",p);

// hai_color头发颜色
// height身高选项
// weight体重选项
// age年龄选项
// breast_size尺寸大小
// select_one_or_more  选项一
// available_to  选项二
// servlce_provided_as  选项三
// independent选项四
// sys_user_sex用户性别
export const apiGetgenderList = () => get('/system/dict/data/type/sys_user_sex') // 性别
export const apiGetindependent = () => get('/system/dict/data/type/independent') // 选项四
export const apiGetservlce_provided_as = () =>
  get('/system/dict/data/type/servlce_provided_as') // 选项三
export const apiGetavailable_to = () =>
  get('/system/dict/data/type/available_to') // 选项二
export const apiGetselect_one_or_more = () =>
  get('/system/dict/data/type/select_one_or_more') // 选项一
  export const apiGetselect_provide = () =>
  get('/system/dict/data/type/provide') // 选项一
export const apiGetbreast_size = () => get('/system/dict/data/type/breast_size') // 尺寸大小
export const apiGetage = () => get('/system/dict/data/type/age') // 年龄
export const apiGetweight = () => get('/system/dict/data/type/weight') // 体重
export const apiGetheight = () => get('/system/dict/data/type/height') // 身高
export const apiGethai_color = () => get('/system/dict/data/type/hair_color') // 发色
export const apiGethai_length = () => get('/system/dict/data/type/hair_length') // 发长
export const apiGettravel = () => get('/system/dict/data/type/travel') // 旅行
export const apiGetEyeColor = () => get('/system/dict/data/type/eye_color') // eye_color

export const apiGetGoogleMapDetail = (params) => get(`/advertisement/getNearbyLoc`,params) // 地址确认

export const getConfigValue = (params) => get('/system/config/configvalue',params) // 根据配置key获取配置值

export const getInvitationAddress = (params) => get('/advertisement/invite-code',params) // 根据配置key获取配置值

export const apiFeedbackInformation = (p) => post('/system/feedback/insert',p)//用户反馈信息
export const apiGetGoogleUserInfo = (p) => get('/GoogleUserInfo',p) //获取谷歌用户信息
export const apiGetUserCityByIp = () => get('/advertisement/getUserCityByIp') //获取IP所在城市
export const apiNeedManey = (p) => get('/advertisement/neddManey',p) //是否需要增加基础时长30天
export const apiRecaptchaed = () => get('/advertisement/recaptchaed') //已人机验证
export const apiNeedToastGetLatLng = () => get('/advertisement/needToastGetLatLng') //是否弹窗提示获取位置授权信息
export const apiVerrfyPayState = (p) => get('/person/verrfypaystate',p) //验证支付事件状态
export const getCodeImg = () =>get('/captchaImage')  //获取验证码区域
export const apiVerifyCode = (p) =>get('/verifycaptchacode',p)  //获取验证码区域
export const apigotoverify = (p) =>get('/gotoverify',p)  //真人认证
export const apigetverifyDetail = (p) =>get('/getverifyDetail',p)  //获取当前真人认证信息
export const apiSysReportAdd = (p) =>get('/sysreport/add',p)  //新增举报信息
export const apiRecordVisitorViewTime = (p) =>get('/system/user/recordVisitorViewTime',p)  //页面停留时间查询

export const apiRecodeShareNum = (p) =>get('/invitation/recordShareNum',p)  //用户点击分享时进行分享次数记录