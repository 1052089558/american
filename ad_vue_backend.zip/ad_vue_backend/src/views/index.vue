<template>
  <div class="app-container home">
    <div>
      用户总余额：{{ totalBalance }} <br />
      用户总花费：{{ totalPay }} <br />
      今日购买小图天数：{{ buyBaseToday }} <br />
      今日购买基础展示天数{{ buyNormalToday }} <br />
      今日购买大图天数：{{ buyTopToday }} <br />
      今日购买推荐天数：{{ buyRecommendToday }} <br />
      用户总充值金额：{{ totalRecharge }} <br />
      昨日充值金额：{{ yesterdayRecharge }} <br />
      今日充值金额：{{ todayRecharge }} <br />
      今日手机端访客停留总时长： {{ viewTimeForPh }} 秒 <br />
      今日电脑端访客停留总时长： {{ viewTimeForPc }} 秒<br />
      今日发起邀请用户数：{{executeInvitationUserNum}} 个 <br />
      今日用户发起邀请数：{{invitationNum}} 次 <br />
      今日有效邀请数：{{effectNum}} 个 <br />
      今日邀请奖励金额：{{invitationReward}}
    </div>

    <div style="display: flex">
      <div ref="visitorNewOld" style="height: 300px; width: 420px"></div>
      <div ref="visitorFromPcPhone" style="height: 300px; width: 420px"></div>
    </div>
    
    <!-- 折线展示数据余额变动 -->
    <div ref="balanceChangeRef" style="height: 600px; width: 1200px"></div>
  </div>
</template>

<script>
import * as echarts from "echarts";
require("echarts/theme/macarons"); // echarts theme
import {
  getTodayVisitorTraffic,
  showBalanceChange,
} from "@/api/system/baseshow";

const animationDuration = 3000;

export default {
  name: "Index",
  data() {
    return {
      // 版本号
      version: "3.8.5",

      executeInvitationUserNum:0,
      invitationNum:0,
      effectNum:0,
      invitationReward:0,

      oldVisitorNum: 0,
      newVisitorNum: 0,
      nowDate: "",
      fromPc: 0,
      fromPhone: 0,

      totalPay: 0,
      totalBalance: 0,

      todayRecharge: 0,
      yesterdayRecharge: 0,
      totalRecharge: 0,

      buyBaseToday: 0,
      buyNormalToday: 0,
      buyTopToday: 0,
      buyRecommendToday: 0,

      viewTimeForPh: 0,
      viewTimeForPc: 0,

      balanceChangeType: [],
      balanceChangeDate: [],
      autorenew: [],
      buyadtime: [],
      upgrade: [],
      postad: [],
      recharge: [],
      sign: [],
      coupon: [],
    };
  },
  created() {
    //获取当日的访客数据
    getTodayVisitorTraffic().then((res) => {
      if (res.code == 200) {
        console.log("200 res");
        this.oldVisitresorNum = res.data.oldVisitorNum;
        this.newVisitorNum = res.data.newVisitorNum;
        this.nowDate = res.data.nowDate;
        this.fromPc = res.data.fromPc;
        this.fromPhone = res.data.fromPhone;

        this.totalBalance = res.data.totalBalance;
        this.totalPay = res.data.totalPay;

        this.totalRecharge = res.data.totalRecharge;
        this.yesterdayRecharge = res.data.yesterdayRecharge;
        this.todayRecharge = res.data.todayRecharge;

        this.buyBaseToday = res.data.buyBaseToday;
        this.buyNormalToday = res.data.buyNormalToday;
        this.buyTopToday = res.data.buyTopToday;
        this.buyRecommendToday = res.data.buyRecommendToday;

        this.viewTimeForPc = res.data.viewTimeForPc;
        this.viewTimeForPh = res.data.viewTimeForPh;

        this.executeInvitationUserNum=res.data.executeInvitationUserNum;
        this.invitationNum=res.data.invitationNum;
        this.effectNum=res.data.effectNum;
        this.invitationReward=res.data.invitationReward;
      }
    });

    showBalanceChange().then((res) => {
      if (res.code == 200) {
        this.balanceChangeType = res.data.balanceChangeType;
        this.balanceChangeDate = res.data.balanceChangeDate;
        this.autorenew = res.data.autoRenew;
        this.buyadtime = res.data.buyAdTime;
        this.postad=res.data.postad;
        this.recharge=res.data.recharge;
        this.upgrade=res.data.upgrade;
        this.coupon=res.data.coupon;
        this.sign=res.data.sign;        
      }
    });
  },
  mounted() {
    setTimeout(() => {
      this.initchartvisitorNewOld();
      this.initchartvisitorFromPcPhone();
      this.initBalanceChange();
    }, 2000);
  },
  methods: {
    initchartvisitorNewOld() {
      var chartvisitorNewOld = echarts.init(
        this.$refs.visitorNewOld,
        "macarons"
      );
      chartvisitorNewOld.setOption({
        title: {
          text: "visitor new/old",
          left: "center",
          textStyle: {
            //标题内容的样式
            color: "#e4393c", //京东红
            fontStyle: "normal", //主标题文字字体风格，默认normal，有italic(斜体),oblique(斜体)
            fontWeight: "lighter", //可选normal(正常)，bold(加粗)，bolder(加粗)，lighter(变细)，100|200|300|400|500...
            fontFamily: "san-serif", //主题文字字体，默认微软雅黑
            fontSize: 12, //主题文字字体大小，默认为18px
          },
        },
        tooltip: {
          trigger: "item",
        },
        legend: {
          orient: "vertical",
          left: "left",
        },
        label: {
          show: true,
          formatter(param) {
            // correct the percentage
            return param.name + " (" + param.value + ")";
          },
        },
        series: [
          {
            name: "访问来源",
            type: "pie", // 设置图表类型为饼图
            radius: "55%", // 饼图的半径，外半径为可视区尺寸（容器高宽中较小一项）的 55% 长度。
            data: [
              // 数据数组，name 为数据项名称，value 为数据项值
              { value: this.oldVisitorNum, name: "旧访客" },
              { value: this.newVisitorNum, name: "新访客" },
            ],
          },
        ],
      });
    },

    initchartvisitorFromPcPhone() {
      var chartvisitorNewOld = echarts.init(
        this.$refs.visitorFromPcPhone,
        "macarons"
      );
      chartvisitorNewOld.setOption({
        title: {
          text: "visitor from Pc/Phone",
          left: "center",
          textStyle: {
            //标题内容的样式
            color: "#e4393c", //京东红
            fontStyle: "normal", //主标题文字字体风格，默认normal，有italic(斜体),oblique(斜体)
            fontWeight: "lighter", //可选normal(正常)，bold(加粗)，bolder(加粗)，lighter(变细)，100|200|300|400|500...
            fontFamily: "san-serif", //主题文字字体，默认微软雅黑
            fontSize: 12, //主题文字字体大小，默认为18px
          },
        },
        tooltip: {
          trigger: "item",
        },
        legend: {
          orient: "vertical",
          left: "left",
        },
        label: {
          show: true,
          formatter(param) {
            // correct the percentage
            return param.name + " (" + param.value + ")";
          },
        },
        series: [
          {
            name: "访问来源",
            type: "pie", // 设置图表类型为饼图
            radius: "55%", // 饼图的半径，外半径为可视区尺寸（容器高宽中较小一项）的 55% 长度。
            data: [
              // 数据数组，name 为数据项名称，value 为数据项值
              { value: this.fromPc, name: "手机" },
              { value: this.fromPhone, name: "电脑" },
            ],
          },
        ],
      });
    },

    initBalanceChange() {
      var balanceChange = echarts.init(this.$refs.balanceChangeRef, "macarons");
      balanceChange.setOption({
        title: {
          text: "balance change",
        },
        tooltip: {
          trigger: "axis",
        },
        legend: {
          data: this.balanceChangeType,
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        toolbox: {
          feature: {
            saveAsImage: {},
          },
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: this.balanceChangeDate,
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            name: "autorenew",
            type: "line",
            stack: "Total",
            data: this.autorenew,
          },
          {
            name: "buyadtime",
            type: "line",
            stack: "Total",
            data: this.buyAdTime,
          },
          ,
          {
            name: "postad",
            type: "line",
            stack: "Total",
            data: this.postad,
          },
          {
            name: "recharge",
            type: "line",
            stack: "Total",
            data: this.recharge,
          },
          {
            name: "upgrade",
            type: "line",
            stack: "Total",
            data: this.upgrade,
          },
          {
            name: "coupon",
            type: "line",
            stack: "Total",
            data: this.coupon,
          },
          {
            name: "sign",
            type: "line",
            stack: "Total",
            data: this.sign,
          },
        ],
      });
    },

    goTarget(href) {
      window.open(href, "_blank");
    },
  },
};
</script>

<style scoped lang="scss">
.home {
  blockquote {
    padding: 10px 20px;
    margin: 0 0 20px;
    font-size: 17.5px;
    border-left: 5px solid #eee;
  }
  hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
  }
  .col-item {
    margin-bottom: 20px;
  }

  ul {
    padding: 0;
    margin: 0;
  }

  font-family: "open sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 13px;
  color: #676a6c;
  overflow-x: hidden;

  ul {
    list-style-type: none;
  }

  h4 {
    margin-top: 0px;
  }

  h2 {
    margin-top: 10px;
    font-size: 26px;
    font-weight: 100;
  }

  p {
    margin-top: 10px;

    b {
      font-weight: 700;
    }
  }

  .update-log {
    ol {
      display: block;
      list-style-type: decimal;
      margin-block-start: 1em;
      margin-block-end: 1em;
      margin-inline-start: 0;
      margin-inline-end: 0;
      padding-inline-start: 40px;
    }
  }
}
</style>
