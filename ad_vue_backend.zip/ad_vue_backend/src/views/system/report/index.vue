<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryForm"
      size="small"
      :inline="true"
      v-show="showSearch"
      label-width="68px"
      >
      <!-- <el-form-item label="举报类型" prop="type">
        <el-input
          v-model="queryParams.userName"
          placeholder="请输入用户名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      -->

      <el-form-item label="举报类型" prop="type">
        <el-select v-model="queryParams.type" clearable placeholder="请选择">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="举报状态" prop="status">
        <el-select v-model="queryParams.status" clearable placeholder="请选择">
          <el-option
            v-for="item in statusOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          size="mini"
          @click="handleQuery"
          >搜索</el-button
        >
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-table
      v-if="refreshTable"
      v-loading="loading"
      :data="reportList"
      row-key="id"
      :default-expand-all="isExpandAll"
    >
      <el-table-column label="广告ID" align="center" prop="adId" />
      <el-table-column label="举报类型" align="center" prop="type" />
      <el-table-column label="举报人邮箱" align="center" prop="contactEmail" />
      <el-table-column label="举报内容" align="center" prop="content" />
      <el-table-column label="处理状态" align="center" prop="handleFlag" />
      <el-table-column label="处理用户" align="center" prop="handleWithUser" />
      <el-table-column label="是否邮件反馈" align="center" prop="handleWithEmailFlag" />
      <el-table-column
        label="举报创建时间"
        align="center"
        prop="createTime"
        width="200"
      >
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="举报更新时间"
        align="center"
        prop="updateTime"
        width="200"
      >
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.updateTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template slot-scope="scope">
          <el-link :href="'https://www.abcd69.com/detail?advertisementId='+scope.row.adId" target="_blank">查看AD</el-link>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row.id,scope.row.adId)"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
          v-show="total>0"
          :total="total"
          :page.sync="queryParams.pageNum"
          :limit.sync="queryParams.pageSize"
          @pagination="getList"
      />


  </div>
</template>
  
  <script>
import {
  listReport,delAd
} from "@/api/system/report.js";
export default {
  name: "rechargeLog",
  components: { },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 是否展开，默认全部展开
      isExpandAll: true,
      // 重新渲染表格状态
      refreshTable: true,
      // 总条数
      total: 0,
      // 【请填写功能名称】表格数据
      reportList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        type:undefined,
        status:undefined,
        pageNum: 1,
        pageSize: 10,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        
      },

      options: [{
          value: 'deceptive',
          label: '欺诈'
        }, {
          value: 'underage',
          label: '未成年'
        }, {
          value: 'bloody',
          label: '血腥'
        }],

        statusOptions: [{
          value: 'handled',
          label: '已处理'
        }, {
          value: 'unhandled',
          label: '未处理'
        }],
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询【请填写功能名称】列表 */
    getList() {
      this.loading = true;
      listReport({
        // userName:this.queryParams.userName,
        type:this.queryParams.type,
        handleFlag:this.queryParams.status,
        pageNum:this.queryParams.pageNum,
        pageSize:this.queryParams.pageSize
      }).then((res)=>{
        this.reportList =res.rows
        this.total=res.total
        this.loading = false;
      })
    },
    toggleExpandAll() {
      this.refreshTable = false;
      this.isExpandAll = !this.isExpandAll;
      this.$nextTick(() => {
        this.refreshTable = true;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.queryParams.userName='';
      this.queryParams.cbType='';
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map((item) => item.cityId);
      this.single = selection.length !== 1;
      this.multiple = !selection.length;
    },
    /** 修改按钮操作 */
    handleUpdate(selectId,selectAdId) {
      delAd({
        id:selectId,
        adId:selectAdId
      }).then((res)=>{
        this.$modal.msgSuccess("已删除");
        this.handleQuery();
      })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const cityIds = row.cityId || this.ids;
      this.$modal
        .confirm(
          '是否确认删除【请填写功能名称】编号为"' + cityIds + '"的数据项？'
        )
        .then(function () {
          return delCity(cityIds);
        })
        .then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        })
        .catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(
        "system/city/export",
        {
          ...this.queryParams,
        },
        `city_${new Date().getTime()}.xlsx`
      );
    },
  },
};
</script>
  