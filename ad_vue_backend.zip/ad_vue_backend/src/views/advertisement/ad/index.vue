<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryForm"
      size="small"
      :inline="true"
      v-show="showSearch"
      label-width="68px"
    >
      <el-form-item label="广告ID" prop="adId">
        <el-input
          v-model="queryParams.adId"
          placeholder="请输入广告ID"
          clearable
        />
      </el-form-item>

      <el-form-item label="认证状态" prop="status">
        <el-select v-model="queryParams.status" clearable placeholder="请选择">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          size="mini"
          @click="handleQuery"
          >搜索</el-button
        >
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-table
      v-if="refreshTable"
      v-loading="loading"
      :data="adList"
      row-key="id"
      :default-expand-all="isExpandAll"
    >
      <el-table-column label="AD用户" align="center" prop="userName" />
      <el-table-column
        label="手机号"
        align="center"
        prop="phoneAreaCode,phoneNumber"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.phoneAreaCode + scope.row.phoneNumber }}</span>
        </template>
      </el-table-column>
      <el-table-column label="邮箱" align="center" prop="email" />

      <el-table-column label="ADID" align="center" prop="advertisementId" />
      <el-table-column label="AD分类" align="center" prop="categoryStr" />
      <el-table-column label="AD类型" align="center" prop="type" />
      <el-table-column label="AD状态" align="center" prop="status" />
      <el-table-column
        label="AD总充值金额"
        align="center"
        prop="totalRecharge"
      />
      <el-table-column label="AD认证" align="center" prop="verify" />
      <el-table-column
        label="AD展示自动续费"
        align="center"
        prop="autoRenewalNormal"
      />
      <el-table-column
        label="AD大图自动续费"
        align="center"
        prop="autoRenewalTop"
      />
      <el-table-column
        label="AD推荐自动续费"
        align="center"
        prop="autoRenewalRecommend"
      />
      <el-table-column label="AD失效时间" align="center" prop="expireDate">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.expireDate) }}</span>
        </template></el-table-column
      >
      <el-table-column
        label="AD展示失效时间"
        align="center"
        prop="normalExpireDate"
      >
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.normalExpireDate) }}</span>
        </template></el-table-column
      >
      <el-table-column
        label="AD大图失效时间"
        align="center"
        prop="topExpireDate"
      >
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.topExpireDate) }}</span>
        </template></el-table-column
      >
      <el-table-column
        label="AD推荐失效时间"
        align="center"
        prop="recommendExpireDate"
      >
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.recommendExpireDate) }}</span>
        </template></el-table-column
      >
      <el-table-column
        label="创建时间"
        align="center"
        prop="createTime"
        width="200"
      >
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="更新时间"
        align="center"
        prop="updateTime"
        width="200"
      >
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.updateTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            @click="playVideo(scope.row.advertisementId)"
            >预览AD信息</el-button
          >
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row.advertisementId, 'delete')"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <el-dialog
      title="预览"
      :visible.sync="dialogPlay"
      v-model="dialogPlay"
      width="65%"
      @close="closeDialog"
    >
      <iframe :src="adUrl"></iframe>
    </el-dialog>
  </div>
</template>

<script>
import { apiGetAdList, updateAdStatus } from "@/api/ad/ad.js";
export default {
  name: "adList",
  components: {},
  data() {
    return {
      dialogPlay: false,
      adUrl: "",

      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 是否展开，默认全部展开
      isExpandAll: true,
      // 重新渲染表格状态
      refreshTable: true,
      // 总条数
      total: 0,
      // 【请填写功能名称】表格数据
      adList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        adId: undefined,
        status: undefined,
        pageNum: 1,
        pageSize: 10,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {},

      options: [
        {
          value: "release",
          label: "已发布",
        },
        {
          value: "draft",
          label: "草稿",
        },
        {
          value: "delete",
          label: "已删除",
        },
      ],
    };
  },
  created() {
    this.getList();
  },
  methods: {
    playVideo(adId) {
      this.dialogPlay = true;
      this.adUrl = "https://www.abcd69.com/detail?advertisementId=" + adId;
      console.log(this.adUrl);
    },
    closeDialog() {
      this.adUrl = ""; //清空数据 关闭视频播放
      console.log("clean adurl ");
    },
    /** 查询【请填写功能名称】列表 */
    getList() {
      this.loading = true;
      apiGetAdList({
        advertisementId: this.queryParams.adId,
        status: this.queryParams.status,
        pageNum: this.queryParams.pageNum,
        pageSize: this.queryParams.pageSize,
      }).then((res) => {
        this.adList = res.rows;
        this.total = res.total;
        this.loading = false;
      });
    },
    toggleExpandAll() {
      this.refreshTable = false;
      this.isExpandAll = !this.isExpandAll;
      this.$nextTick(() => {
        this.refreshTable = true;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.queryParams.userName = "";
      this.queryParams.cbType = "";
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map((item) => item.cityId);
      this.single = selection.length !== 1;
      this.multiple = !selection.length;
    },
    /** 修改按钮操作 */
    handleUpdate(selectId, flag) {
      updateAdStatus({
        advertisementId: selectId,
        status: flag,
      }).then((res) => {
        this.$modal.msgSuccess();
        this.handleQuery();
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const cityIds = row.cityId || this.ids;
      this.$modal
        .confirm(
          '是否确认删除【请填写功能名称】编号为"' + cityIds + '"的数据项？'
        )
        .then(function () {
          return delCity(cityIds);
        })
        .then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        })
        .catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(
        "system/city/export",
        {
          ...this.queryParams,
        },
        `city_${new Date().getTime()}.xlsx`
      );
    },
  },
};
</script>
<style>
.el-dialog__body {
  display: flex;
  justify-content: space-around;
}
</style>
