<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryForm"
      size="small"
      :inline="true"
      v-show="showSearch"
      label-width="68px"
      >
      <el-form-item label="州名称" prop="parent_id">
        <el-select v-model="queryParams.parent_id" clearable filterable placeholder="请选择">
          <el-option
            v-for="item in stateOptions"
            :key="item.cityId"
            :label="item.cityName"
            :value="item.cityId">
          </el-option>
        </el-select>
      </el-form-item>

      <!-- <el-form-item label="城市名称" prop="city_name">
        <el-select v-model="queryParams.city_name" clearable placeholder="请选择">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-form-item> -->
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          size="mini"
          @click="handleQuery"
          >搜索</el-button
        >
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-table
      v-if="refreshTable"
      v-loading="loading"
      :data="adManageInfoList"
      row-key="id"
      :default-expand-all="isExpandAll"
    >
      <el-table-column prop="city_name" label="城市名称"></el-table-column>
      <el-table-column label="城市广告消耗总金额" align="center" prop="amount" />
      <el-table-column label="vip广告数" align="center" prop="vipAdNums" />
      <el-table-column label="vip展示时长数/天" align="center" prop="vipAdDays" />
      <el-table-column label="伴游广告总数" align="center" prop="feAdNums" />
      <el-table-column label="伴游小图展示时长数/天" align="center" prop="feNormalAdDays" />
      <el-table-column label="伴游大图总数" align="center" prop="feTopAdNums" />
      <el-table-column label="伴游大图展示时长数/天" align="center" prop="feTopAdDays" />
      <el-table-column label="伴游推荐总数" align="center" prop="feRecommendAdNums" />
      <el-table-column label="伴游推荐展示时长数/天" align="center" prop="feRecommendAdDays" />
    </el-table>
    <pagination
          v-show="total>0"
          :total="total"
          :page.sync="queryParams.pageNum"
          :limit.sync="queryParams.pageSize"
          @pagination="getList"
      />


  </div>
</template>
  
  <script>
import {
  getAdManageInfo
} from "@/api/ad/ad.js";
import{
  listCityTree
} from "@/api/system/city.js";
export default {
  name: "adManageInfo",
  components: { },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 是否展开，默认全部展开
      isExpandAll: true,
      // 重新渲染表格状态
      refreshTable: true,
      // 总条数
      total: 0,
      // 【请填写功能名称】表格数据
      adManageInfoList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        parent_id: undefined,
        pageNum: 1,
        pageSize: 10,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        
      },

      stateOptions: [],

    };
  },
  created() {
    this.getList();

    listCityTree().then((res) => {
      if (res.code == 200) {
        this.stateOptions = res.data;
      }
    });
  },
  methods: {
    /** 查询【请填写功能名称】列表 */
    getList() {
      this.loading = true;
      getAdManageInfo({
        parentId:this.queryParams.parent_id,
        pageNum:this.queryParams.pageNum,
        pageSize:this.queryParams.pageSize
      }).then((res)=>{
        this.adManageInfoList =res.rows
        this.total=res.total
        this.loading = false;
      })
    },
    toggleExpandAll() {
      this.refreshTable = false;
      this.isExpandAll = !this.isExpandAll;
      this.$nextTick(() => {
        this.refreshTable = true;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.queryParams.userName='';
      this.queryParams.cbType='';
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map((item) => item.cityId);
      this.single = selection.length !== 1;
      this.multiple = !selection.length;
    },
    /** 修改按钮操作 */
    handleUpdate(id) {
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const cityIds = row.cityId || this.ids;
      this.$modal
        .confirm(
          '是否确认删除【请填写功能名称】编号为"' + cityIds + '"的数据项？'
        )
        .then(function () {
          return delCity(cityIds);
        })
        .then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        })
        .catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(
        "system/city/export",
        {
          ...this.queryParams,
        },
        `city_${new Date().getTime()}.xlsx`
      );
    },
  },
};
</script>
  