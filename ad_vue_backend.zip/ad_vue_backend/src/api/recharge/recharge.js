import request from '@/utils/request'

export function getRechargeLog(data){
  return request({
    url: '/api/rechargelog',
    method: 'post',
    params: data    
  })
}

export function dorecharge(data){
  return request({
    url: '/api/dorecharge',
    method: 'post',
    params: data    
  })
}