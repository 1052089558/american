import request from '@/utils/request'

export function getAdManageInfo(data){
  return request({
    url: '/api/getAdManageInfo',
    method: 'get',
    params: data    
  })
}

export function apiGetAdList(data){
  return request({
    url: '/api/getAdList',
    method: 'get',
    params: data    
  })
}


export function updateAdStatus(data){
  return request({
    url: '/api/updateAdStatus',
    method: 'get',
    params: data    
  })
}

