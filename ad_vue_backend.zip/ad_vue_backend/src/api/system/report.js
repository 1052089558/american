import request from '@/utils/request'

// 查询【请填写功能名称】列表
export function listReport(query) {
  return request({
    url: '/sysreport/getList',
    method: 'get',
    params: query
  })
}

export function delAd(query) {
  return request({
    url: '/sysreport/deleteAd',
    method: 'get',
    params: query
  })
}

