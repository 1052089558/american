import request from '@/utils/request'

// 查询【请填写功能名称】列表
export function listVerify(query) {
  return request({
    url: '/apiPersonVerify/getList',
    method: 'get',
    params: query
  })
}

export function updateVerify(query) {
  return request({
    url: '/apiPersonVerify/updateById',
    method: 'get',
    params: query
  })
}



