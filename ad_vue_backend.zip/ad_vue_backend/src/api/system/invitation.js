import request from '@/utils/request'
import { parseStrEmpty } from "@/utils/ruoyi";

// 查询邀请用户列表
export function getInvitationList(query) {
  return request({
    url: '/invitation/list',
    method: 'get',
    params: query
  })
}