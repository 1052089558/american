import request from '@/utils/request'

// 查询【请填写功能名称】列表
export function getTodayVisitorTraffic() {
  return request({
    url: '/system/baseshow/getTodayVisitorTraffic',
    method: 'get'
  })
}


export function showBalanceChange() {
  return request({
    url: '/system/baseshow/showBalanceChange',
    method: 'get'
  })
}



